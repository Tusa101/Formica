// GREYBOX dressing for points of interest (P19). Replaced by kit assets (PIPE §42–43).
import * as THREE from 'three';
import { pathLamp } from '../props/greybox.js';

const wood = new THREE.MeshStandardMaterial({ color: 0x5a4330, roughness: 0.85 });
const metal = new THREE.MeshStandardMaterial({ color: 0x6f6c66, roughness: 0.5, metalness: 0.5 });
const cloth = new THREE.MeshStandardMaterial({ color: 0x6b5a48, roughness: 0.95 });
const foreign = new THREE.MeshStandardMaterial({ color: 0x3a2d4a, emissive: 0x6a4fa0, emissiveIntensity: 0.8, roughness: 0.7, side: THREE.DoubleSide });

function build(kind) {
  const g = new THREE.Group();
  const add = (geo, m, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.rotation.set(rx, ry, rz); g.add(o); return o; };
  switch (kind) {
    case 'crate': add(new THREE.BoxGeometry(0.5, 0.4, 0.4), wood, 0, 0.2, 0, 0, 0.3); add(new THREE.BoxGeometry(0.35, 0.3, 0.3), wood, 0.1, 0.55, 0.02, 0, -0.2); break;
    case 'shelf': for (let i = 0; i < 3; i++) add(new THREE.BoxGeometry(1.2, 0.04, 0.3), wood, 0, 0.15 + i * 0.35, 0); for (const x of [-0.58, 0.58]) add(new THREE.BoxGeometry(0.05, 0.9, 0.3), wood, x, 0.45, 0); break;
    case 'tank': add(new THREE.CylinderGeometry(0.45, 0.5, 1.1, 14), metal, 0, 0.55, 0); add(new THREE.CylinderGeometry(0.06, 0.06, 1.2, 6), metal, 0.5, 0.9, 0, 0, 0, Math.PI / 2); break;
    case 'pipes': for (let i = 0; i < 2; i++) add(new THREE.CylinderGeometry(0.07, 0.07, 1.8, 8), metal, 0, 0.3 + i * 0.2, 0, 0, 0.6, Math.PI / 2); break;
    case 'broken-mast': add(new THREE.CylinderGeometry(0.06, 0.1, 1.6, 8), metal, 0, 0.6, 0, 0.5, 0, 0.3); add(new THREE.BoxGeometry(0.3, 0.25, 0.3), metal, 0.3, 0.12, 0.25, 0.3, 0.2, 0.1); break;
    case 'dead-lamp': { const l = pathLamp(); l.bulb.material = new THREE.MeshStandardMaterial({ color: 0x3a3020, roughness: 0.4 }); g.add(l.group); break; }
    case 'bedroll': { const b = add(new THREE.CylinderGeometry(0.18, 0.18, 0.9, 10), cloth, 0, 0.12, 0, 0, 0.4, Math.PI / 2); b.scale.set(1, 1, 0.6); break; }
    case 'foreign-mark': add(new THREE.CircleGeometry(0.35, 7), foreign, 0, 0.03, 0, -Math.PI / 2); break;
    default: break;
  }
  return g;
}

export function buildPois(scene, field, pois) {
  for (const q of pois || []) for (const [kind, pos] of q.dressing || []) {
    const fl = field.dropToSurface(pos, 4) || pos;
    const g = build(kind); g.position.set(...fl); g.rotation.y = (pos[0] * 7 + pos[2] * 3) % 6.28;
    scene.add(g);
  }
}
