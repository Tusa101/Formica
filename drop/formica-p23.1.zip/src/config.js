// All tunable parameters live here. Units: 1 world unit = 1 "ant metre" (ant body ≈ 1.0).
// BUILD is replaced by the deploy workflow; locally it stays "dev".

export const BUILD = '__BUILD__'.startsWith('__') ? 'dev' : '__BUILD__';
export const PHASE = 'P23';

const deepFreeze = (o) => {
  for (const v of Object.values(o)) if (v && typeof v === 'object') deepFreeze(v);
  return Object.freeze(o);
};

export const CONFIG = deepFreeze({
  render: {
    maxPixelRatio: 2,
    maxPixelRatioTouch: 1.5,
    antialiasDesktop: true,
    antialiasTouch: false,
    fov: 75,
    near: 0.02,
    far: 120,
    clearColor: 0x07090b,
    fogColor: 0x07090b,
    fogNear: 4,
    fogFar: 38,
  },
  sim: {
    step: 1 / 60,
    maxStepsPerFrame: 5,
  },
  input: {
    mouseSensitivity: 0.0022,   // rad per px
    touchLookSensitivity: 0.0055, // rad per CSS px
    invertY: false,
    stickRadius: 56,            // CSS px
    stickDeadzone: 0.12,        // 0..1
    stickExponent: 1.6,         // response curve
  },
  noclip: {
    speed: 3.2,                 // units / s
    fastMultiplier: 2.5,
    verticalSpeed: 2.4,
    pitchLimit: 1.5,            // rad
  },
  ant: {
    adhesion: false,            // ADDENDUM 03 §2: ground-first; true = Adhesion Suit (P22) / creatures
    minUp: 0.643,               // cos 50°: steepest walkable slope
    hover: 0.32,                // body centre above the surface
    walkSpeed: 2.2,             // units / s (~2 body lengths)
    runMultiplier: 1.7,
    jumpSpeed: 3.2,
    detachTime: 0.18,           // s without re-attaching after a jump
    snapRange: 0.55,            // beyond hover+snapRange the surface is lost → fall
    upRate: 12,                 // 1/s, body up → surface normal
    climbRate: 8,               // 1/s, extra turn toward a wall directly ahead
    airUprightRate: 2.5,
    gravity: 9,
    airControl: 3,
    maxAirSpeed: 9,
    hardLanding: 6,
    pitchLimit: 1.45,
    projectIterations: 3,
    gradientStep: 0.2,
    minGradient: 0.35,
  },
  camera: {
    modes: ['full', 'reduced', 'horizon'],
    reducedBlend: 0.35,         // share of body up in Reduced Rotation
    upSmoothing: 10,            // 1/s
    posSmoothing: 30,           // 1/s
    eyeOffset: 0.06,            // above body centre along up
    bobAmplitude: 0.012,
    bobFrequency: 9,            // rad/s at walk speed
  },
  lamp: {
    // headlamp on top of the head, aimed straight ahead (slightly up): the floor right in front of the ant must not
    // swallow all the light; low decay keeps far walls readable (AB §34: light supports navigation)
    color: 0xfff1d6,
    intensity: 16,
    distance: 30,
    angle: 0.55,
    penumbra: 0.6,
    decay: 1.0,
    offset: [0, 0.1, 0.02],     // camera space
    aim: [0, 0.12, -1],         // camera space direction
  },
  world: {
    chunkCells: 40,             // cells per chunk edge
    voxel: 0.4,                 // units per cell → chunk = 16 units (ADD §37)
    maxWorkers: 3,
  },
  terrain: {
    strataFrequency: 2.2,       // rad per unit of height
    freshCutSeconds: 40,        // decay constant of the fresh-cut look (AB §7)
  },
  dig: {
    remeshInterval: 0.08,       // s between remesh flushes (ADD §36 batching)
    autosaveInterval: 3,        // s
    aimStep: 0.04,
    kick: 0.012,                // camera kick per bite
    debrisPerBite: 10,
  },
  ambient: {
    sky: 0x2a3440,
    ground: 0x0b0907,
    intensity: 0.22,
  },
  ui: {
    minTouchTarget: 44,         // CSS px, layout self-test
    selfTestDelayMs: 400,
  },
  scale: {
    antLength: 1.0,
    eyeHeight: 0.35,
    tunnelDiameter: 2.2,
  },
});
