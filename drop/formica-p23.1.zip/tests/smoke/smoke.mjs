// Browser smoke test (P12.4): real three.js from the CDN in headless Chromium (SwiftShader WebGL).
// Usage: node smoke.mjs <siteDir> <outDir>   (env THREE_STUB=path routes the CDN to a local stub for offline runs)
import { chromium } from 'playwright';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';

const SITE = path.resolve(process.argv[2] || '.'), OUT = path.resolve(process.argv[3] || 'smoke-out');
fs.mkdirSync(OUT, { recursive: true });
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
const srv = http.createServer((q, r) => {
  const p = path.join(SITE, decodeURIComponent(q.url.split('?')[0]).replace(/\/$/, '/index.html'));
  if (!p.startsWith(SITE) || !fs.existsSync(p)) { r.writeHead(404); return r.end(); }
  r.writeHead(200, { 'content-type': TYPES[path.extname(p)] || 'application/octet-stream' }); fs.createReadStream(p).pipe(r);
}).listen(8190);

const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const report = [];
async function session(name, url, fn) {
  const ctx = await browser.newContext({ viewport: { width: 800, height: 360 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon/.test(m.text())) errors.push('console: ' + m.text().slice(0, 300)); });
  if (process.env.THREE_STUB) await page.route('https://cdn.jsdelivr.net/**', (r) => r.fulfill({ contentType: 'text/javascript', body: fs.readFileSync(process.env.THREE_STUB, 'utf8') }));
  const res = { name, ok: true, errors, notes: [] };
  try {
    await page.goto(`http://localhost:8190/${url}`);
    await page.waitForFunction(() => window.__formicaWorldReady, null, { timeout: 90000 });
    await fn(page, res);
    const box = await page.evaluate(() => document.getElementById('error-box')?.innerText || '');
    if (box) errors.push('overlay: ' + box.slice(0, 500));
  } catch (e) { errors.push('exception: ' + e.message); }
  await page.screenshot({ path: path.join(OUT, `${name}.png`) }).catch(() => {});
  res.ok = errors.length === 0;
  report.push(res);
  await ctx.close();
}
const layout = (page) => page.evaluate(async () => { const m = await import(document.querySelector('script[type=module]').src.replace('main.js', 'ui/selftest.js')); return m.runLayoutSelfTest(44); });

await session('sandbox', '?autostart=1&sandbox=1&selftest=1', async (page, res) => {
  await page.waitForTimeout(4000);
  const info = await page.evaluate(() => { const L = window.__formica.level, a = window.__formica.app; return { fps: Math.round(a.fps), draws: a.renderer.info.render.calls, tris: a.renderer.info.render.triangles, chunks: L.world.stats.meshed, programs: a.renderer.info.programs?.length }; });
  res.notes.push(`fps ${info.fps} · draws ${info.draws} · tris ${info.tris} · chunks ${info.chunks} · shader programs ${info.programs}`);
  const l = await layout(page);
  if (l.problems.length) res.errors.push('layout: ' + l.problems.join('; '));
  res.notes.push(`layout checked ${l.checked}`);
});

await session('rite', '', async (page, res) => {
  await page.evaluate(() => document.querySelector('[data-hud="start-go"]').click());
  await page.waitForTimeout(1500);
  await page.waitForFunction(() => window.__formicaWorldReady, null, { timeout: 90000 });
  await page.evaluate(() => document.querySelector('[data-hud="start-go"]').click());
  // story time runs on the game clock (dt is clamped per frame), so on a slow software renderer (SwiftShader, ~4 fps)
  // the 13-second opening takes much longer in wall time — wait for the state, not for a fixed number of seconds
  await page.waitForFunction(() => window.__formica.level.story.phase === 'journey', null, { timeout: 150000 }).catch(() => {});
  const st = await page.evaluate(() => ({ phase: window.__formica.level.story.phase, done: window.__formica.level.story.s.done.join(',') }));
  res.notes.push(`story ${st.phase} (${st.done})`);
  if (st.phase !== 'journey') res.errors.push('opening did not reach the journey phase');
  const l = await layout(page);
  if (l.problems.length) res.errors.push('layout: ' + l.problems.join('; '));
});

await browser.close(); srv.close();
const md = ['## FORMICA browser smoke (real three.js)', '', '| session | result | notes |', '|---|---|---|',
  ...report.map((r) => `| ${r.name} | ${r.ok ? '✅' : '❌'} | ${[...r.notes, ...r.errors].join('<br>').replace(/\|/g, '/')} |`)].join('\n');
fs.writeFileSync(path.join(OUT, 'summary.md'), md);
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, md + '\n');
console.log(md);
process.exit(report.every((r) => r.ok) ? 0 : 1);
