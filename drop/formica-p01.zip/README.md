# FORMICA: HOMECOMING — web prototype

Three.js prototype of the core underground loop (see `docs/ROADMAP.md`).
Plain ES modules, no build step. Deployed to GitHub Pages by `.github/workflows/pages.yml`.

## One-time setup (from the phone)
1. Create repo `formica-homecoming`, add `.github/workflows/pages.yml` from this archive.
2. Settings → Pages → Source: **GitHub Actions**.

## Each phase
Upload `formica-pNN.zip` into the `drop/` folder (Add file → Upload files). The workflow takes the newest
`drop/formica-*.zip`, runs the unit tests and deploys. Build number = Actions run number (shown on the start screen).

## URL flags
`?debug=1` debug panel · `?selftest=1` always show the layout self-test badge · `?autostart=1` skip the start screen.

## Local run
Any static server from the repo root, e.g. `python3 -m http.server`, then open http://localhost:8000.
Tests: `node --test tests/*.test.mjs`.
