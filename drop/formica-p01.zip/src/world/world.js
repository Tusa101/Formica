// Main-thread world: owns the density field, dispatches generation/meshing to workers. No Three.js here;
// the renderer subscribes via onChunkMesh.
import { CONFIG } from '../config.js';
import { DensityField, ChunkState } from './field.js';
import { WorkerPool } from './pool.js';
import { buildLevelField } from './levelfield.js';

export class World {
  constructor(level) {
    const W = CONFIG.world;
    this.level = level;
    this.N = W.chunkCells;
    this.voxel = W.voxel;
    this.field = new DensityField(this.N, this.voxel);
    this.analytic = buildLevelField(level); // zone names / debugging only — gameplay reads this.field
    const threads = Math.max(1, Math.min(W.maxWorkers, (navigator.hardwareConcurrency || 2) - 1));
    this.pool = new WorkerPool(new URL('./worker.js', import.meta.url), threads);
    this.threads = threads;
    this.onChunkMesh = null;
    this.stats = { chunks: 0, meshed: 0, triangles: 0, genMs: 0, meshMs: 0, loadMs: 0 };
  }

  async load(onProgress = () => {}) {
    const { min, max } = this.level.chunks;
    const size = this.field.size;
    const sp = this.level.spawn.pos;
    const list = [];
    for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++) {
      const d = Math.hypot((cx + 0.5) * size - sp[0], (cy + 0.5) * size - sp[1], (cz + 0.5) * size - sp[2]);
      list.push({ cx, cy, cz, d });
    }
    list.sort((a, b) => a.d - b.d); // nearest first
    const t0 = performance.now();
    let done = 0;
    onProgress(0, list.length);
    await Promise.all(list.map(async ({ cx, cy, cz }) => {
      const r = await this.pool.run({ type: 'generate', levelId: this.level.id, cx, cy, cz, N: this.N, voxel: this.voxel });
      const chunk = this.field.set(cx, cy, cz, { density: r.density, material: r.material, allSolid: r.allSolid, allEmpty: r.allEmpty });
      this.stats.chunks++;
      this.stats.genMs += r.genMs;
      if (r.mesh) {
        chunk.state = ChunkState.MESHED;
        this.stats.meshed++;
        this.stats.meshMs += r.meshMs;
        this.stats.triangles += r.mesh.triangleCount;
        if (this.onChunkMesh) this.onChunkMesh(chunk, r.mesh);
        chunk.state = ChunkState.ACTIVE;
      }
      onProgress(++done, list.length);
    }));
    this.stats.loadMs = performance.now() - t0;
  }

  zoneAt(p) { return this.analytic.zoneAt(p.x, p.y, p.z); }
  densityAt(p) { return this.field.densityAt(p.x, p.y, p.z); }
}
