// Turns a level description (levels/*.js) into pure density + material functions.
// Density > 0 = solid, < 0 = empty (ADD §34). Used by workers and by Node tests.
import { createNoise } from './noise.js';
import { sdCavity, cavityBounds, smin } from './sdf.js';
import { MAT } from '../data/materials.js';

export const SOLID_FAR = 3.0; // density reported far inside rock

export function buildLevelField(level) {
  const n = createNoise(level.seed);
  const blend = level.blend ?? 1.0;
  const nz = level.noise ?? { amp: 0.55, freq: 0.28, detailAmp: 0.2, detailFreq: 0.9, band: 2.5 };
  const pad = blend + nz.amp + nz.detailAmp + 0.5;
  const cavs = level.cavities.map((c) => ({ c, b: cavityBounds(c, pad) }));

  function cavityDistance(x, y, z) {
    let d = SOLID_FAR;
    for (let i = 0; i < cavs.length; i++) {
      const { c, b } = cavs[i];
      if (x < b.min[0] || x > b.max[0] || y < b.min[1] || y > b.max[1] || z < b.min[2] || z > b.max[2]) continue;
      d = smin(d, sdCavity(c, x, y, z), blend);
    }
    return d;
  }

  function density(x, y, z) {
    let d = cavityDistance(x, y, z);
    if (d > -nz.band && d < nz.band) {
      d += n.fbm(x * nz.freq, y * nz.freq, z * nz.freq) * nz.amp + n.noise3(x * nz.detailFreq, y * nz.detailFreq, z * nz.detailFreq) * nz.detailAmp;
    }
    return d;
  }

  const g = level.geology;
  function material(x, y, z) {
    const yy = y + n.fbm(x * 0.05, y * 0.05 + 100, z * 0.05, 2) * g.warp;
    if (yy > g.soilTop) return MAT.SOIL;
    if (yy > g.clayTop) return MAT.CLAY;
    if (yy > g.sandTop) return n.noise3(x * 0.12 + 50, y * 0.3, z * 0.12) > g.sandLens ? MAT.SAND : MAT.CLAY;
    return MAT.LIMESTONE;
  }

  /** Name of the zone containing the point (nearest named cavity within `range`), or null. */
  function zoneAt(x, y, z, range = 0.6) {
    let best = null, bd = range;
    for (const { c } of cavs) {
      if (!c.name) continue;
      const d = sdCavity(c, x, y, z);
      if (d < bd) { bd = d; best = c.name; }
    }
    return best;
  }

  return { density, material, cavityDistance, zoneAt };
}
