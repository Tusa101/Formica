// Chunked density field (ADD §34, §37). Pure JS: no Three.js.
// A chunk of N cells stores (N+2)^3 samples: indices -1..N on every axis (1-sample halo),
// so meshing and normals never need neighbour chunks and borders are seamless.

export const ChunkState = Object.freeze({ UNLOADED: 0, DATA_ONLY: 1, MESHED: 2, ACTIVE: 3 });

export const chunkKey = (cx, cy, cz) => `${cx},${cy},${cz}`;

export function sampleIndex(N, i, j, k) {
  const S = N + 2;
  return (i + 1) + S * ((j + 1) + S * (k + 1));
}

/** Fills a chunk from world-space functions. Deterministic → neighbours agree on shared samples. */
export function generateChunk(cx, cy, cz, N, voxel, densityFn, materialFn) {
  const S = N + 2;
  const density = new Float32Array(S * S * S);
  const material = new Uint8Array(S * S * S);
  const ox = cx * N, oy = cy * N, oz = cz * N;
  let solid = 0, empty = 0, idx = 0;
  for (let k = -1; k <= N; k++) {
    const z = (oz + k) * voxel;
    for (let j = -1; j <= N; j++) {
      const y = (oy + j) * voxel;
      for (let i = -1; i <= N; i++, idx++) {
        const x = (ox + i) * voxel;
        const d = densityFn(x, y, z);
        density[idx] = d;
        if (d > 0) { solid++; material[idx] = materialFn(x, y, z); } else empty++;
      }
    }
  }
  return { density, material, allSolid: empty === 0, allEmpty: solid === 0 };
}

/** Main-thread store of chunk data + world-space queries (collision in P02, digging in P03). */
export class DensityField {
  constructor(N, voxel) {
    this.N = N; this.voxel = voxel; this.size = N * voxel;
    this.chunks = new Map();
  }

  set(cx, cy, cz, data) {
    const key = chunkKey(cx, cy, cz);
    const c = { key, cx, cy, cz, state: ChunkState.DATA_ONLY, ...data };
    this.chunks.set(key, c);
    return c;
  }

  get(cx, cy, cz) { return this.chunks.get(chunkKey(cx, cy, cz)); }

  /** Density at a sample (integer world-sample coords). Missing chunk = solid rock. */
  sampleAt(gx, gy, gz) {
    const N = this.N;
    const cx = Math.floor(gx / N), cy = Math.floor(gy / N), cz = Math.floor(gz / N);
    const c = this.chunks.get(chunkKey(cx, cy, cz));
    if (!c) return 3.0;
    return c.density[sampleIndex(N, gx - cx * N, gy - cy * N, gz - cz * N)];
  }

  /** Trilinear density at a world position. */
  densityAt(x, y, z) {
    const v = this.voxel;
    const fx = x / v, fy = y / v, fz = z / v;
    const x0 = Math.floor(fx), y0 = Math.floor(fy), z0 = Math.floor(fz);
    const tx = fx - x0, ty = fy - y0, tz = fz - z0;
    const s = (i, j, k) => this.sampleAt(x0 + i, y0 + j, z0 + k);
    const l = (a, b, t) => a + (b - a) * t;
    return l(
      l(l(s(0, 0, 0), s(1, 0, 0), tx), l(s(0, 1, 0), s(1, 1, 0), tx), ty),
      l(l(s(0, 0, 1), s(1, 0, 1), tx), l(s(0, 1, 1), s(1, 1, 1), tx), ty),
      tz);
  }

  /** Surface normal (points into empty space) via central differences. */
  normalAt(x, y, z, h = this.voxel * 0.5) {
    const gx = this.densityAt(x + h, y, z) - this.densityAt(x - h, y, z);
    const gy = this.densityAt(x, y + h, z) - this.densityAt(x, y - h, z);
    const gz = this.densityAt(x, y, z + h) - this.densityAt(x, y, z - h);
    const len = Math.hypot(gx, gy, gz) || 1;
    return [-gx / len, -gy / len, -gz / len];
  }

  /** First surface point below `pos` (steps down through empty space), or null. */
  dropToSurface(pos, maxDist = 20) {
    const step = this.voxel * 0.5;
    const [x, y0, z] = pos;
    if (this.densityAt(x, y0, z) > 0) return null;
    for (let t = step; t <= maxDist; t += step) {
      if (this.densityAt(x, y0 - t, z) > 0) {
        let lo = t - step, hi = t; // bisection for the zero crossing
        for (let i = 0; i < 8; i++) { const m = (lo + hi) / 2; if (this.densityAt(x, y0 - m, z) > 0) hi = m; else lo = m; }
        return [x, y0 - lo, z];
      }
    }
    return null;
  }
}
