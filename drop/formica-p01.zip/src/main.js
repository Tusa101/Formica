import { CONFIG } from './config.js';
import { App } from './core/app.js';
import { Input } from './core/input.js';
import { Shell } from './ui/shell.js';
import { TouchControls } from './ui/touch.js';
import { Hud, DebugPanel } from './ui/hud.js';
import { runLayoutSelfTest } from './ui/selftest.js';
import { TestTunnelsScene } from './scenes/test-tunnels.js';
import { TEST_TUNNELS } from './levels/test-tunnels.js';

const params = new URLSearchParams(location.search);
const touch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
document.body.classList.toggle('is-touch', touch);

const stage = document.getElementById('stage');
const uiRoot = document.getElementById('ui');

const app = new App(stage, { touch });
const input = new Input(app.canvas);
const hud = new Hud(uiRoot);
const debug = new DebugPanel(uiRoot, app, input);
const touchUI = touch ? new TouchControls(uiRoot, input, { onMenu: () => shell.showPause() }) : null;

const persistentSelfTest = params.get('selftest') === '1';
function selfTest() {
  const result = runLayoutSelfTest(CONFIG.ui.minTouchTarget);
  debug.setLayout(result);
  hud.showSelfTest(result, persistentSelfTest);
  window.__formicaLayout = result; // read by headless smoke tests
  return result;
}
let selfTestTimer = 0;
const scheduleSelfTest = () => { clearTimeout(selfTestTimer); selfTestTimer = setTimeout(selfTest, CONFIG.ui.selfTestDelayMs); };
addEventListener('resize', scheduleSelfTest);

function setPlaying(playing) {
  input.enabled = playing;
  if (!playing) input.reset();
  hud.setVisible(playing);
  touchUI?.setVisible(playing);
  scheduleSelfTest();
}

const shell = new Shell(uiRoot, {
  touch,
  onStart: () => { setPlaying(true); input.requestPointerLock(); },
  onPause: () => setPlaying(false),
  onResume: () => { setPlaying(true); input.requestPointerLock(); },
  onSelfTest: () => { debug.el.hidden = false; selfTest(); },
  onDebug: () => debug.toggle(),
});

input.on((type, value) => {
  if (type === 'press' && value === 'debug') debug.toggle();
  // Desktop: leaving pointer lock (Esc) opens the pause menu.
  if (type === 'pointerlock' && value === false && !touch && shell.started && !shell.isPaused) shell.showPause();
});
addEventListener('keydown', (e) => { if (e.code === 'Escape' && touch) shell.showPause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) shell.showPause(); });

const level = new TestTunnelsScene(app, input, TEST_TUNNELS);
app.scene = level.scene;
app.add({ preUpdate: () => input.update() });
app.add(level);
app.add({ lateUpdate: () => input.endFrame() });
app.add(debug);
debug.extra = () => level.debugText();

let lastZone;
app.add({ update: () => {
  if (level.zone !== lastZone) { lastZone = level.zone; hud.setMessage(level.zone || 'Test Tunnels'); }
} });

hud.setMode('NOCLIP');
hud.setMessage('Test Tunnels');
setPlaying(false);
if (params.get('debug') === '1') debug.toggle();

level.load((done, total) => shell.setLoading(done, total)).then(() => {
  shell.setReady();
  window.__formicaWorldReady = true;
  if (params.get('autostart') === '1') shell.goBtn.click();
}).catch((e) => window.__formicaError?.('World generation failed: ' + (e.stack || e.message || e)));

app.start();
window.__formicaReady = true;
