// Unified action layer: keyboard/mouse and touch feed the same actions.
import { CONFIG } from '../config.js';
import { keyVector } from './stick.js';

export const ACTIONS = ['jump', 'dig', 'use', 'scan', 'map', 'debug', 'up', 'down', 'fast'];

const KEYMAP = {
  Space: 'jump', KeyE: 'use', KeyQ: 'scan', KeyM: 'map',
  F3: 'debug', Backquote: 'debug',
  KeyR: 'up', KeyF: 'down', ShiftLeft: 'fast', ShiftRight: 'fast',
};
const MOVE_KEYS = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight']);

export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.enabled = false;
    this.source = matchMedia('(pointer: coarse)').matches ? 'touch' : 'keyboard';
    this.keys = new Set();
    this.touchMove = { x: 0, y: 0, mag: 0 };
    this.move = { x: 0, y: 0, mag: 0 };
    this.look = { dx: 0, dy: 0 };
    this.held = new Set();
    this.pressed = new Set();
    this.touchHeld = new Set();
    this.pointerLocked = false;
    this.listeners = new Set();
    this._bind();
  }

  _bind() {
    addEventListener('keydown', (e) => {
      if (e.repeat) return;
      this.source = 'keyboard';
      if (MOVE_KEYS.has(e.code)) this.keys.add(e.code);
      const a = KEYMAP[e.code];
      if (a) { this._press(a); e.preventDefault(); }
    });
    addEventListener('keyup', (e) => {
      this.keys.delete(e.code);
      const a = KEYMAP[e.code];
      if (a) this._release(a);
    });
    addEventListener('blur', () => this.reset());

    this.canvas.addEventListener('mousedown', (e) => {
      if (e.pointerType === 'touch') return;
      this.source = 'keyboard';
      if (!this.enabled) return;
      if (!this.pointerLocked) { this.requestPointerLock(); return; }
      if (e.button === 0) this._press('dig');
      if (e.button === 2) this._press('use');
    });
    addEventListener('mouseup', (e) => {
      if (e.button === 0) this._release('dig');
      if (e.button === 2) this._release('use');
    });
    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    addEventListener('mousemove', (e) => {
      if (!this.pointerLocked || !this.enabled) return;
      const s = CONFIG.input.mouseSensitivity;
      this.look.dx += e.movementX * s;
      this.look.dy += e.movementY * s * (CONFIG.input.invertY ? -1 : 1);
    });
    document.addEventListener('pointerlockchange', () => {
      this.pointerLocked = document.pointerLockElement === this.canvas;
      if (!this.pointerLocked) this.reset();
      this._emit('pointerlock', this.pointerLocked);
    });
  }

  requestPointerLock() {
    if (this.source === 'touch' || !this.canvas.requestPointerLock) return;
    try {
      const p = this.canvas.requestPointerLock();
      if (p && p.catch) p.catch(() => {});
    } catch { /* ignored: some browsers throw without a gesture */ }
  }

  // ---- touch feed (called by ui/touch.js) ----
  setTouchMove(v) { this.source = 'touch'; this.touchMove = v; }
  addTouchLook(dxPx, dyPx) {
    this.source = 'touch';
    const s = CONFIG.input.touchLookSensitivity;
    this.look.dx += dxPx * s;
    this.look.dy += dyPx * s * (CONFIG.input.invertY ? -1 : 1);
  }
  touchButton(action, down) {
    this.source = 'touch';
    if (down) { this.touchHeld.add(action); this._press(action); }
    else { this.touchHeld.delete(action); this._release(action); }
  }

  // ---- per-frame API ----
  update() {
    const k = this.keys;
    const kv = keyVector(
      k.has('KeyA') || k.has('ArrowLeft'), k.has('KeyD') || k.has('ArrowRight'),
      k.has('KeyS') || k.has('ArrowDown'), k.has('KeyW') || k.has('ArrowUp'));
    this.move = kv.mag > 0 ? kv : this.touchMove;
  }
  isDown(a) { return this.enabled && this.held.has(a); }
  wasPressed(a) { return this.enabled && this.pressed.has(a); }
  consumeLook() {
    const l = { dx: this.look.dx, dy: this.look.dy };
    this.look.dx = 0; this.look.dy = 0;
    return this.enabled ? l : { dx: 0, dy: 0 };
  }
  endFrame() { this.pressed.clear(); }
  reset() {
    this.keys.clear(); this.held.clear(); this.pressed.clear(); this.touchHeld.clear();
    this.touchMove = { x: 0, y: 0, mag: 0 };
    this.look.dx = 0; this.look.dy = 0;
  }

  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  _emit(type, value) { for (const fn of this.listeners) fn(type, value); }
  _press(a) { if (!this.held.has(a)) this.pressed.add(a); this.held.add(a); this._emit('press', a); }
  _release(a) { this.held.delete(a); }
}
