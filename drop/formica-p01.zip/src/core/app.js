// Renderer, fixed-step loop, resize and pause handling.
import * as THREE from 'three';
import { CONFIG } from '../config.js';

export class App {
  constructor(container, { touch }) {
    const r = CONFIG.render;
    this.touch = touch;
    this.renderer = new THREE.WebGLRenderer({
      antialias: touch ? r.antialiasTouch : r.antialiasDesktop,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, touch ? r.maxPixelRatioTouch : r.maxPixelRatio));
    this.renderer.setClearColor(r.clearColor, 1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.debug.onShaderError = (gl, program, vs, fs) => {
      const log = [gl.getProgramInfoLog(program), gl.getShaderInfoLog(vs), gl.getShaderInfoLog(fs)].filter(Boolean).join('\n');
      window.__formicaError?.('Shader compile error:\n' + log.slice(0, 1500));
    };
    this.canvas = this.renderer.domElement;
    this.canvas.id = 'game-canvas';
    container.appendChild(this.canvas);

    this.camera = new THREE.PerspectiveCamera(r.fov, 1, r.near, r.far);
    this.scene = null;
    this.systems = [];          // objects with fixedUpdate(dt) / update(dt) / onResize(w,h)
    this.running = false;
    this.paused = false;
    this.acc = 0;
    this.last = 0;
    this.frameMs = 0;
    this.fps = 0;
    this._fpsAcc = 0; this._fpsFrames = 0;

    this._resize = this._resize.bind(this);
    new ResizeObserver(this._resize).observe(container);
    addEventListener('orientationchange', () => setTimeout(this._resize, 150));
    document.addEventListener('visibilitychange', () => { this.paused = document.hidden; this.last = 0; });
    this._resize();
  }

  add(system) { this.systems.push(system); if (system.onResize) system.onResize(this.width, this.height); return system; }

  _resize() {
    const el = this.canvas.parentElement;
    this.width = Math.max(1, el.clientWidth);
    this.height = Math.max(1, el.clientHeight);
    this.renderer.setSize(this.width, this.height, false);
    this.camera.aspect = this.width / this.height;
    this.camera.updateProjectionMatrix();
    for (const s of this.systems) if (s.onResize) s.onResize(this.width, this.height);
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.renderer.setAnimationLoop((t) => this._frame(t));
  }

  _frame(t) {
    if (this.paused) { this.last = 0; return; }
    const now = t / 1000;
    let dt = this.last ? now - this.last : CONFIG.sim.step;
    this.last = now;
    dt = Math.min(dt, 0.25);
    const t0 = performance.now();

    for (const s of this.systems) if (s.preUpdate) s.preUpdate(dt);
    const step = CONFIG.sim.step;
    this.acc += dt;
    let steps = 0;
    while (this.acc >= step && steps < CONFIG.sim.maxStepsPerFrame) {
      for (const s of this.systems) if (s.fixedUpdate) s.fixedUpdate(step);
      this.acc -= step; steps++;
    }
    if (steps === CONFIG.sim.maxStepsPerFrame) this.acc = 0; // drop backlog instead of spiralling
    for (const s of this.systems) if (s.update) s.update(dt);
    if (this.scene) this.renderer.render(this.scene, this.camera);
    for (const s of this.systems) if (s.lateUpdate) s.lateUpdate(dt);

    this.frameMs = performance.now() - t0;
    this._fpsAcc += dt; this._fpsFrames++;
    if (this._fpsAcc >= 0.5) { this.fps = this._fpsFrames / this._fpsAcc; this._fpsAcc = 0; this._fpsFrames = 0; }
  }
}
