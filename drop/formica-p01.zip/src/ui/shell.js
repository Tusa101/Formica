// Start screen, pause menu, fullscreen, rotate hint.
import { BUILD, PHASE } from '../config.js';

const CONTROLS_DESKTOP = 'WASD move · mouse look · R/F up/down · Shift fast · F3 debug · Esc pause';
const CONTROLS_TOUCH = 'Left: move · Right: look · JUMP up · DIG down (noclip)';

export class Shell {
  constructor(root, { touch, onStart, onResume, onPause, onSelfTest, onDebug }) {
    this.touch = touch;
    this.root = root;
    this.cb = { onStart, onResume, onPause, onSelfTest, onDebug };
    this.started = false;

    this.start = this._overlay('start-screen', `
      <div class="panel">
        <div class="title">FORMICA<span>HOMECOMING</span></div>
        <div class="sub">web prototype · ${PHASE} · build ${BUILD}</div>
<div class="btns">
        <button class="pbtn primary" data-hud="start-go" data-hud-group="start">START</button>
        <button class="pbtn" data-hud="start-fs" data-hud-group="start" data-fs>FULLSCREEN</button>
        </div>
        <div class="hint">${touch ? CONTROLS_TOUCH : CONTROLS_DESKTOP}</div>
      </div>`);
    this.pause = this._overlay('pause-screen', `
      <div class="panel">
        <div class="title small">PAUSED</div>
        <div class="btns">
        <button class="pbtn primary" data-hud="pause-resume" data-hud-group="pause">RESUME</button>
        <button class="pbtn" data-hud="pause-fs" data-hud-group="pause" data-fs>FULLSCREEN</button>
        <button class="pbtn" data-hud="pause-selftest" data-hud-group="pause">LAYOUT SELF-TEST</button>
        <button class="pbtn" data-hud="pause-debug" data-hud-group="pause">DEBUG PANEL</button>
        </div>
        <div class="hint">${touch ? CONTROLS_TOUCH : CONTROLS_DESKTOP}</div>
        <div class="sub">build ${BUILD}</div>
      </div>`);
    this.pause.hidden = true;
    this.rotate = this._overlay('rotate-hint', `
      <div class="panel"><div class="rot-icon">⟳</div><div>Rotate the phone to landscape</div>
      <button class="pbtn" data-hud="rotate-dismiss">CONTINUE ANYWAY</button></div>`);
    this.rotate.hidden = true;
    this.rotateDismissed = false;

    this.goBtn = this.start.querySelector('.primary');
    this.goBtn.addEventListener('click', () => { if (this.ready) this._go(); });
    this.ready = false;
    this.setLoading(0, 1);
    this.pause.querySelector('.primary').addEventListener('click', () => this.resume());
    this.pause.querySelector('[data-hud="pause-selftest"]').addEventListener('click', () => this.cb.onSelfTest());
    this.pause.querySelector('[data-hud="pause-debug"]').addEventListener('click', () => this.cb.onDebug());
    this.rotate.querySelector('button').addEventListener('click', () => { this.rotateDismissed = true; this._checkRotate(); });
    for (const b of root.querySelectorAll('[data-fs]')) {
      if (!document.documentElement.requestFullscreen) b.hidden = true;
      b.addEventListener('click', () => this.toggleFullscreen());
    }
    addEventListener('resize', () => this._checkRotate());
    this._checkRotate();
  }

  _overlay(id, html) {
    const el = document.createElement('div');
    el.id = id; el.className = 'overlay'; el.innerHTML = html;
    this.root.appendChild(el);
    return el;
  }

  _go() {
    this.started = true;
    this.start.hidden = true;
    if (this.touch) this.enterFullscreen();
    this.cb.onStart();
  }

  setLoading(done, total) {
    this.goBtn.disabled = true;
    this.goBtn.textContent = `GENERATING ${Math.round((done / Math.max(total, 1)) * 100)}%`;
  }

  setReady() {
    this.ready = true;
    this.goBtn.disabled = false;
    this.goBtn.textContent = 'START';
  }

  showPause() {
    if (!this.started || !this.pause.hidden) return;
    this.pause.hidden = false;
    this.cb.onPause();
  }

  resume() {
    this.pause.hidden = true;
    this.cb.onResume();
  }

  get isPaused() { return !this.pause.hidden; }

  async enterFullscreen() {
    try {
      if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
      }
      if (screen.orientation?.lock) await screen.orientation.lock('landscape').catch(() => {});
    } catch { /* not allowed on this device — fine */ }
  }

  toggleFullscreen() {
    if (document.fullscreenElement) document.exitFullscreen?.();
    else this.enterFullscreen();
  }

  _checkRotate() {
    const portrait = innerHeight > innerWidth;
    this.rotate.hidden = !(this.touch && portrait && !this.rotateDismissed);
  }
}
