// Touch controls: dynamic left stick, right-side look drag, action buttons.
import { CONFIG } from '../config.js';
import { stickVector, clampKnob } from '../core/stick.js';

const BUTTONS = [
  { action: 'dig', label: 'DIG', cls: 'btn-dig' },
  { action: 'jump', label: 'JUMP', cls: 'btn-jump' },
  { action: 'use', label: 'USE', cls: 'btn-use' },
  { action: 'scan', label: 'SCAN', cls: 'btn-scan' },
  { action: 'map', label: 'MAP', cls: 'btn-map' },
];

export class TouchControls {
  constructor(root, input, { onMenu }) {
    this.input = input;
    this.el = document.createElement('div');
    this.el.id = 'touch-layer';
    this.el.innerHTML = `
      <div class="stick" hidden><div class="stick-knob"></div></div>
      <div class="touch-buttons">
        ${BUTTONS.map((b) => `<button class="tbtn ${b.cls}" data-action="${b.action}" data-hud="btn-${b.action}">${b.label}</button>`).join('')}
      </div>
      <button class="tbtn btn-menu" data-hud="btn-menu" aria-label="Menu">II</button>`;
    root.appendChild(this.el);
    this.stickEl = this.el.querySelector('.stick');
    this.knobEl = this.el.querySelector('.stick-knob');
    this.stickId = null; this.stickOrigin = null;
    this.lookId = null; this.lookLast = null;

    for (const btn of this.el.querySelectorAll('[data-action]')) {
      const a = btn.dataset.action;
      const down = (e) => { e.preventDefault(); e.stopPropagation(); btn.setPointerCapture?.(e.pointerId); btn.classList.add('on'); input.touchButton(a, true); };
      const up = (e) => { e.preventDefault(); btn.classList.remove('on'); input.touchButton(a, false); };
      btn.addEventListener('pointerdown', down);
      btn.addEventListener('pointerup', up);
      btn.addEventListener('pointercancel', up);
      btn.addEventListener('lostpointercapture', up);
    }
    this.el.querySelector('.btn-menu').addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); onMenu(); });

    this.el.addEventListener('pointerdown', (e) => this._down(e));
    this.el.addEventListener('pointermove', (e) => this._move(e));
    this.el.addEventListener('pointerup', (e) => this._up(e));
    this.el.addEventListener('pointercancel', (e) => this._up(e));
  }

  setVisible(v) { this.el.hidden = !v; if (!v) this._clear(); }

  _down(e) {
    if (e.pointerType === 'mouse') return;
    e.preventDefault();
    const leftSide = e.clientX < innerWidth * 0.45;
    if (leftSide && this.stickId === null) {
      this.stickId = e.pointerId;
      this.stickOrigin = { x: e.clientX, y: e.clientY };
      this.stickEl.hidden = false;
      this.stickEl.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
      this.knobEl.style.transform = 'translate(-50%, -50%)';
    } else if (!leftSide && this.lookId === null) {
      this.lookId = e.pointerId;
      this.lookLast = { x: e.clientX, y: e.clientY };
    } else return;
    this.el.setPointerCapture?.(e.pointerId);
  }

  _move(e) {
    if (e.pointerId === this.stickId) {
      const c = CONFIG.input;
      const dx = e.clientX - this.stickOrigin.x, dy = e.clientY - this.stickOrigin.y;
      const k = clampKnob(dx, dy, c.stickRadius);
      this.knobEl.style.transform = `translate(calc(-50% + ${k.x}px), calc(-50% + ${k.y}px))`;
      this.input.setTouchMove(stickVector(dx, dy, c.stickRadius, c.stickDeadzone, c.stickExponent));
    } else if (e.pointerId === this.lookId) {
      this.input.addTouchLook(e.clientX - this.lookLast.x, e.clientY - this.lookLast.y);
      this.lookLast = { x: e.clientX, y: e.clientY };
    }
  }

  _up(e) {
    if (e.pointerId === this.stickId) {
      this.stickId = null; this.stickEl.hidden = true;
      this.input.setTouchMove({ x: 0, y: 0, mag: 0 });
    } else if (e.pointerId === this.lookId) {
      this.lookId = null;
    }
  }

  _clear() {
    this.stickId = null; this.lookId = null; this.stickEl.hidden = true;
    this.input.touchMove = { x: 0, y: 0, mag: 0 };
  }
}
