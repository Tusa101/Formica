// "Test Tunnels" — technical test level for P01–P05 (ADD §77, §79; GDD §65-A).
// Pure data. Units: ant metres (ant ≈ 1.0 long). Chunk grid covers x,z ∈ [-32, 32), y ∈ [-16, 16).
export const TEST_TUNNELS = {
  id: 'test-tunnels',
  seed: 1337,
  blend: 1.0,
  chunks: { min: [-2, -1, -2], max: [1, 0, 1] }, // inclusive chunk index range
  geology: { warp: 2.5, soilTop: 7.5, clayTop: 1.5, sandTop: -5, sandLens: 0.18 },
  spawn: { pos: [-12.5, -1.2, 1.5], yaw: -Math.PI / 2, pitch: -0.1 },

  cavities: [
    // ADD §77: Room A | solid wall (~2.5) | Room B. The wall is dug through in P03.
    { name: 'Room A', type: 'ellipsoid', c: [-12.5, 0, 0], r: [5, 3, 5] },
    { name: 'Room B', type: 'ellipsoid', c: [-0.5, 0, 0], r: [4.5, 3.2, 4.5] },
    // Long way round A → B (south loop)
    { name: 'South Loop', type: 'tube', r: 1.1, points: [[-13, -1.6, -3.5], [-15, -1.4, -12], [-6, -0.8, -19], [4, -1.2, -13], [1, -1.6, -3.5]] },
    // Vertical shaft up from Room B to the upper gallery
    { name: 'Shaft', type: 'capsule', a: [2.2, 1.5, 2], b: [2.2, 12, 2], r: 1.3 },
    { name: 'Upper Gallery', type: 'tube', r: 1.5, points: [[2.2, 12, 2], [10, 12.5, 3], [16, 11.5, 6]] },
    // Wide hall with a pit in the floor: crossing it means walking on walls / ceiling
    { name: 'Pit Hall', type: 'ellipsoid', c: [20, 7, 10], r: [6.5, 4, 6.5] },
    { name: 'The Pit', type: 'capsule', a: [20, 5, 10], b: [20, -10, 10], r: 3.2 },
    { name: 'Far Ledge', type: 'ellipsoid', c: [21, 6.5, 18.5], r: [3, 2.2, 3] },
    // Low tunnel from the pit bottom back to Room B (closes the vertical loop)
    { name: 'Deep Tunnel', type: 'tube', r: 1.1, points: [[20, -10, 10], [12, -6, 6], [4, -2.2, 1.5]] },
    // Narrow squeeze (Ø 1.2) from Room A to a hidden niche
    { name: 'Squeeze', type: 'tube', r: 0.6, points: [[-13, -0.5, 4.2], [-16.5, -0.3, 13], [-8, -0.2, 19]] },
    { name: 'Niche', type: 'ellipsoid', c: [-5.5, 0, 20], r: [2.6, 1.8, 2.6] },
  ],

  // Landmarks. Every light has a physical source (AB §10). Props are GREYBOX until PIPE §43 assets exist.
  lights: [
    { kind: 'ritual-lamp', pos: [-15.5, -2.4, -1.5], color: 0xe0a64a, intensity: 5, distance: 11 },
    { kind: 'fungus', pos: [1.5, -2.6, -2.5], color: 0x5fd0b0, intensity: 5, distance: 9 },
    { kind: 'fungus', pos: [21, 4.6, 19], color: 0x5fd0b0, intensity: 6, distance: 10 },
    { kind: 'fungus', pos: [-5.2, -1.4, 21], color: 0x7fd07a, intensity: 4, distance: 7 },
  ],
};
