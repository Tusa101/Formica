// P01 scene: volumetric Test Tunnels, flown in noclip. P02 replaces noclip with the ant controller.
import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { World } from '../world/world.js';
import { ChunkMeshes } from '../render/chunk-meshes.js';
import { createTerrainMaterial } from '../render/terrain-material.js';
import { PROP_BUILDERS } from '../props/greybox.js';
import { NoclipController } from '../player/noclip.js';

export class TestTunnelsScene {
  constructor(app, input, level) {
    this.app = app; this.level = level;
    const scene = (this.scene = new THREE.Scene());
    const R = CONFIG.render, A = CONFIG.ambient;
    scene.fog = new THREE.Fog(R.fogColor, R.fogNear, R.fogFar);
    scene.add(new THREE.HemisphereLight(A.sky, A.ground, A.intensity));

    const L = CONFIG.lamp;
    this.lamp = new THREE.SpotLight(L.color, L.intensity, L.distance, L.angle, L.penumbra, L.decay);
    this.lamp.target.position.set(0, 0, -1);
    app.camera.add(this.lamp, this.lamp.target);
    scene.add(app.camera);

    this.world = new World(level);
    this.terrain = new ChunkMeshes(scene, createTerrainMaterial());
    this.world.onChunkMesh = (chunk, mesh) => this.terrain.upsert(chunk, mesh);
    this.player = new NoclipController(app.camera, input, level.spawn);
    this.zone = null;
    this._zoneT = 0;
  }

  async load(onProgress) {
    await this.world.load(onProgress);
    this._placeLandmarks();
  }

  _placeLandmarks() {
    this.level.lights.forEach((l, i) => {
      const hit = this.world.field.dropToSurface(l.pos, 12) || l.pos;
      const base = new THREE.Vector3(...hit);
      const build = PROP_BUILDERS[l.kind];
      if (build) { const prop = build(i, l); prop.position.copy(base); this.scene.add(prop); }
      const light = new THREE.PointLight(l.color, l.intensity, l.distance, 1.8);
      light.position.copy(base).add(new THREE.Vector3(0, l.kind === 'ritual-lamp' ? 1.3 : 0.7, 0));
      this.scene.add(light);
    });
  }

  fixedUpdate(dt) { this.player.fixedUpdate(dt); }

  update(dt) {
    this.player.update(dt);
    this._zoneT += dt;
    if (this._zoneT > 0.3) { this._zoneT = 0; this.zone = this.world.zoneAt(this.player.pos); }
  }

  debugText() {
    const p = this.player.pos, s = this.world.stats;
    const inside = this.world.densityAt(p) > 0 ? ' (in rock)' : '';
    return `cam ${p.x.toFixed(1)},${p.y.toFixed(1)},${p.z.toFixed(1)}${inside}
zone ${this.zone || '-'}
chunks ${s.meshed}/${s.chunks} meshed · ${this.world.threads} workers
terrain ${s.triangles} tris · load ${s.loadMs.toFixed(0)}ms
gen ${s.genMs.toFixed(0)}ms · mesh ${s.meshMs.toFixed(0)}ms (worker sum)`;
  }
}
