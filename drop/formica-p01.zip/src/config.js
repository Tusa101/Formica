// All tunable parameters live here. Units: 1 world unit = 1 "ant metre" (ant body ≈ 1.0).
// BUILD is replaced by the deploy workflow; locally it stays "dev".

export const BUILD = '__BUILD__'.startsWith('__') ? 'dev' : '__BUILD__';
export const PHASE = 'P01';

const deepFreeze = (o) => {
  for (const v of Object.values(o)) if (v && typeof v === 'object') deepFreeze(v);
  return Object.freeze(o);
};

export const CONFIG = deepFreeze({
  render: {
    maxPixelRatio: 2,
    maxPixelRatioTouch: 1.5,
    antialiasDesktop: true,
    antialiasTouch: false,
    fov: 75,
    near: 0.02,
    far: 120,
    clearColor: 0x07090b,
    fogColor: 0x07090b,
    fogNear: 4,
    fogFar: 38,
  },
  sim: {
    step: 1 / 60,
    maxStepsPerFrame: 5,
  },
  input: {
    mouseSensitivity: 0.0022,   // rad per px
    touchLookSensitivity: 0.0055, // rad per CSS px
    invertY: false,
    stickRadius: 56,            // CSS px
    stickDeadzone: 0.12,        // 0..1
    stickExponent: 1.6,         // response curve
  },
  noclip: {
    speed: 3.2,                 // units / s
    fastMultiplier: 2.5,
    verticalSpeed: 2.4,
    pitchLimit: 1.5,            // rad
  },
  lamp: {
    color: 0xfff1d6,
    intensity: 38,
    distance: 26,
    angle: 0.62,
    penumbra: 0.55,
    decay: 1.6,
  },
  world: {
    chunkCells: 40,             // cells per chunk edge
    voxel: 0.4,                 // units per cell → chunk = 16 units (ADD §37)
    maxWorkers: 3,
  },
  terrain: {
    strataFrequency: 2.2,       // rad per unit of height
  },
  ambient: {
    sky: 0x2a3440,
    ground: 0x0b0907,
    intensity: 0.22,
  },
  ui: {
    minTouchTarget: 44,         // CSS px, layout self-test
    selfTestDelayMs: 400,
  },
  scale: {
    antLength: 1.0,
    eyeHeight: 0.35,
    tunnelDiameter: 2.2,
  },
});
