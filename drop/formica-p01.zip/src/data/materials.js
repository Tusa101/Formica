// Canonical geology (AB §6, GDD §11). Index = material id = slot in the terrain vec4 weights.
// Gameplay values are placeholders until P03 (digging) and P05 (stability) tune them.
export const MATERIALS = Object.freeze([
  { id: 0, key: 'soil',      name: 'Soil',      color: 0x5e4533, color2: 0x3f2d21, roughness: 0.96, hardness: 0.2, stability: 0.45, strata: 0.0 },
  { id: 1, key: 'clay',      name: 'Clay',      color: 0x7c5541, color2: 0x5a3c2d, roughness: 0.82, hardness: 0.5, stability: 0.7,  strata: 0.35 },
  { id: 2, key: 'sand',      name: 'Sand',      color: 0x9a8662, color2: 0x74634a, roughness: 0.99, hardness: 0.1, stability: 0.2,  strata: 0.1 },
  { id: 3, key: 'limestone', name: 'Limestone', color: 0xa39d8e, color2: 0x7d776a, roughness: 0.74, hardness: 0.8, stability: 0.9,  strata: 0.6 },
]);
export const MAT = Object.freeze({ SOIL: 0, CLAY: 1, SAND: 2, LIMESTONE: 3 });
