import { CONFIG } from './config.js';
import { App } from './core/app.js';
import { Input } from './core/input.js';
import { Shell } from './ui/shell.js';
import { TouchControls } from './ui/touch.js';
import { Hud, DebugPanel } from './ui/hud.js';
import { runLayoutSelfTest } from './ui/selftest.js';
import { TestTunnelsScene } from './scenes/test-tunnels.js';
import { TEST_TUNNELS } from './levels/test-tunnels.js';
import { Carapace } from './ui/carapace.js';
import { ModulePanel } from './ui/module-panel.js';
import { MODULE_TYPES } from './data/modules.js';
import { MapPanel } from './ui/map-panel.js';
import { Finale } from './ui/finale.js';
import { SettingsPanel } from './ui/settings-panel.js';
import { settings, loadSettings, setSetting } from './settings.js';
import { migrate, exportSave, importSave, resetAll as resetSaves, saveSize } from './save/save-manager.js';
import { ITEMS } from './data/items.js';

const params = new URLSearchParams(location.search);
let migration = null;
try { migration = migrate(localStorage); } catch { /* storage unavailable */ }
loadSettings();
const touch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
document.body.classList.toggle('is-touch', touch);

const stage = document.getElementById('stage');
const uiRoot = document.getElementById('ui');

const app = new App(stage, { touch });
const input = new Input(app.canvas);
const hud = new Hud(uiRoot);
const debug = new DebugPanel(uiRoot, app, input);
const touchUI = touch ? new TouchControls(uiRoot, input, { onMenu: () => shell.showPause(), onKit: () => toggleKit() }) : null;
let carapace = null, modulePanel = null, openModule = null;
const kitState = () => ({ survival: level.survival, inventory: level.inventory, stations: level.stations });
function toggleKit() {
  if (!level.ready || !shell.started || shell.isPaused) return;
  if (modulePanel?.open) closeModule(false);
  if (carapace.open) { carapace.hide(); setPlaying(true); input.requestPointerLock(); return; }
  setPlaying(false);
  if (document.pointerLockElement) document.exitPointerLock();
  carapace.show(kitState());
}
function openModulePanel(id) {
  openModule = id;
  setPlaying(false);
  if (document.pointerLockElement) document.exitPointerLock();
  modulePanel.show(level.moduleVM(id));
}
function closeModule(resume = true) {
  modulePanel.hide(); openModule = null;
  if (finale?.open) return;
  if (resume) { setPlaying(true); input.requestPointerLock(); }
}

const persistentSelfTest = params.get('selftest') === '1';
function selfTest() {
  const result = runLayoutSelfTest(CONFIG.ui.minTouchTarget);
  debug.setLayout(result);
  hud.showSelfTest(result, persistentSelfTest);
  window.__formicaLayout = result; // read by headless smoke tests
  return result;
}
let selfTestTimer = 0;
const scheduleSelfTest = () => { clearTimeout(selfTestTimer); selfTestTimer = setTimeout(selfTest, CONFIG.ui.selfTestDelayMs); };
addEventListener('resize', scheduleSelfTest);

function setPlaying(playing) {
  input.enabled = playing;
  if (!playing) input.reset();
  hud.setVisible(playing);
  touchUI?.setVisible(playing);
  scheduleSelfTest();
}

function resetAll() { try { resetSaves(localStorage); } catch { level.world.clearSaved(); level.clearPlayer(); level.clearBase(); level.clearExplore(); level.clearStory(); } }
// Voice Synthesizer (GDD §39): optional browser TTS for recordings
function speak(text) {
  if (!settings.voice || !window.speechSynthesis || !text || text.startsWith('[')) return;
  const u = new SpeechSynthesisUtterance(text); u.rate = 0.92; u.pitch = 0.8; u.lang = 'en-GB';
  speechSynthesis.speak(u);
}
hud.onSpeak = (l) => speak(l.text);
const shell = new Shell(uiRoot, {
  touch,
  onStart: () => { level.sfx.unlock(); level.started = true; setPlaying(true); input.requestPointerLock(); },
  onPause: () => setPlaying(false),
  onResume: () => { setPlaying(true); input.requestPointerLock(); },
  onSelfTest: () => { debug.el.hidden = false; selfTest(); },
  onDebug: () => { debug.toggle(); if (level.ready && level.graphView.visible === debug.el.hidden) level.graphView.toggle(); },
  onCamera: () => { shell.setLabels({ camera: level.ant.cycleCameraMode() }); },
  onMode: () => { shell.setLabels({ mode: level.toggleMode() }); syncMode(); },
  onCourse: () => level.resetCourse(),
  onResetWorld: () => { resetAll(); location.reload(); },
  onSandbox: () => { level.storyOn = false; },
  onNewRite: () => { resetAll(); try { localStorage.setItem('formica.pendingRite', '1'); } catch { /* ignore */ } location.reload(); },
  onSettings: () => { shell.pause.hidden = true; settingsPanel.show(); },
});

input.on((type, value) => {
  if (type === 'press' && value === 'debug') debug.toggle();
  if (type === 'press' && value === 'kit') toggleKit();
  if (type === 'press' && value === 'use' && modulePanel?.open) closeModule();
  if (type === 'press' && value === 'noclip' && input.enabled) { shell.setLabels({ mode: level.toggleMode() }); syncMode(); }
  if (type === 'press' && value === 'camera' && input.enabled) shell.setLabels({ camera: level.ant.cycleCameraMode() });
  if (type === 'press' && value === 'tool1') setTool(0);
  if (type === 'press' && value === 'tool2') setTool(1);
  if (type === 'wheel') setTool(level.digger.toolIndex + value);
  if (type === 'press' && value === 'map' && level.ready && (input.enabled || mapPanel.open)) toggleMap();
  if (type === 'press' && value === 'graph' && level.ready) level.graphView.toggle();
  if (type === 'press' && value === 'use' && input.enabled) level.use();
  if (type === 'press' && value === 'scan' && input.enabled) level.scan();
  // Desktop: leaving pointer lock (Esc) opens the pause menu (not while a panel is open).
  if (type === 'pointerlock' && value === false && !touch && shell.started && !shell.isPaused && !carapace?.open && !modulePanel?.open && !mapPanel?.open) shell.showPause();
});
addEventListener('keydown', (e) => { if (e.code === 'Escape' && touch) shell.showPause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) { shell.showPause(); level.world.save(); level.savePlayer(); level.saveBase?.(); level.saveExplore?.(); } });
addEventListener('pagehide', () => { level.world.save(); level.savePlayer(); });

const level = new TestTunnelsScene(app, input, TEST_TUNNELS);
carapace = new Carapace(uiRoot, {
  onUse: (id) => { if (level.useItem(id) === 'armed') toggleKit(); else carapace.render(kitState()); },
  onDrop: (id) => { level.dropItem(id); carapace.render(kitState()); },
  onCraft: (id) => { level.craftItem(id); carapace.render(kitState()); },
  onClose: () => toggleKit(),
});
modulePanel = new ModulePanel(uiRoot, {
  onAction: (act, arg) => {
    const next = level.moduleAction(openModule, act, arg);
    if (next === 'kit') { closeModule(false); carapace.show(kitState()); return; }
    if (next === 'close') { closeModule(); return; }
    modulePanel.show(level.moduleVM(openModule));
  },
  onClose: () => closeModule(),
});
level.onModule = (id) => openModulePanel(id);

// ---- settings (P12.2) ----
function applySettings() {
  const preset = app.setQuality(settings.quality);
  if (level.ready) { level.applyQuality(preset); level.hideCourse = !settings.showCourse; level.markers?.sync(); level.hints.enabled = settings.hints; }
  level.sfx.setVolume(settings.volume);
}
const settingsPanel = new SettingsPanel(uiRoot, {
  onChange: (k, v) => { setSetting(k, v); applySettings(); },
  onCamera: () => shell.setLabels({ camera: level.ant.cycleCameraMode() }),
  cameraLabel: () => level.ant.cameraMode.toUpperCase(),
  saveInfo: () => { try { return `${Math.round(saveSize(localStorage) / 1024)} KB`; } catch { return '—'; } },
  onExport: () => {
    level.world.save(); level.savePlayer(); level.saveBase?.(); level.saveExplore?.(); level.saveStory?.();
    const blob = new Blob([exportSave(localStorage)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `formica-save-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  },
  onImport: (text) => { try { importSave(localStorage, text); location.reload(); } catch (e) { alert('Import failed: ' + e.message); } },
  onReset: () => { resetAll(); location.reload(); },
  onClose: () => { settingsPanel.hide(); shell.pause.hidden = false; },
});
level.onSay = (lines, system) => hud.subtitles(lines, system);
level.onHint = (text) => hud.tip(text);
level.onInspect = (e) => {
  openModule = null; setPlaying(false);
  if (document.pointerLockElement) document.exitPointerLock();
  modulePanel.show({ title: e.title, state: 'OBSERVED', lines: [e.text], actions: [] });
};
const finale = new Finale(uiRoot, {
  onContinue: () => { finale.hide(); setPlaying(true); input.requestPointerLock(); },
  onNewRite: () => { resetAll(); try { localStorage.setItem('formica.pendingRite', '1'); } catch { /* ignore */ } location.reload(); },
});
level.onFinale = (stats) => {
  if (modulePanel.open) closeModule(false);
  setPlaying(false);
  if (document.pointerLockElement) document.exitPointerLock();
  finale.play(stats, speak);
};

// ---- 3D map (GDD §44) ----
let worldView = null;
const mapPanel = new MapPanel(uiRoot, {
  onClose: () => toggleMap(),
  onOrbit: (dx, dy) => level.mapView.orbit(dx, dy),
  onZoom: (f) => level.mapView.zoom(f),
  onRecenter: () => level.mapView.recenter(level.playerPos),
  onMark: (t) => { level.mark(t); notice(`MARKED · ${t.toUpperCase()}`); syncMap(); },
  onUnmark: () => { notice(level.unmark() ? 'MARKER REMOVED' : 'NO MARKER NEARBY (3 u)'); syncMap(); },
});
function syncMap() { level.mapView.sync(level.exploration, level.topology.nav, level.playerPos, level.ant.motor.heading, level.beacons()); }
function toggleMap() {
  if (!level.ready || !shell.started || shell.isPaused) return;
  if (mapPanel.open) {
    mapPanel.hide();
    app.scene = worldView.scene; app.camera = worldView.camera; app._resize();
    setPlaying(true); input.requestPointerLock();
    return;
  }
  if (carapace.open) carapace.hide();
  if (modulePanel.open) closeModule(false);
  setPlaying(false);
  if (document.pointerLockElement) document.exitPointerLock();
  worldView = { scene: app.scene, camera: app.camera };
  level.mapView.recenter(level.playerPos);
  syncMap();
  app.scene = level.mapView.scene; app.camera = level.mapView.camera; app._resize();
  mapPanel.show();
}
app.add({ update: () => { if (mapPanel.open) { syncMap(); level.mapView.updateCamera(app.width / app.height); } } });
app.scene = level.scene;
app.add({ preUpdate: () => input.update() });
app.add(level);
function setTool(i) { level.digger.setTool(i); hud.setTool(level.digger.tool.name); }
hud.onTool = () => setTool(level.digger.toolIndex + 1);
function syncMode() { hud.setMode(level.mode === 'ant' ? 'ANT' : 'NOCLIP'); }
shell.setLabels({ camera: level.ant.cameraMode, mode: level.mode });
app.add({ lateUpdate: () => input.endFrame() });
app.add(debug);
debug.extra = () => level.debugText();

let lastZone, noticeUntil = 0;
const notice = (text, kind = '') => hud.notice(text, 3.5, kind);
level.onNotice = notice;
level.onTopologyEvent = (ev) => {
  const label = ev.type === 'connected' ? 'CAVITY OPENED' : 'NEW PASSAGE';
  notice(`${label} · ${ev.a} ↔ ${ev.b}`);
};
app.add({ update: () => {
  const zl = (level.zone || 'Test Tunnels') + (level.shelterLine ? ` · ${level.shelterLine}` : '');
  if (zl !== lastZone) { lastZone = zl; hud.setMessage(zl); }
  if (noticeUntil && performance.now() > noticeUntil) { noticeUntil = 0; lastZone = undefined; }
  hud.setCourse(level.ready ? level.courseText : '');
  if (level.ready) {
    const sv = level.survival;
    hud.setVib(level.vibSense.s, level.vibSense.up, level.vibSense.down);
    const sig = level.signalBearing(); hud.setSignal(sig ? sig.angle : null, sig?.dist ?? 0);
    hud.setVitals({ health: sv.health, energy: sv.energy, air: level.airQuality, hydration: sv.hydration, breath: sv.breath });
    const tool = level.digger.tool;
    hud.setTool(tool.id === 'vibropick' ? `${tool.name} ${Math.round(sv.toolCharge)}%` : tool.name);
    const ut = level.useTarget;
    if (level.armed && level.mode === 'ant') hud.setAim('ok', `USE · PLACE ${ITEMS[level.armed].name.toUpperCase()}`);
    else if (ut && level.mode === 'ant') hud.setAim('ok', ut.kind === 'module' ? `USE · ${MODULE_TYPES[ut.m.type].name}` : ut.kind === 'inspect' ? `USE · ${ut.title}` : ut.kind === 'water' ? 'USE · DRINK' : `USE · ${ITEMS[ut.item].name.toUpperCase()}`);
    else { const t = level.mode === 'ant' ? level.digger.target : null; hud.setAim(t ? (t.status === 'empty' ? 'warn' : t.status) : 'none', t?.status === 'empty' ? 'NO CELL CHARGE' : t?.materialName?.toUpperCase() ?? ''); }
  }

} });

syncMode();
hud.setMessage('Test Tunnels');
setPlaying(false);
if (params.get('debug') === '1') debug.toggle();

level.load((done, total) => shell.setLoading(done, total)).then(() => {
  shell.setReady(level.story.phase === 'ended' ? 'ended' : level.story.active ? (level.story.s.t > 0.5 ? 'continue' : 'ready') : 'new');
  applySettings();
  if (migration?.newer) notice('SAVE FROM A NEWER BUILD · reset if something breaks', 'caution');
  window.__formicaWorldReady = true;
  if (params.get('autostart') === '1') (params.get('sandbox') === '1' ? shell.start.querySelector('[data-hud="start-sandbox"]') : shell.goBtn).click();
}).catch((e) => window.__formicaError?.('World generation failed: ' + (e.stack || e.message || e)));

app.start();
window.__formica = { app, input, level };
window.__formicaReady = true;
