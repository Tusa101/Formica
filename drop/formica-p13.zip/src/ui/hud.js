// Minimal HUD (GDD §58 grows here in later phases) and the debug panel.
import { BUILD, PHASE } from '../config.js';

export class Hud {
  constructor(root) {
    this.el = document.createElement('div');
    this.el.id = 'hud';
    this.el.innerHTML = `
      <div class="reticle"></div>
      <div class="aim-label"></div>
      <div class="vib-ring">${Array.from({ length: 16 }, (_, i) => `<i style="transform: rotate(${i * 22.5}deg)"></i>`).join('')}<b class="up">▲</b><b class="down">▼</b></div>
      <div class="hud-toast" hidden></div>
      <div class="hud-subs" hidden></div>
      <div class="hud-tip" data-hud="hud-tip" hidden><b>TIP</b><span></span></div>
      <div class="hud-signal" data-hud="hud-signal" hidden><i>▲</i><span></span></div>
      <button class="hud-tool" data-hud="hud-tool">MANDIBLES</button>
      <div class="hud-vitals" data-hud="hud-vitals"></div>
      <div class="hud-status" data-hud="hud-status"><span class="mode">NOCLIP</span><span class="msg"></span></div>
      <div class="hud-badge" data-hud="hud-selftest" hidden></div>
      <div class="hud-course" data-hud="hud-course" hidden></div>`;
    root.appendChild(this.el);
    this.modeEl = this.el.querySelector('.mode');
    this.msgEl = this.el.querySelector('.msg');
    this.badge = this.el.querySelector('.hud-badge');
    this.courseEl = this.el.querySelector('.hud-course');
    this.reticle = this.el.querySelector('.reticle');
    this.aimLabel = this.el.querySelector('.aim-label');
    this.toolBtn = this.el.querySelector('.hud-tool');
    this.onTool = null;
    this.toolBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); this.onTool?.(); });
    this._aim = '';
    this.vitalsEl = this.el.querySelector('.hud-vitals');
    this._vit = '';
  }
  /**
   * GDD §58: HP, EN, AIR always; WATER and BREATH only when they matter.
   * @param {{health:number, energy:number, air:number, hydration:number, breath:number}} v  0..100 (air 0..1)
   */
  setVitals(v) {
    const rows = [['HP', v.health, 50], ['EN', v.energy, 30], ['AIR', v.air * 100, 70]];
    if (v.breath < 99) rows.push(['BREATH', v.breath, 60]);
    if (v.hydration < 40) rows.push(['WATER', v.hydration, 40]);
    const key = rows.map((r) => r[0] + Math.round(r[1] / 2)).join('');
    if (key === this._vit) return;
    this._vit = key;
    this.vitalsEl.innerHTML = rows.map(([l, x, w]) => `<div class="vr ${x < w * 0.5 ? 'danger' : x < w ? 'caution' : ''}"><span>${l}</span><i style="width:${Math.max(0, Math.round(x))}%"></i></div>`).join('');
  }
  /** Vibration sense ring (GDD §45): 16 sectors around the reticle + above/below. */
  setVib(sectors, up, down) {
    if (!this._vibI) { this._vibI = [...this.el.querySelectorAll('.vib-ring i')]; this._vibUp = this.el.querySelector('.vib-ring .up'); this._vibDown = this.el.querySelector('.vib-ring .down'); }
    for (let i = 0; i < 16; i++) { const v = sectors[i] > 0.04 ? Math.min(1, sectors[i]).toFixed(2) : '0'; if (this._vibI[i].style.opacity !== v) this._vibI[i].style.opacity = v; }
    this._vibUp.style.opacity = up > 0.04 ? Math.min(1, up).toFixed(2) : '0';
    this._vibDown.style.opacity = down > 0.04 ? Math.min(1, down).toFixed(2) : '0';
  }
  /** Control tip (P13). */
  tip(text, secs = 7) {
    const el = this.el.querySelector('.hud-tip');
    el.querySelector('span').textContent = text; el.hidden = false;
    clearTimeout(this._tipT); this._tipT = setTimeout(() => { el.hidden = true; }, secs * 1000);
  }
  /** Subtitles queue (recordings, escorts, Rite Kit). lines: [{who, text}] */
  subtitles(lines, system = false) {
    this._subQ = (this._subQ || []).concat(lines.map((l) => ({ ...l, system })));
    if (!this._subBusy) this._nextSub();
  }
  _nextSub() {
    const el = this.el.querySelector('.hud-subs');
    const l = this._subQ.shift();
    if (!l) { el.hidden = true; this._subBusy = false; return; }
    this._subBusy = true;
    el.className = 'hud-subs' + (l.system ? ' system' : '');
    el.innerHTML = `<b>${l.who || 'RITE KIT'}</b>${l.text}`;
    el.hidden = false;
    this.onSpeak?.(l);
    setTimeout(() => this._nextSub(), Math.max(2200, l.text.length * 55));
  }
  /** Shelter bearing (ADD §6): arrow relative to the view, distance rounded to 5. angle in degrees, null = hidden */
  setSignal(angle, dist) {
    const el = this.el.querySelector('.hud-signal');
    el.hidden = angle === null;
    if (angle === null) return;
    el.querySelector('i').style.transform = `rotate(${Math.round(angle)}deg)`;
    const t = `SHELTER SIGNAL ~${Math.max(5, Math.round(dist / 5) * 5)} u`;
    const sp = el.querySelector('span'); if (sp.textContent !== t) sp.textContent = t;
  }
  /** Transient event notice (topology, collapse, air, vibration). */
  notice(text, secs = 3.5, kind = '') {
    const t = this.el.querySelector('.hud-toast');
    t.textContent = text; t.className = 'hud-toast ' + kind; t.hidden = false;
    clearTimeout(this._toastT);
    this._toastT = setTimeout(() => { t.hidden = true; }, secs * 1000);
  }
  setTool(name) { this.toolBtn.textContent = name; }
  /** status: 'ok' | 'hard' | 'none' */
  setAim(status, label) {
    const key = status + label;
    if (key === this._aim) return;
    this._aim = key;
    const cls = status === 'warn' ? 'hard' : status;
    this.reticle.className = 'reticle ' + cls;
    this.aimLabel.className = 'aim-label ' + cls;
    this.aimLabel.textContent = status === 'none' ? '' : status === 'hard' ? `${label} · TOO HARD` : label;
  }
  setCourse(t) { if (this.courseEl.textContent !== t) this.courseEl.textContent = t; this.courseEl.hidden = !t; }
  setVisible(v) { this.el.hidden = !v; }
  setMode(t) { this.modeEl.textContent = t; }
  setMessage(t) { this.msgEl.textContent = t; }
  showSelfTest(result, persistent) {
    const ok = result.problems.length === 0;
    this.badge.hidden = !(persistent || !ok);
    this.badge.className = 'hud-badge ' + (ok ? 'ok' : 'bad');
    this.badge.textContent = ok ? `LAYOUT OK (${result.checked})` : `LAYOUT: ${result.problems.length} issue(s)`;
  }
}

export class DebugPanel {
  constructor(root, app, input) {
    this.app = app; this.input = input;
    this.el = document.createElement('pre');
    this.el.id = 'debug-panel';
    this.el.hidden = true;
    root.appendChild(this.el);
    this.layout = null;
    this.extra = () => '';
    this._t = 0;
  }
  toggle() { this.el.hidden = !this.el.hidden; }
  setLayout(result) { this.layout = result; }
  lateUpdate(dt) {
    if (this.el.hidden) return;
    this._t += dt;
    if (this._t < 0.25) return;
    this._t = 0;
    const a = this.app, r = a.renderer.info.render, i = this.input;
    const lay = this.layout
      ? (this.layout.problems.length ? 'LAYOUT ✗\n  ' + this.layout.problems.join('\n  ') : `LAYOUT OK (${this.layout.checked})`)
      : 'LAYOUT —';
    this.el.textContent =
`${PHASE} build ${BUILD}
fps ${a.fps.toFixed(0)}  cpu ${a.frameMs.toFixed(1)}ms
draws ${r.calls}  tris ${r.triangles}
res ${a.width}×${a.height} @${a.renderer.getPixelRatio().toFixed(2)}
input ${i.source}${i.pointerLocked ? ' (locked)' : ''}
move ${i.move.x.toFixed(2)},${i.move.y.toFixed(2)}
held ${[...i.held].join(' ') || '-'}
${this.extra()}
${lay}`;
  }
}
