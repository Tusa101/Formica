// Test Tunnels scene: volumetric level + ant controller (default) or noclip (debug), traversal course.
import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { World } from '../world/world.js';
import { ChunkMeshes } from '../render/chunk-meshes.js';
import { createTerrainMaterial } from '../render/terrain-material.js';
import { CourseMarkers } from '../render/course-markers.js';
import { PROP_BUILDERS, pathLamp } from '../props/greybox.js';
import { LightPool } from '../render/light-pool.js';
import { placeLamps } from '../world/lamp-path.js';
import { Hints } from '../story/hints.js';
import { settings } from '../settings.js';
import { NoclipController } from '../player/noclip.js';
import { AntController } from '../player/ant-controller.js';
import { Course, formatTime } from '../gameplay/course.js';
import { Digger } from '../gameplay/dig.js';
import { Debris } from '../render/debris.js';
import { MATERIALS } from '../data/materials.js';
import { Topology } from '../world/topology.js';
import { Beetle } from '../ai/beetle.js';
import { BeetleView } from '../render/beetle-view.js';
import { GraphView } from '../render/graph-view.js';
import { Stability, State } from '../world/stability.js';
import { SupportView, ScannerView } from '../render/structure-view.js';
import { planSupport } from '../gameplay/supports.js';
import { Sfx } from '../audio/sfx.js';
import { Atmosphere } from '../world/atmosphere.js';
import { VibrationBus, VIBRATION } from '../world/vibration.js';
import { Survival } from '../gameplay/survival.js';
import { Inventory } from '../gameplay/inventory.js';
import { craft } from '../gameplay/crafting.js';
import { Pickups } from '../render/pickups.js';
import { ITEMS, RITE_KIT } from '../data/items.js';
import { SURVIVAL } from '../data/survival.js';
import { BaseNetwork } from '../gameplay/base.js';
import { BaseView } from '../render/base-view.js';
import { MODULE_TYPES, STATE_LABEL } from '../data/modules.js';
import { MAINTENANCE_LOG } from '../data/lore.js';
import { RECIPES } from '../data/recipes.js';
import { Exploration } from '../gameplay/exploration.js';
import { VibrationSense } from '../gameplay/senses.js';
import { MapView } from '../render/map-view.js';
import { ScentView } from '../render/scent-view.js';
import { Spider } from '../ai/spider.js';
import { Scout } from '../ai/scout.js';
import { DeepThing } from '../ai/deep-thing.js';
import { canSee } from '../ai/perception.js';
import { SpiderView, ScoutView } from '../render/creature-views.js';
import { RiteStory } from '../story/rite.js';
import { buildRoots } from '../render/roots.js';
import { Inspectables } from '../render/inspectables.js';
import { MAT } from '../data/materials.js';

let storage = null;
try { storage = localStorage; } catch { /* private mode */ }

export class TestTunnelsScene {
  constructor(app, input, level) {
    this.app = app; this.input = input; this.level = level;
    const scene = (this.scene = new THREE.Scene());
    const R = CONFIG.render, A = CONFIG.ambient;
    scene.fog = new THREE.Fog(R.fogColor, R.fogNear, R.fogFar);
    scene.add(new THREE.HemisphereLight(A.sky, A.ground, A.intensity));

    const L = CONFIG.lamp;
    this.lamp = new THREE.SpotLight(L.color, L.intensity, L.distance, L.angle, L.penumbra, L.decay);
    this.lamp.position.set(...L.offset);
    this.lamp.target.position.set(L.offset[0] + L.aim[0], L.offset[1] + L.aim[1], L.offset[2] + L.aim[2]);
    app.camera.add(this.lamp, this.lamp.target);
    scene.add(app.camera);

    this.world = new World(level, storage);
    this.terrainMaterial = createTerrainMaterial();
    this.terrain = new ChunkMeshes(scene, this.terrainMaterial);
    this.digger = new Digger(this.world);
    this.debris = new Debris(scene);
    this.world.onChunkMesh = (chunk, mesh) => this.terrain.upsert(chunk, mesh);

    this.noclip = new NoclipController(app.camera, input, level.spawn);
    this.ant = new AntController(app.camera, input, this.world.field);
    this.ant.body.setVisible(false);
    this.course = new Course(level.course, storage);
    this.mode = 'ant';
    this.ready = false;
    this.zone = null;
    this._zoneT = 0;
    this.courseText = '';
    this.flash = null; this.flashT = 0;
    this.onTopologyEvent = null;
    this.graphView = new GraphView(scene);
    this.beetles = [];
    this.supportView = new SupportView(scene);
    this.scanner = new ScannerView(scene);
    this.sfx = new Sfx();
    this.onNotice = null;
    this.stressSources = [];
    this._creakT = 0;
    this.airQuality = 1;
    this._airWarned = false;
    this._stepT = 0;
    this._vibCool = 0;
    this._v3 = new THREE.Vector3();
    this.fogScale = 1;
    this.landmarkLights = [];
    this._cullT = 0;
    this.playerKey = `formica.player.${level.id}.${level.seed}`;
    this._loadPlayer();
    this.useTarget = null;
  }

  async load(onProgress) {
    await this.world.load(onProgress);
    this._placeLandmarks();
    this.markers = new CourseMarkers(this.scene, this.course);
    this.topology = new Topology(this.world.field, this.level);
    this.topology.build();
    this.stability = new Stability(this.world.field, this.topology.nav);
    this.stability.build();
    this.atmosphere = new Atmosphere(this.topology.nav, this.level.air || {}, (p) => this.world.analytic.zoneAt(p[0], p[1], p[2], 0.3));
    this.atmosphere.init();
    this.vib = new VibrationBus(this.world.field);
    this.pickups = new Pickups(this.scene, this.world.field, this.level, this.collected);
    this.exploreKey = `formica.explore.${this.level.id}.${this.level.seed}`;
    this.exploration = new Exploration(this.topology.nav);
    try { this.exploration.load(JSON.parse(storage?.getItem(this.exploreKey) || 'null')); } catch { /* ignore */ }
    this.vibSense = new VibrationSense();
    this.mapView = new MapView();
    this.scentView = new ScentView(this.scene);
    this._revealT = 0;
    this._initBase();
    buildRoots(this.scene, this.level.roots);
    this.inspectables = new Inspectables(this.scene, this.world.field, this.level.rite?.inspectables);
    this.storyKey = `formica.story.${this.level.id}.${this.level.seed}`;
    let st = null;
    try { st = JSON.parse(storage?.getItem(this.storyKey) || 'null'); } catch { /* ignore */ }
    this.story = new RiteStory(st);
    this.storyOn = this.story.active;
    this.flags = { spiderThreat: false, logRead: false, transmitted: false };
    this._storyT = 0;
    let seenHints = [];
    try { seenHints = JSON.parse(storage?.getItem('formica.hints') || '[]'); } catch { /* ignore */ }
    this.hints = new Hints(seenHints, { enabled: settings.hints });
    this.playT = 0; this._aimOkT = 0; this._hintT = 0;
    let pending = false;
    try { pending = storage?.getItem('formica.pendingRite') === '1'; storage?.removeItem('formica.pendingRite'); } catch { /* ignore */ }
    if (pending) this.beginRite();
    this.world.onEdit = (c, r, opts) => { this.topology.onEdit(c, r); this.stability.onEdit(c, r, opts); this.atmosphere.markDirty(); };
    for (const [a, b] of this.world.supports) { this.stability.addSupport(a, b); this.supportView.add(a, b); }
    for (const [i, c] of (this.level.creatures || []).entries()) {
      if (c.kind === 'beetle') this.beetles.push({ brain: new Beetle(this.world.field, this.topology, c.pos, 7 + i), view: new BeetleView(this.scene) });
      if (c.kind === 'spider') {
        const lair = this.world.field.dropToSurface(c.pos, 6) || c.pos;
        this.spider = { brain: new Spider(this.world.field, this.topology, [lair[0], lair[1] + 0.3, lair[2]], 31 + i), view: new SpiderView(this.scene) };
      }
    }
    this.scoutT = this.level.scout?.delay ?? Infinity;
    this.scout = null;
    this.deep = this.level.deep ? new DeepThing(this.level.deep.loop.map((p) => p.slice())) : null;
    this._deepNoticeT = 0; this._scoutNoticed = false; this._biteCool = 0; this._critStepT = 0;
    const R = this.level.rite;
    const start = this.story.phase === 'opening' && R ? R.spawn : this.discovered && this.level.shelter ? { pos: this.level.shelter.respawn, yaw: 0 } : this.level.spawn;
    this.ant.place(start.pos, start.yaw);
    this.ant.body.setVisible(this.mode === 'ant');
    this.ant.onEvent = (e) => { if (e.type === 'land' && e.hard) this.survival.damage(SURVIVAL.hardLandingDamage, 'fall'); };
    this.ready = true;
  }

  _placeLandmarks() {
    // P13: a fixed pool of real lights follows the nearest sources (landmarks + ritual path lamps)
    this.lightPool = new LightPool(this.scene, 5);
    this.level.lights.forEach((l, i) => {
      const hit = this.world.field.dropToSurface(l.pos, 12) || l.pos;
      const base = new THREE.Vector3(...hit);
      const build = PROP_BUILDERS[l.kind];
      if (build) { const prop = build(i, l); prop.position.copy(base); this.scene.add(prop); }
      this.lightPool.add({ pos: [base.x, base.y + (l.kind === 'ritual-lamp' ? 1.3 : 0.7), base.z], color: l.color, intensity: l.intensity, distance: l.distance });
    });
    // old ritual lamps along the initiates' way to the shelter (ADD §6)
    const f = this.world.field;
    this.pathLamps = placeLamps(this.level.rite?.lampPath || [], (p) => (f.densityAt(...p) < 0 ? f.dropToSurface(p, 3) : null));
    for (const l of this.pathLamps) {
      const { group, bulb } = pathLamp();
      group.position.set(...l.pos);
      this.scene.add(group);
      this.lightPool.add({ pos: [l.pos[0], l.pos[1] + 0.65, l.pos[2]], color: 0xffc27a, intensity: 3.2, distance: 7, flicker: l.flicker, bulb, tint: bulb.material.color.clone() });
    }
  }

  _loadPlayer() {
    let saved = null;
    try { saved = JSON.parse(storage?.getItem(this.playerKey) || 'null'); } catch { /* ignore */ }
    this.survival = new Survival(saved?.survival || {});
    this.inventory = saved ? Inventory.from(saved.inventory) : Inventory.from(RITE_KIT);
    this.collected = new Set(saved?.collected || []);
    this.harness = !!saved?.harness;
    this.alerts = saved?.alerts || 0;
    if (this.harness) this.inventory.limit = 30;
  }

  savePlayer() {
    try {
      storage?.setItem(this.playerKey, JSON.stringify({ survival: this.survival.toJSON(), inventory: this.inventory.toJSON(), collected: [...this.collected], harness: !!this.harness, alerts: this.alerts || 0 }));
    } catch { /* quota */ }
  }

  clearPlayer() { try { storage?.removeItem(this.playerKey); } catch { /* ignore */ } }

  _initBase() {
    const f = this.world.field;
    const los = (a, b) => {
      const d = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]), n = Math.max(1, Math.ceil(d / 0.4));
      for (let i = 1; i < n; i++) { const k = i / n; if (f.densityAt(a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k + 0.35, a[2] + (b[2] - a[2]) * k) > 0) return false; }
      return true;
    };
    this.base = new BaseNetwork(this.level.shelter?.modules || [], { los });
    this.baseKey = `formica.base.${this.level.id}.${this.level.seed}`;
    let saved = null;
    try { saved = JSON.parse(storage?.getItem(this.baseKey) || 'null'); } catch { /* ignore */ }
    this.base.load(saved?.base);
    this.stash = Inventory.from(saved?.stash, 999);
    this.discovered = !!saved?.discovered;
    this.baseView = new BaseView(this.scene, f);
    this.baseView.sync(this.base);
    for (const m of this.base.modules) if (m.floor && !m.placed) m.pos = [m.floor[0], m.floor[1] + 0.3, m.floor[2]];
    this.base.recompute();
    this.armed = null;
    this._baseT = 0;
    this.condenserCooldown = 0;
  }

  /** Starts the Rite on a fresh world (the caller resets saves and reloads first). */
  beginRite() {
    this.story.start(); this.storyOn = true;
    this.saveStory();
  }
  saveStory() { try { storage?.setItem(this.storyKey, JSON.stringify(this.story.toJSON())); } catch { /* quota */ } }
  clearStory() { try { storage?.removeItem(this.storyKey); } catch { /* ignore */ } }

  _storyTick(dt) {
    if (!this.started || !this.storyOn || !this.story.active) return;
    this._storyT += dt;
    if (this._storyT < 0.2 && this.story.phase === 'journey') return;
    const step = this._storyT; this._storyT = 0;
    const p = this.playerPos, R = this.level.rite;
    const a = this.mode === 'ant' ? this.ant.aim() : null;
    const seesResin = !!a && this.pickups.entries.some((e) => e.item === 'resin' && Math.hypot(...e.pos.map((v, i) => v - p[i])) < 5 && canSee(this.world.field, a.eye, e.pos, 5));
    const ctx = {
      distance: Math.hypot(...R.signal.map((v, i) => v - p[i])),
      seesResin, air: this.airQuality, spiderThreat: this.flags.spiderThreat, inShelter: this.discovered,
      logRead: this.flags.logRead, powerRepaired: this.base.get('power')?.state === 'working',
      deepNear: !!this.deep && Math.hypot(...R.shift.lure.map((v, i) => v - this.deep.pos[i])) < 4,
      beaconRepaired: this.base.get('beacon')?.state === 'working', transmitted: this.flags.transmitted,
    };
    for (const act of this.story.update(step, ctx)) this._storyAction(act);
  }

  _storyAction(act) {
    const R = this.level.rite, now = TestTunnelsScene.now();
    if (act.type === 'say') this.onSay?.(act.lines, false);
    if (act.type === 'system') this.onSay?.(act.lines.map((text) => ({ who: 'RITE KIT', text })), true);
    if (act.type === 'seal') {
      for (const f of R.seal) this.world.fill(f.c, f.r, MAT.SAND);
      for (const f of R.loopRubble) this.world.fill(f.c, f.r, MAT.SAND);
      this.sfx.rumble(4); this.ant.kickT = 3;
      for (const f of R.seal) this.debris.burst(f.c, [1, 0.3, 0], MAT.SAND, 40);
      this.vib.emit(R.seal[0].c, 6, 'world');
    }
    if (act.type === 'lure' && this.deep) { this.deep.target = R.shift.lure.slice(); this.deep.forgetT = 60; }
    if (act.type === 'shift') {
      for (const c of R.shift.carve) this.world.carve(c, R.shift.r, now);
      this.world.fill(R.shift.rubble.c, R.shift.rubble.r, MAT.SAND);
      this.stability.addVibration(R.shift.carve[0], 6);
      const d = Math.hypot(...R.shift.carve[0].map((v, i) => v - this.playerPos[i]));
      this.sfx.rumble(d); this.ant.kickT = 3;
      this.debris.burst(R.shift.carve[1], [0, -1, 0], MAT.SAND, 60);
      this.onNotice?.('THE ROCK SHIFTS · something passed beneath the shelter — the north rubble has slumped', 'danger');
    }
    if (act.type === 'finale') {
      const dug = Object.values(this.world.spoil).reduce((a, b) => a + b, 0);
      this.onFinale?.({ time: this.story.s.t, dug, collapses: this.stability.stats.collapses, deaths: this.story.s.stats.deaths, alerts: this.alerts || 0 });
    }
    this.saveStory();
  }

  /** Bearing to the shelter signal in degrees relative to the view (0 = ahead), or null. */
  signalBearing() {
    if (!this.storyOn || !this.story.signal) return null;
    const cam = this.app.camera, t = this.level.rite.signal;
    const v = this._v3.set(t[0], t[1], t[2]).sub(cam.position).applyQuaternion(cam.quaternion.clone().invert());
    return { angle: (Math.atan2(v.x, -v.z) * 180) / Math.PI, dist: Math.hypot(...t.map((x, i) => x - this.playerPos[i])) };
  }

  saveExplore() { try { storage?.setItem(this.exploreKey, JSON.stringify(this.exploration.toJSON())); } catch { /* quota */ } }
  clearExplore() { try { storage?.removeItem(this.exploreKey); } catch { /* ignore */ } }

  /** Pheromone marker at the ant's feet (GDD §19): strong scent + map marker. */
  mark(type) {
    const p = this.playerPos;
    const m = this.exploration.addMarker(type, [p[0], p[1] - 0.25, p[2]]);
    this.atmosphere.deposit('marker', p, 1);
    this.saveExplore();
    return m;
  }
  unmark() {
    const m = this.exploration.nearestMarker(this.playerPos, 3);
    if (m) { this.exploration.removeMarker(m.id); this.saveExplore(); }
    return m;
  }

  /** Beacons for the map: the shelter once found, powered camps. */
  beacons() {
    const out = [];
    if (this.discovered && this.level.shelter) out.push({ pos: this.level.shelter.respawn, color: 0x5fd0c0 });
    for (const c of this.base.ofType('camp')) if (c.battery > 0) out.push({ pos: c.pos, color: 0xe0a64a });
    return out;
  }

  saveBase() {
    try { storage?.setItem(this.baseKey, JSON.stringify({ base: this.base.toJSON(), stash: this.stash.toJSON(), discovered: this.discovered })); } catch { /* quota */ }
  }
  clearBase() { try { storage?.removeItem(this.baseKey); } catch { /* ignore */ } }

  get stations() {
    const fab = this.base.get('fabricator');
    const p = this.playerPos;
    return { fabricator: !!(fab && fab.powered && fab.state === 'working' && Math.hypot(...fab.pos.map((v, i) => v - p[i])) < 3.5) };
  }

  get playerPos() { return this.mode === 'ant' ? this.ant.motor.pos : this.noclip.pos.toArray(); }

  setMode(mode) {
    if (mode === this.mode || !this.ready) return;
    if (mode === 'noclip') {
      this.noclip.pos.copy(this.app.camera.position);
      this.noclip.yaw = this.ant.viewYaw();
      this.noclip.pitch = 0;
    } else {
      const p = this.noclip.pos;
      this.ant.place([p.x, p.y, p.z], this.noclip.yaw);
    }
    this.mode = mode;
    this.ant.body.setVisible(mode === 'ant');
  }

  toggleMode() { this.setMode(this.mode === 'ant' ? 'noclip' : 'ant'); return this.mode; }

  resetCourse() {
    this.course.reset();
    this.markers?.sync();
    if (this.mode === 'ant') this.ant.place(this.level.spawn.pos, this.level.spawn.yaw);
  }

  /** P10 creatures: spider, scout, the deep thing — they learn about the ant only through stimuli. */
  _creatures(dt) {
    const f = this.world.field, am = this.ant.motor, antHere = this.mode === 'ant';
    const P = antHere ? am.pos : null;
    this._critStepT -= dt;
    const stepPulse = this._critStepT <= 0;
    if (stepPulse) this._critStepT = 0.4;
    // spider: perceives the ant inside its territory if it can see it or feel it moving
    if (this.spider) {
      const sp = this.spider.brain;
      const inRange = P && Math.hypot(...P.map((v, i) => v - sp.lair[i])) < 8;
      const perceived = inRange && (canSee(f, sp.pos, P, 6) || am.speed > 0.3) ? P : null;
      sp.step(dt, { player: perceived });
      if (sp.drum) { this.vib.emit(sp.pos, 0.5, 'spider'); this.sfx.drum(Math.hypot(...sp.pos.map((v, i) => v - am.pos[i]))); }
      if (stepPulse && sp.motor.speed > 1) this.vib.emit(sp.pos, 0.2, 'spider');
      for (const e of sp.events.splice(0)) {
        if (e.type === 'threat') { this.flags.spiderThreat = true; this.onNotice?.('SOMETHING DRUMS ITS LEGS · this is its territory — back away', 'caution'); }
        if (e.type === 'charge') this.onNotice?.('IT CHARGES', 'danger');
        if (e.type === 'hit') { this.survival.damage(e.damage, 'spider bite'); this.ant.kickT = 3; this.onNotice?.('BITTEN · get out of its territory', 'danger'); }
        if (e.type === 'scared') this.onNotice?.('IT SCUTTLES AWAY');
      }
    }
    // scout from a foreign colony
    this.scoutT -= dt;
    if (!this.scout && this.scoutT <= 0 && this.level.scout) {
      const S = this.level.scout;
      this.scout = { brain: new Scout(f, this.topology, S.home, S.patrol, 41 + Math.floor(Math.random() * 1000)), view: new ScoutView(this.scene) };
      this._scoutNoticed = false;
    }
    if (this.scout) {
      const sc = this.scout.brain;
      sc.step(dt, { air: this.atmosphere, player: P });
      this.atmosphere.deposit('scout', sc.pos, 0.8 * dt);
      if (stepPulse && sc.motor.speed > 0.3) { this.vib.emit(sc.pos, 0.12, 'scout'); this.sfx.tick(Math.hypot(...sc.pos.map((v, i) => v - am.pos[i]))); }
      for (const e of sc.events.splice(0)) {
        if (e.type === 'found') { this.alerts = (this.alerts || 0) + 1; this.onNotice?.('A FOREIGN SCOUT HAS SEEN YOU · it runs back to report', 'danger'); this.savePlayer(); }
        if (e.type === 'reported' || e.type === 'gave-up') {
          this.scene.remove(this.scout.view.root); this.scout = null; this.scoutT = this.level.scout.respawn;
          break;
        }
      }
    }
    // something huge below
    if (this.deep) {
      const loud = this.vib.events.filter((e) => e.source !== 'deep');
      const pulse = this.deep.step(dt, loud);
      if (pulse) {
        this.vib.emit(pulse.pos, pulse.strength, 'deep');
        const p = this.playerPos, d = Math.hypot(...pulse.pos.map((v, i) => v - p[i]));
        if (d < 18) this.sfx.rumble(d * 1.8);
        if (d < 10) { this.stability.addVibration([p[0], p[1] - 2, p[2]], 3); this.debris.burst([p[0], p[1] + 1.2, p[2]], [0, -1, 0], 3, 4); }
      }
    }
    // biting creatures with the mandibles (combat is optional, GDD §36)
    this._biteCool -= dt;
    if (antHere && this.input.isDown('dig') && this._biteCool <= 0) {
      const a = this.ant.aim();
      const hitC = (pos, r = 1.6) => { const v = pos.map((x, i) => x - a.eye[i]); const t = v[0] * a.dir[0] + v[1] * a.dir[1] + v[2] * a.dir[2]; return t > 0 && t < r && Math.hypot(v[0] - a.dir[0] * t, v[1] - a.dir[1] * t, v[2] - a.dir[2] * t) < 0.45; };
      if (this.spider && hitC(this.spider.brain.pos)) { this.spider.brain.hurt(); this._biteCool = 0.5; this.ant.bite(); this.onNotice?.('YOU BITE IT', 'caution'); }
      else if (this.scout && hitC(this.scout.brain.pos)) { this._biteCool = 0.5; this.ant.bite(); }
      else for (const b of this.beetles) if (hitC(b.brain.pos)) { b.brain.flee(am.pos); this._biteCool = 0.5; this.ant.bite(); }
    }
    for (const b of this.beetles) if (P && canSee(f, b.brain.pos, P, 2.5)) b.brain.see(P);
  }

  _collapse(f) {
    const plan = this.stability.planCollapse(f);
    this.world.collapse(plan, TestTunnelsScene.now());
    this.stability.settle(plan.carve.c, 3.5);
    const p = this.playerPos;
    const dist = Math.hypot(...plan.carve.c.map((v, i) => v - p[i]));
    this.sfx.rumble(dist);
    this.vib.emit(plan.carve.c, VIBRATION.collapse, 'world');
    this.stability.addVibration(plan.carve.c, VIBRATION.collapse);
    for (let k = 0; k < 4; k++) this.debris.burst(plan.carve.c, [0, -1, 0], plan.fill.material, 25);
    if (dist < 8) this.ant.kickT = 3;
    // anything caught under the rubble is pushed to the nearest open space
    const free = (motor) => {
      if (this.world.field.densityAt(...motor.pos) < -0.05) return false;
      const c = this.topology.nav.nearestOpen(motor.pos, 6);
      if (c >= 0) motor.place(this.topology.nav.worldPos(c), 0);
      return true;
    };
    const buried = this.mode === 'ant' && free(this.ant.motor);
    if (buried) this.survival.damage(25, 'collapse');
    for (const b of this.beetles) free(b.brain.motor);
    this.onNotice?.(buried ? 'COLLAPSE · you were caught in it' : 'COLLAPSE');
  }

  /** USE: pick up / drink what is aimed at; otherwise place a Resin Support (GDD §12). */
  use() {
    if (!this.ready || this.mode !== 'ant') return;
    if (this.armed) { this._placeArmed(); return; }
    const t = this.useTarget;
    if (t && t.kind === 'module') { if (t.m.type === 'terminal') this.flags.logRead = true; this.onModule?.(t.m.id); return; }
    if (t && t.kind === 'inspect') { this.onInspect?.(t); return; }
    if (t && t.kind === 'pickup') {
      if (!this.inventory.add(t.item, t.n)) { this.onNotice?.('TOO HEAVY · drop or use something (KIT)', 'caution'); return; }
      this.collected.add(t.id); this.pickups.remove(t); this.useTarget = null;
      this.onNotice?.(`+${t.n} ${ITEMS[t.item].name.toUpperCase()}`);
      this.savePlayer();
      return;
    }
    if (t && t.kind === 'water') {
      if (t.cooldown > 0) { this.onNotice?.('THE DRIP IS STILL GATHERING'); return; }
      this.survival.drink(SURVIVAL.waterSourceAmount); t.cooldown = SURVIVAL.waterSourceCooldown;
      this.onNotice?.('YOU DRINK FROM THE DRIP');
      return;
    }
    this.placeSupport();
  }

  placeSupport() {
    if (!this.ready || this.mode !== 'ant') return;
    if (!this.inventory.count('resin_support')) { this.onNotice?.('NO RESIN SUPPORT · craft one in KIT (2 resin + 1 chitin)', 'caution'); return; }
    const plan = planSupport(this.world.field, this.digger.target);
    if (!plan) { this.onNotice?.('NO SUPPORT HERE · aim at floor or ceiling, 0.8–6 u apart'); return; }
    this.inventory.remove('resin_support');
    this.world.addSupport(plan.a, plan.b);
    this.stability.addSupport(plan.a, plan.b);
    this.supportView.add(plan.a, plan.b);
    this.onNotice?.('RESIN SUPPORT PLACED');
  }

  /** Arms a placeable item: the next USE places it at the aimed floor (support: floor ↔ ceiling). */
  arm(id) {
    this.armed = id;
    this.onNotice?.(`PLACE ${ITEMS[id].name.toUpperCase()} · aim and press USE`);
  }

  _placeArmed() {
    const id = this.armed, kind = ITEMS[id].place;
    if (!this.inventory.count(id)) { this.armed = null; return; }
    if (kind === 'support') { this.armed = null; this.placeSupport(); return; }
    const t = this.digger.target;
    if (!t?.hit || t.normal[1] < 0.6) { this.onNotice?.('AIM AT THE FLOOR', 'caution'); return; }
    const p = [t.hit[0], t.hit[1] + 0.02, t.hit[2]];
    if (kind === 'camp') {
      // ADD §61: no building on unsafe ground
      if (this.stability.sources(p, 20, 3.5, 0).length) { this.onNotice?.('UNSTABLE FOUNDATION · support the roof first', 'danger'); return; }
      if (this.world.field.densityAt(p[0], p[1] + 1.2, p[2]) > 0) { this.onNotice?.('NOT ENOUGH ROOM FOR A CAMP', 'caution'); return; }
    }
    this.inventory.remove(id);
    const m = this.base.place(kind, p);
    m.floor = p;
    this.armed = this.inventory.count(id) && kind !== 'camp' ? id : null;
    this.baseView.sync(this.base);
    const linked = kind === 'camp' || this.base.linked.has(m.id);
    this.onNotice?.(kind === 'camp' ? 'FORWARD CAMP DEPLOYED · you will wake here' : linked ? `${MODULE_TYPES[kind].name} LINKED` : `${MODULE_TYPES[kind].name} PLACED · not linked (too far or no line of sight)`, linked ? '' : 'caution');
    this.saveBase(); this.savePlayer();
  }

  /** View model for the module panel. */
  moduleVM(id) {
    const m = this.base.get(id), T = MODULE_TYPES[m.type], inv = this.inventory;
    const need = T.repair?.[m.state];
    const has = (req) => Object.entries(req).map(([k, n]) => `${ITEMS[k].name} ${inv.count(k)}/${n}`).join(' · ');
    const stateLabel = m.state !== 'working' ? STATE_LABEL[m.state] : (T.draw > 0 && !m.powered ? STATE_LABEL.offline : STATE_LABEL.working);
    const vm = { title: T.name, state: stateLabel, stateClass: m.state === 'working' && (m.powered || !(T.draw > 0)) ? '' : m.state === 'degraded' || !m.powered ? 'caution' : 'danger',
      lines: [T.desc], actions: [] };
    const b = this.base;
    vm.lines.push(`Shelter power: ${b.used.toFixed(1)} used / ${b.supply.toFixed(1)} supply (demand ${b.demand.toFixed(1)})`);
    if (T.draw) vm.lines.push(`Draw: ${T.draw} · ${m.powered ? 'powered' : 'unpowered'}`);
    if (m.type === 'power') vm.lines.push(`Fuel: ${Math.round(m.fuel)}%  · burns faster the more modules run`);
    if (m.type === 'camp') vm.lines.push(`Battery: ${Math.round(m.battery)}%`);
    if (need) vm.actions.push({ act: 'repair', label: `Repair (${STATE_LABEL[m.state].toLowerCase()} → working)`, note: has(need), enabled: inv.has(need), btn: 'REPAIR' });
    if (m.type === 'power' || m.type === 'camp') vm.actions.push({ act: 'refuel', label: 'Insert chemical cell', note: `Chemical Cell ${inv.count('chemical_cell')}`, enabled: inv.count('chemical_cell') > 0, btn: 'INSERT' });
    if (m.type === 'condenser') vm.actions.push({ act: 'drink', label: 'Drink condensed water', note: this.condenserCooldown > 0 ? 'refilling…' : m.powered ? '' : 'needs power', enabled: m.powered && this.condenserCooldown <= 0, btn: 'DRINK' });
    if (m.type === 'fabricator') vm.actions.push({ act: 'fabricate', label: 'Build infrastructure', note: this.stations.fabricator ? '' : 'needs repair and power', enabled: this.stations.fabricator, btn: 'OPEN' });
    if (m.type === 'terminal') vm.log = MAINTENANCE_LOG;
    if (T.draw > 0 && m.state !== 'broken' && m.state !== 'damaged') vm.actions.push({ act: 'toggle', label: m.enabled === false ? 'Switched OFF — the budget skips it' : 'Switched ON', note: 'Free power for something else', enabled: true, btn: m.enabled === false ? 'TURN ON' : 'TURN OFF' });
    if (m.type === 'beacon' && m.state === 'working') vm.actions.push({ act: 'transmit', label: 'Transmit on the ritual band', note: m.powered ? '' : 'needs 2 power — switch other modules off', enabled: m.powered && !this.flags.transmitted, btn: 'TRANSMIT' });
    if (m.type === 'beacon' && m.state === 'working') vm.lines.push(m.powered ? 'Carrier up. Only static answers.' : 'Needs 2 power — switch something off or add a power node.');
    if (m.type === 'storage') vm.lists = [
      { title: `YOUR KIT ${inv.weight.toFixed(1)}/${inv.limit}`, rows: inv.list().filter((x) => !x.key).map((x) => ({ label: `${x.name} ×${x.n}`, act: 'store', arg: x.id, btn: 'STORE' })) },
      { title: 'STORAGE', rows: this.stash.list().map((x) => ({ label: `${x.name} ×${x.n}`, act: 'take', arg: x.id, btn: 'TAKE' })) },
    ];
    return vm;
  }

  /** @returns {'close'|'kit'|null} what the UI should do next */
  moduleAction(id, act, arg) {
    const b = this.base, m = b.get(id);
    let r = null;
    if (act === 'repair') {
      r = b.repair(id, this.inventory);
      if (r.ok) {
        this.onNotice?.(`${MODULE_TYPES[m.type].name} REPAIRED`);
        if (m.type === 'beacon') this.onNotice?.('BEACON REPAIRED · the carrier needs 2 power');
      }
    }
    if (act === 'refuel') r = b.refuel(id, this.inventory);
    if (act === 'toggle') { const on = b.toggle(id); this.onNotice?.(`${MODULE_TYPES[m.type].name} ${on ? 'ON' : 'OFF'}`); }
    if (act === 'transmit' && m.powered) { this.flags.transmitted = true; if (!this.storyOn) this.onNotice?.('CARRIER UP · only static answers'); return 'close'; }
    if (act === 'drink' && m.powered && this.condenserCooldown <= 0) { this.survival.drink(40); this.condenserCooldown = 15; this.onNotice?.('YOU DRINK CONDENSED WATER'); }
    if (act === 'store' && this.inventory.remove(arg)) this.stash.add(arg);
    if (act === 'take' && this.inventory.canAdd(arg) && this.stash.remove(arg)) this.inventory.add(arg);
    if (r && !r.ok) this.onNotice?.(r.reason.toUpperCase(), 'caution');
    this.baseView.sync(b); this.saveBase(); this.savePlayer();
    return act === 'fabricate' ? 'kit' : null;
  }

  /** NAV-CARAPACE actions. */
  useItem(id) {
    if (ITEMS[id]?.place) { this.arm(id); return 'armed'; }
    if (id === 'cargo_harness') { if (!this.inventory.remove(id)) return false; this.inventory.limit = 30; this.harness = true; this.onNotice?.('CARGO HARNESS ON · carry limit 30'); this.savePlayer(); return true; }
    if (!this.inventory.count(id) || !this.survival.use(id)) return false;
    this.inventory.remove(id);
    this.onNotice?.(`${ITEMS[id].verb} · ${ITEMS[id].name.toUpperCase()}`);
    this.savePlayer();
    return true;
  }
  dropItem(id) { if (this.inventory.remove(id)) this.savePlayer(); }
  craftItem(id) { const r = craft(this.inventory, id, this.stations); if (r.ok) { this.onNotice?.(`CRAFTED · ${ITEMS[r.item].name.toUpperCase()}`); this.savePlayer(); } return r; }

  _die() {
    const cause = this.survival.cause;
    if (this.story.active) this.story.s.stats.deaths++;
    this.survival.respawn();
    const camp = this.base.ofType('camp').filter((c) => c.battery > 0).at(-1);
    const where = camp ? camp.pos : this.discovered ? this.level.shelter.respawn : this.level.spawn.pos;
    this.ant.place(where, this.level.spawn.yaw);
    this.onNotice?.(`YOU BLACK OUT (${cause}) · you wake ${camp ? 'at your camp' : this.discovered ? 'in the shelter' : 'where you started'}`, 'danger');
    this.savePlayer();
  }

  /** SCAN: coarse structural read-out (ADD §63). */
  scan() {
    if (!this.ready) return;
    const n = this.scanner.show(this.stability.sources(this.playerPos, 40, 16, 1.0));
    this.scentView.pulse(8);
    this.onNotice?.(`SENSE · scent trails${n ? ` · ${n} unstable spot${n > 1 ? 's' : ''}` : ''}`);
  }

  preUpdate() { if (this.ready && this.mode === 'ant') this.ant.preUpdate(); }

  static now() { return performance.now() / 1000; }

  fixedUpdate(dt) {
    if (!this.ready) return;
    for (const b of this.beetles) {
      b.brain.step(dt);
      this.atmosphere.deposit('beetle', b.brain.pos, 0.4 * dt);
      if (b.brain.motor.mode === 'surface' && b.brain.motor.speed > 0.2) this.stability.addTraffic(b.brain.pos.map((v, i) => v - b.brain.motor.up[i] * 0.4), dt, 0.3);
    }
    this._creatures(dt);
    const am = this.ant.motor;
    if (this.mode === 'ant') {
      this.survival.update(dt, { air: this.airQuality, running: this.input.isDown('fast') && am.speed > 0.3 });
      if (this.survival.dead) this._die();
      if (this.survival.scentMask <= 0) this.atmosphere.deposit('player', am.pos, 1.5 * dt);
      this.atmosphere.consume(am.pos, 0.002 * dt);
      if (am.mode === 'surface' && am.speed > 0.3) {
        const run = this.input.isDown('fast');
        this.stability.addTraffic(am.pos.map((v, i) => v - am.up[i] * 0.45), dt, run ? 2 : 1);
        this._stepT -= dt;
        if (this._stepT <= 0) {
          this._stepT = run ? 0.25 : 0.4; this.vib.emit(am.pos, run ? VIBRATION.run : VIBRATION.step, 'player');
          const mat = this.world.field.materialAt(am.pos[0] - am.up[0] * 0.45, am.pos[1] - am.up[1] * 0.45, am.pos[2] - am.up[2] * 0.45);
          this.sfx.step(MATERIALS[mat]?.hardness ?? 0.4, run);
        }
      }
    }
    for (const f of this.stability.update(dt, this.playerPos)) this._collapse(f);
    if (this.mode !== 'ant') { this.noclip.fixedUpdate(dt); return; }
    const a = this.ant.aim();
    const bites = this.digger.update(dt, {
      held: this.input.isDown('dig'), eye: a.eye, dir: a.dir, up: this.ant.motor.up,
      eyeHeight: CONFIG.ant.hover + CONFIG.camera.eyeOffset, now: TestTunnelsScene.now(), canDig: this.ant.motor.mode === 'surface',
      allow: this.survival.canBite(this.digger.tool.id),
    });
    this.ant.digging = this.input.isDown('dig') && this.digger.target.status === 'ok';
    for (const b of bites) {
      this.survival.bite(this.digger.tool.id);
      this.ant.bite();
      this.sfx.bite(MATERIALS[b.material]?.hardness ?? 0.5);
      const vs = VIBRATION.bite[this.digger.tool.id] ?? 0.6;
      this.vib.emit(b.center, vs, 'player');
      this.stability.addVibration(b.center, vs);
      const hit = this.digger.target.hit || b.center;
      this.debris.burst(hit, b.normal, b.material, CONFIG.dig.debrisPerBite);
    }
    this.ant.fixedUpdate(dt);
  }

  update(dt) {
    this.terrainMaterial.userData.terrainUniforms.uTime.value = TestTunnelsScene.now();
    if (!this.ready) { this.noclip.update(dt); return; }
    this.world.focus = this.playerPos;
    this.world.tick(dt);
    this.debris.update(dt);
    for (const ev of this.topology.tick(dt)) {
      for (const b of this.beetles) b.brain.notice(ev);
      this.onTopologyEvent?.(ev);
    }
    for (const b of this.beetles) b.view.update(dt, b.brain.motor);
    if (this.spider) this.spider.view.update(dt, this.spider.brain.motor, 0.12);
    if (this.scout) this.scout.view.update(dt, this.scout.brain.motor, 0.1);
    this._updateStressVisuals(dt);
    this.scanner.update(dt);
    this._updateSenses(dt);
    this._storyTick(dt);
    this._cull(dt);
    this.lightPool.update(dt, this.playerPos);
    this._hintTick(dt);
    this.pickups.update(dt);
    this._revealT -= dt;
    if (this._revealT <= 0) { this._revealT = 0.25; this.exploration.reveal(this.playerPos, 5); if (this.mode === 'ant') this.exploration.addRoute(this.playerPos); }
    this.scentView.update(dt, this.atmosphere, this.topology.nav, this.playerPos, this.exploration);
    this.base.update(dt);
    this.baseView.update(dt, this.base);
    if (this.condenserCooldown > 0) this.condenserCooldown -= dt;
    this._baseT -= dt;
    if (this._baseT <= 0) { this._baseT = 0.5; this.baseView.sync(this.base); this.atmosphere.setSources(this.base.airSources()); }
    if (this.mode === 'ant') {
      const a = this.ant.aim();
      const mod = this.baseView.aimed(this.base, a.eye, a.dir);
      const pk = this.pickups.aimed(a.eye, a.dir);
      const ins = this.inspectables.aimed(a.eye, a.dir);
      this.useTarget = mod ? { kind: 'module', m: mod } : ins || pk;
    } else this.useTarget = null;
    const inShelter = this.level.shelter?.zones.includes(this.zone);
    if (inShelter && !this.discovered) { this.discovered = true; this.onNotice?.('RITUAL SHELTER · you made it. You will wake here from now on.'); this.saveBase(); }
    this.shelterLine = inShelter ? `PWR ${this.base.used.toFixed(1)}/${this.base.supply.toFixed(1)} · FUEL ${Math.round(this.base.get('power')?.fuel ?? 0)}%` : '';
    this._saveT = (this._saveT || 0) + dt;
    if (this._saveT > 3) { this._saveT = 0; this.savePlayer(); this.saveBase(); this.saveExplore(); if (this.storyOn) this.saveStory(); }
    const bb = this.beetles[0]?.brain;
    this.graphView.update(this.topology, bb?.path ? [bb.pos.slice(), ...bb.path.slice(bb.wi)] : null, this.atmosphere, dt);
    if (this.mode === 'ant') this.ant.update(dt); else this.noclip.update(dt);
    this._zoneT += dt;
    if (this._zoneT > 0.3) { this._zoneT = 0; const p = this.playerPos; this.zone = this.world.zoneAt({ x: p[0], y: p[1], z: p[2] }); }
    this._updateCourse(dt);
  }

  _updateSenses(dt) {
    this.atmosphere.update(dt);
    const p = this.playerPos;
    const q = (this.airQuality = this.atmosphere.quality(p));
    // bad air thickens the haze (AB §34: preserve darkness, no false-colour screens)
    const R = CONFIG.render;
    this.scene.fog.far = R.fogFar * this.fogScale * (0.4 + 0.6 * q);
    this.scene.fog.near = R.fogNear * (0.3 + 0.7 * q);
    if (q < 0.6 && !this._airWarned) { this._airWarned = true; this.onNotice?.(q < 0.4 ? 'AIR QUALITY CRITICAL' : 'AIR QUALITY LOW', q < 0.4 ? 'danger' : 'caution'); }
    if (q > 0.75) this._airWarned = false;
    // vibration: beetles react; the player feels others' strong vibrations
    for (const b of this.beetles) b.brain.feel(this.vib.feel(b.brain.pos, 'beetle'));
    const cam = this.app.camera;
    const fwd = this._v3.set(0, 0, -1).applyQuaternion(cam.quaternion).toArray();
    const cup = new THREE.Vector3(0, 1, 0).applyQuaternion(cam.quaternion).toArray();
    for (const e of this.vib.feelAll(p, 'player')) this.vibSense.feel(e, cam.position.toArray(), fwd, cup);
    this.vibSense.update(dt);
    this._vibCool -= dt;
    const ev = this.vib.feel(p, 'player');
    this._deepNoticeT -= dt;
    if (ev && ev.source === 'deep') {
      if (ev.received > 0.1 && this._deepNoticeT <= 0) { this._deepNoticeT = 25; this.onNotice?.(`A DEEP RUMBLE ${this._direction(ev.pos)} · something huge moves in the rock`, 'caution'); }
    } else if (ev && ev.source === 'scout' && !this._scoutNoticed) { this._scoutNoticed = true; this.onNotice?.(`FOOTSTEPS ${this._direction(ev.pos)} · something walks your trail`, 'caution'); }
    else if (ev && ev.received > 0.15 && this._vibCool <= 0) { this._vibCool = 3; this.onNotice?.(`VIBRATION ${this._direction(ev.pos)}`, 'caution'); }
    this.vib.clear();
  }

  /** Arrow + word for where a world point lies relative to the view. */
  _direction(pos) {
    const cam = this.app.camera;
    const v = this._v3.set(pos[0], pos[1], pos[2]).sub(cam.position).applyQuaternion(cam.quaternion.clone().invert());
    const h = Math.atan2(v.x, -v.z), el = Math.atan2(v.y, Math.hypot(v.x, v.z));
    if (el < -0.9) return '↓ below'; if (el > 0.9) return '↑ above';
    const arrows = ['↑ ahead', '↗', '→ right', '↘', '↓ behind', '↙', '← left', '↖'];
    return arrows[((Math.round(h / (Math.PI / 4)) % 8) + 8) % 8];
  }

  /** P13 control tips — each once, by situation. */
  _hintTick(dt) {
    if (!this.started || !this.input.enabled) return;
    this.playT += dt;
    const t = this.digger.target;
    this._aimOkT = t?.status === 'ok' ? this._aimOkT + dt : 0;
    this._hintT += dt;
    if (this._hintT < 0.2) return;
    const step = this._hintT; this._hintT = 0;
    const p = this.playerPos, m = this.ant.motor;
    const ctx = {
      playing: this.mode === 'ant', t: this.playT,
      signal: this.storyOn && this.story.signal,
      nearLamp: this.pathLamps.some((l) => Math.hypot(...l.pos.map((v, i) => v - p[i])) < 3),
      wallAhead: !!t?.hit && t.dist < 0.9 && Math.abs(t.normal[1]) < 0.5, onWall: m.mode === 'surface' && m.up[1] < 0.4,
      aimPickup: this.useTarget?.kind === 'pickup', pickedUp: this.collected.size > 0,
      aimDiggable: this._aimOkT, air: this.airQuality,
      vibroEmpty: this.digger.tool.id === 'vibropick' && !this.survival.canBite('vibropick'),
      stressNear: this.stressSources.some((x) => x.state >= State.STRESSED),
    };
    const h = this.hints.update(step, ctx, document.body.classList.contains('is-touch'));
    if (h) { this.onHint?.(h.text); try { storage?.setItem('formica.hints', JSON.stringify(this.hints.toJSON())); } catch { /* ignore */ } }
  }

  /** Quality preset from settings (P12.1). */
  applyQuality(preset) {
    this.fogScale = preset.fog;
    this.terrainMaterial.setLow?.(preset.terrainLow);
  }

  /** Underground occlusion (ADD §37): chunks beyond the fog are not drawn; far landmark lights go dark. */
  _cull(dt) {
    this._cullT -= dt;
    if (this._cullT > 0) return;
    this._cullT = 0.3;
    const cam = this.app.camera.position, far = this.scene.fog.far + 4;
    let vis = 0;
    for (const m of this.terrain.meshes.values()) {
      const bs = m.geometry.boundingSphere;
      if (!bs) continue;
      const d = Math.hypot(bs.center.x - cam.x, bs.center.y - cam.y, bs.center.z - cam.z) - bs.radius;
      m.visible = d < far; if (m.visible) vis++;
    }
    this.visibleChunks = vis;

  }

  _updateStressVisuals(dt) {
    const p = this.playerPos;
    const src = (this.stressSources = this.stability.sources(p, 8));
    const u = this.terrainMaterial.userData.terrainUniforms.uStress.value;
    for (let i = 0; i < 8; i++) {
      const s = src[i];
      if (s) u[i].set(s.pos[0], s.pos[1], s.pos[2], Math.max(0.05, s.state === State.CRITICAL ? 0.7 + s.level * 0.3 : s.state === State.FRACTURED ? 0.4 + s.level * 0.3 : 0.1 + s.level * 0.3));
      else u[i].set(0, 0, 0, 0);
    }
    // dust and audible stress from fractured / critical roofs
    this._creakT -= dt;
    for (const s of src) {
      if (s.state < State.FRACTURED) continue;
      const rate = s.state === State.CRITICAL ? 6 : 1.5;
      if (Math.random() < rate * dt) this.debris.burst([s.pos[0], s.pos[1] - 0.45, s.pos[2]], [0, -0.3, 0], 1, s.state === State.CRITICAL ? 3 : 1);
      if (s.state === State.CRITICAL && this._creakT <= 0) { this.sfx.creak(s.level, s.d); this._creakT = 0.4 + Math.random() * 1.2; }
    }
  }

  _updateCourse(dt) {
    if (this.mode === 'ant') {
      const moving = this.input.move.mag > 0.1 || this.ant.motor.mode === 'air';
      const ev = this.course.update(dt, this.ant.motor.pos, moving);
      if (ev) {
        this.markers.sync();
        this.flash = ev.type === 'gate' ? `✓ ${ev.gate.name}` : `FINISH ${formatTime(ev.time)}${ev.record ? ' · RECORD' : ''}`;
        this.flashT = ev.type === 'gate' ? 1.5 : 6;
      }
    }
    this.markers.update(dt);
    if (this.flashT > 0) this.flashT -= dt;
    const c = this.course, n = c.def.gates.length;
    if (this.storyOn || this.hideCourse) { this.markers.meshes.forEach((m) => { m.visible = false; }); this.markers.light.visible = false; this.courseText = ''; return; }
    const head = this.flashT > 0 ? this.flash : c.finished ? `DONE ${formatTime(c.time)}` : `${c.index + 1}/${n} ${c.next.name}`;
    this.courseText = `${head} · ${formatTime(c.time)} · ★ ${c.best === null ? "—" : formatTime(c.best)}`;
  }

  debugText() {
    const p = this.playerPos, s = this.world.stats, m = this.ant.motor;
    const inside = this.world.densityAt({ x: p[0], y: p[1], z: p[2] }) > 0 ? ' (in rock)' : '';
    const ant = this.mode === 'ant'
      ? `ant ${m.mode} dist ${m.surfaceDist.toFixed(2)} spd ${m.speed.toFixed(1)}\nup ${m.up.map((v) => v.toFixed(2)).join(',')} cam ${this.ant.cameraMode}`
      : 'noclip';
    return `pos ${p.map((v) => v.toFixed(1)).join(',')}${inside}
zone ${this.zone || '-'}
${ant}
chunks ${s.meshed}/${s.chunks} (visible ${this.visibleChunks ?? '-'}) · ${this.world.threads} workers · ${s.triangles} tris
time fixed ${this.app.timing.fixed.toFixed(1)} · update ${this.app.timing.update.toFixed(1)} · render ${this.app.timing.render.toFixed(1)} ms · q ${this.app.quality} @${this.app.renderer.getPixelRatio().toFixed(2)}
load ${s.loadMs.toFixed(0)}ms (gen ${s.genMs.toFixed(0)} / mesh ${s.meshMs.toFixed(0)})
dig ${this.digger.tool.id} · ops ${s.ops} · remesh ${s.remeshes} (${s.lastRemeshMs.toFixed(0)}ms) · dirty ${this.world.dirty.size}
topo ${this.topology?.cavityCount ?? '-'} cavities · ${this.topology?.graph.nodes.length ?? 0} regions · rebuilds ${this.topology?.stats.rebuilds ?? 0}
beetle ${this.beetles[0]?.brain.state ?? '-'} · spider ${this.spider?.brain.state ?? '-'} · scout ${this.scout ? this.scout.brain.state : `in ${Math.max(0, this.scoutT).toFixed(0)}s`} · deep y${this.deep ? this.deep.pos[1].toFixed(0) : '-'}${this.survival.scentMask > 0 ? ' · MASK ' + Math.ceil(this.survival.scentMask) : ''}
air ${this.airQuality.toFixed(2)} · scent ${this.atmosphere ? this.atmosphere.scentAt('player', this.playerPos).toFixed(2) : '-'}
vitals HP ${this.survival.health.toFixed(0)} EN ${this.survival.energy.toFixed(1)} W ${this.survival.hydration.toFixed(1)} B ${this.survival.breath.toFixed(0)} cell ${this.survival.toolCharge.toFixed(0)} · kit ${this.inventory.weight}/${this.inventory.limit}
stress ${this.stressSources.map((x) => ['S', 's', 'F', 'C'][x.state]).join('') || '-'} · collapses ${this.stability?.stats.collapses ?? 0} · supports ${this.world.supports.length}
spoil ${Object.entries(this.world.spoil).map(([m, v]) => `${MATERIALS[m].key} ${v.toFixed(1)}`).join(' ') || '-'}`;
  }
}
