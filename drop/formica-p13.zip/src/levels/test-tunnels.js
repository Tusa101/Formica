// "Test Tunnels" — technical test level for P01–P05 (ADD §77, §79; GDD §65-A).
// Pure data. Units: ant metres (ant ≈ 1.0 long). Chunk grid covers x,z ∈ [-32, 32), y ∈ [-16, 16).
export const TEST_TUNNELS = {
  id: 'test-tunnels',
  seed: 1337,
  blend: 1.0,
  chunks: { min: [-2, -1, -2], max: [1, 0, 1] }, // inclusive chunk index range
  geology: {
    warp: 2.5, soilTop: 7.5, clayTop: 1.5, sandTop: -5, sandLens: 0.18,
    // loose rubble plugging the Shelter's collapsed chamber — diggable with mandibles
    overrides: [{ c: [16, -4.5, -8.6], r: 2.3, material: 2 }],
  },
  spawn: { pos: [-12.5, -1.2, 1.5], yaw: -Math.PI / 2, pitch: -0.1 },

  cavities: [
    // ADD §77: Room A | solid wall (~2.5) | Room B. The wall is dug through in P03.
    { name: 'Room A', type: 'ellipsoid', c: [-12.5, 0, 0], r: [5, 3, 5] },
    { name: 'Room B', type: 'ellipsoid', c: [-0.5, 0, 0], r: [4.5, 3.2, 4.5] },
    // Long way round A → B (south loop)
    { name: 'South Loop', type: 'tube', r: 1.1, points: [[-13, -1.6, -3.5], [-15, -1.4, -12], [-6, -0.8, -19], [4, -1.2, -13], [1, -1.6, -3.5]] },
    // Vertical shaft up from Room B to the upper gallery
    { name: 'Shaft', type: 'capsule', a: [2.2, 1.5, 2], b: [2.2, 12, 2], r: 1.3 },
    { name: 'Upper Gallery', type: 'tube', r: 1.5, points: [[2.2, 12, 2], [10, 12.5, 3], [16, 11.5, 6], [18.5, 9.5, 8.5]] },
    // Wide hall with a pit in the floor: crossing it means walking on walls / ceiling
    { name: 'Pit Hall', type: 'ellipsoid', c: [20, 7, 10], r: [6.5, 4, 6.5] },
    { name: 'The Pit', type: 'capsule', a: [20, 5, 10], b: [20, -10, 10], r: 3.2 },
    { name: 'Far Ledge', type: 'ellipsoid', c: [21, 6.5, 18.5], r: [3, 2.2, 3] },
    // Low tunnel from the pit bottom back to Room B (closes the vertical loop)
    { name: 'Deep Tunnel', type: 'tube', r: 1.1, points: [[20, -10, 10], [12, -6, 6], [4, -2.2, 1.5]] },
    // Narrow squeeze (Ø 1.2) from Room A to a hidden niche
    { name: 'Squeeze', type: 'tube', r: 0.6, points: [[-13, -0.5, 4.2], [-16.5, -0.3, 13], [-8, -0.2, 19]] },
    { name: 'Niche', type: 'ellipsoid', c: [-5.5, 0, 20], r: [2.6, 1.8, 2.6] },
    // P08: Ritual Shelter (ADD §8) — reached from the South Loop. [STORAGE]–[CENTRAL]–[AIR], FABRICATOR south,
    // POWER below it, a collapsed chamber north (the broken Beacon waits behind the rubble).
    { name: 'Shelter Passage', type: 'tube', r: 1.0, points: [[4, -1.3, -13.2], [8, -2.6, -14], [11.5, -3.6, -14]] },
    { name: 'Shelter', type: 'ellipsoid', c: [16, -4, -14], r: [3.6, 2.3, 3.6] },
    { name: 'Storage Room', type: 'ellipsoid', c: [11.5, -4, -14], r: [2.1, 1.7, 2.1] },
    { name: 'Air Room', type: 'ellipsoid', c: [21, -4, -14], r: [2.2, 1.7, 2.2] },
    { name: 'Fabricator Room', type: 'ellipsoid', c: [16, -4, -19], r: [2.2, 1.7, 2.1] },
    { name: 'Power Room', type: 'ellipsoid', c: [16, -7.6, -19.6], r: [1.9, 1.4, 1.9] },
    { name: 'Power Shaft', type: 'capsule', a: [16, -4.5, -19.6], b: [16, -7.2, -19.6], r: 0.9 },
    { name: 'Collapsed Chamber', type: 'ellipsoid', c: [16, -4.2, -6.0], r: [2.4, 1.7, 2.2] },
    // P11: the ritual route the escorts came by — sealed behind the initiate at the start of the rite
    { name: 'Ritual Route', type: 'tube', r: 1.0, points: [[-16.8, -2, 0.5], [-21, -1.6, -0.5], [-26, -1.3, 0.3]] },
    // P04: sealed cavity north of Room B (wall ~2.5). Home of the test beetle; opened only by digging.
    { name: 'Sealed Chamber', type: 'ellipsoid', c: [0, -0.8, 9.6], r: [3, 2, 2.6] },
  ],

  // P06 atmosphere: the Sealed Chamber holds stale, CO₂-rich air (ADD §78); the shaft top vents to fresh air.
  air: {
    zones: [
      { zone: 'Sealed Chamber', o2: 0.3, co2: 0.65, tox: 0.05 },
      // the shelter's air has gone stale while the processor ran degraded (GDD §63: "repair damaged Air Generator")
      ...['Shelter', 'Storage Room', 'Air Room', 'Fabricator Room', 'Power Room', 'Power Shaft'].map((zone) => ({ zone, o2: 0.7, co2: 0.3, tox: 0 })),
      { zone: 'Collapsed Chamber', o2: 0.5, co2: 0.3, tox: 0.1 },
    ],
    vents: [{ pos: [2.2, 12.5, 2], radius: 1.6 }],
    // an old CO₂ seep under the shelter floor — why the shelter needs its Air Processor
    seeps: [{ pos: [16, -7.8, -19.6], radius: 1.8, co2: 0.15, o2: 0.05 }],
  },

  // P07 resources (GREYBOX props). Positions are dropped onto the floor below at load time.
  pickups: [
    { id: 'a-resin-1', item: 'resin', pos: [-15.5, -1, 2.5] },
    { id: 'a-resin-2', item: 'resin', pos: [-9.5, -1, -2.5] },
    { id: 'a-fungus', item: 'fungus', n: 2, pos: [-14, -1, -3] },
    { id: 'a-seed', item: 'seed', pos: [-11, -1, 3.2] },
    { id: 'a-scrap', item: 'scrap', pos: [-13.5, -1, 0.5] },
    { id: 'loop-fungus', item: 'fungus', n: 2, pos: [-15, -1, -12] },
    { id: 'loop-resin', item: 'resin', pos: [-6, -0.5, -19] },
    { id: 'loop-chitin', item: 'chitin', pos: [4, -1, -13] },
    { id: 'b-chitin', item: 'chitin', n: 2, pos: [-2.5, -1, -2] },
    { id: 'b-seed', item: 'seed', pos: [1.5, -1, 1] },
    { id: 'gal-seed', item: 'seed', pos: [10, 12.5, 3] },
    { id: 'gal-chitin', item: 'chitin', pos: [14, 12, 5] },
    { id: 'hall-resin-1', item: 'resin', n: 2, pos: [24.5, 6, 11] },
    { id: 'hall-fungus', item: 'fungus', n: 2, pos: [16, 6, 12] },
    { id: 'ledge-scrap', item: 'scrap', n: 2, pos: [21, 6.5, 19] },
    { id: 'deep-fungus', item: 'fungus', pos: [12, -6, 6] },
    { id: 'deep-scrap', item: 'scrap', pos: [16, -8, 8] },
    { id: 'niche-chitin', item: 'chitin', n: 2, pos: [-5.5, 0.5, 21] },
    { id: 'niche-scrap', item: 'scrap', pos: [-4.5, 0.5, 19.5] },
    { id: 'sealed-fungus', item: 'fungus', n: 3, pos: [1, -1, 9.6] },
    { id: 'sealed-resin', item: 'resin', n: 2, pos: [-1.5, -1, 10] },
  ],
  // Condensate drips: infinite water with a cooldown.
  waterSources: [
    { id: 'drip-b', pos: [-3, -1, 2.5] },
    { id: 'drip-hall', pos: [14.8, 6, 10] },
    { id: 'drip-loop', pos: [-14.5, -1, -8] },
  ],

  // P11 Root Forest: giant roots through the Upper Gallery and over the Pit — solid, climbable (GDD §9).
  roots: [
    { r: 0.38, points: [[6, 15.6, 2.2], [6.6, 12.5, 3.2], [7.2, 9.5, 3.6]] },
    { r: 0.42, points: [[12, 15.6, 4.6], [11.6, 12.6, 3.6], [12.2, 10, 2.4]] },
    { r: 0.45, points: [[17, 11.4, 12.6], [18.6, 5, 11.8], [19, -2, 11], [19.5, -7, 10.5]] },
    // hanging root tips
    { r: 0.3, points: [[22, 11.4, 6], [22.8, 8.6, 6.5]] },
    { r: 0.3, points: [[15, 10.8, 12], [14.8, 8.2, 12.4]] },
    { r: 0.28, points: [[-2, 3.6, -1.5], [-1.6, 1.4, -1.2]] },
  ],

  // P11 story: spawn in the Ritual Route, what is sealed, the old partial collapse in the South Loop, inspectables.
  rite: {
    spawn: { pos: [-21.2, -1.6, -0.4], yaw: -Math.PI / 2 },
    seal: [{ c: [-24.2, -1.4, -0.1], r: 1.6 }, { c: [-25.8, -1.3, 0.3], r: 1.5 }],
    loopRubble: [{ c: [-15, -2.6, -12], r: 1.3 }],
    signal: [16, -5.2, -14],
    // P13: old ritual lamps along the initiates' way to the shelter (ADD §6 "remnants of old ritual infrastructure")
    lampPath: [[-21.2, -1.6, -0.4], [-17, -1.8, 0.3], [-14, -1.5, -1], [-13, -1.6, -3.5], [-15, -1.4, -12], [-6, -0.8, -19],
      [4, -1.2, -13], [8, -2.6, -14], [11.5, -3.6, -14], [14, -4, -14], [16.5, -4.4, -14.5]],
    shift: { carve: [[16, -4.9, -10.5], [16, -4.8, -9.4], [16, -4.7, -8.3]], r: 0.95, rubble: { c: [15.2, -5.8, -11.8], r: 0.7 }, lure: [16, -9, -14] },
    inspectables: [
      { id: 'sign', pos: [-13.6, -2.3, -3.2], title: 'OLD RITUAL MARK', text: 'A pheromone glyph cut into the wall, hundreds of cycles old: RETURN ↑ WEST. The way west is the way you came — and it is rubble now.' },
      { id: 'foil', pos: [-10.5, -2.4, 2.6], title: 'SILVER HILL', text: 'Aluminium foil, crumpled into a hill of silver. Human debris. It still smells faintly of sugar.' },
      { id: 'canister', pos: [-15.2, -1.4, -9.4], title: 'EMPTY CANISTER', text: 'An emergency air canister of formic make. The valve is open. Whoever carried it needed air badly.' },
      { id: 'mark', pos: [-6, -0.8, -18.6], title: 'FOREIGN MARKING', text: 'A faint pheromone marking, cycles old. Your NAV-CARAPACE cannot decode the dialect. Not from home.' },
      { id: 'comb', pos: [3, -1.2, -12.2], title: 'CARVED COMB', text: 'A small chitin comb. A name is scratched on it: TAVI, 391. Initiates were never meant to lose their things.' },
      { id: 'hair', pos: [1.6, -2.3, -2.2], title: 'MAMMAL HAIR', text: 'A single hair, thick as a root. Something enormous once walked the world above.' },
      { id: 'names', pos: [14.6, -4.3, -10.9], title: 'NAMES ON THE WALL', text: 'Names scratched into the shelter wall, each with a cycle: ORU 377 · MENNA 383 · TAVI 391 · KESS 396 · ILAN 402. Nobody after 402.' },
    ],
  },

  // P08: Ritual Shelter modules (ADD §8 initial states). Positions are dropped onto the floor at load time.
  shelter: {
    zone: 'Shelter',
    zones: ['Shelter', 'Storage Room', 'Air Room', 'Fabricator Room', 'Power Room', 'Power Shaft', 'Shelter Passage', 'Collapsed Chamber'],
    respawn: [16, -5.2, -14],
    modules: [
      { id: 'storage', type: 'storage', pos: [11.3, -4, -14.8], state: 'working' },
      { id: 'lights', type: 'lighting', pos: [16, -2, -14], state: 'working' },
      { id: 'condenser', type: 'condenser', pos: [13.6, -4, -12.2], state: 'working' },
      { id: 'terminal', type: 'terminal', pos: [17.6, -4, -12.4], state: 'working' },
      { id: 'power', type: 'power', pos: [16, -7.6, -19.9], state: 'degraded', fuel: 55 },
      { id: 'air', type: 'air', pos: [21.4, -4, -14], state: 'degraded' },
      { id: 'fabricator', type: 'fabricator', pos: [17.6, -4, -18.4], state: 'damaged' },
      { id: 'beacon', type: 'beacon', pos: [16.4, -4.2, -5.6], state: 'broken' },
    ],
  },

  // P04 creatures (GREYBOX)
  creatures: [
    { kind: 'beetle', pos: [0, -1.5, 9.6] },
    // P10: territorial spider on the Pit Hall rim (the course passes it — avoidable)
    { kind: 'spider', pos: [23.5, 5, 13] },
  ],
  // P10: foreign scout — leaves the Niche after ~90 s and patrols the hubs until it smells the ant
  scout: { home: [-5.5, -0.5, 20], delay: 90, respawn: 300,
    patrol: [[-12.5, -2, 0], [-6, -0.8, -19], [-0.5, -2, 0], [4, -1.2, -13], [12, -3, -14], [-13, -0.5, 4.2]] },
  // P10: something huge, far below (never above y = −6)
  deep: { loop: [[18, -13, 6], [8, -14, -4], [-6, -13.5, -10], [-14, -13, 4], [2, -14, 14]] },

  // P02 traversal course (ROADMAP 2.6). Gates must sit in empty space (checked by tests).
  course: {
    id: 'test-tunnels-traverse',
    gates: [
      { name: 'South Loop', pos: [-6, -0.8, -19], r: 2 },
      { name: 'Room B', pos: [-0.5, -1, 0], r: 2.2 },
      { name: 'Upper Gallery', pos: [10, 12.5, 3], r: 2 },
      { name: 'Far Ledge', pos: [21, 6.5, 18.5], r: 2 },
      { name: 'Deep Tunnel', pos: [12, -6, 6], r: 2 },
      { name: 'Niche', pos: [-5.5, 0, 20], r: 2 },
    ],
  },

  // Landmarks. Every light has a physical source (AB §10). Props are GREYBOX until PIPE §43 assets exist.
  lights: [
    { kind: 'ritual-lamp', pos: [-15.5, -2.4, -1.5], color: 0xe0a64a, intensity: 5, distance: 11 },
    { kind: 'fungus', pos: [1.5, -2.6, -2.5], color: 0x5fd0b0, intensity: 5, distance: 9 },
    { kind: 'fungus', pos: [21, 4.6, 19], color: 0x5fd0b0, intensity: 6, distance: 10 },
    { kind: 'fungus', pos: [-5.2, -1.4, 21], color: 0x7fd07a, intensity: 4, distance: 7 },
  ],
};
