// Contextual control tips (P13). Separate from the mother's recordings (ADD §3: recordings are not a tutorial).
// Each tip fires once, one at a time; texts differ for touch and keyboard. Pure JS.
export const HINTS = [
  { id: 'move', when: (c) => c.playing && c.t > 1.5, touch: 'Left side: move · right side: look around', desk: 'WASD — move · mouse — look' },
  { id: 'signal', when: (c) => c.signal && c.t > 6, touch: 'Top: the SHELTER SIGNAL — a direction, not a path', desk: 'Top: the SHELTER SIGNAL — a direction, not a path' },
  { id: 'lamps', when: (c) => c.nearLamp && c.t > 10, touch: 'Old ritual lamps mark the way initiates walked', desk: 'Old ritual lamps mark the way initiates walked' },
  { id: 'walls', when: (c) => c.wallAhead || c.onWall, touch: 'Keep walking into a wall — you climb it. JUMP lets go', desk: 'Keep walking into a wall — you climb it. SPACE lets go' },
  { id: 'use', when: (c) => c.aimPickup, touch: 'USE picks it up', desk: 'E / right mouse — pick up' },
  { id: 'kit', when: (c) => c.pickedUp, touch: 'KIT — inventory and field crafting', desk: 'TAB — inventory and field crafting' },
  { id: 'dig', when: (c) => c.aimDiggable > 1.2, touch: 'Hold DIG to bite through soft rock', desk: 'Hold left mouse to bite through soft rock' },
  { id: 'air', when: (c) => c.air < 0.7, touch: 'AIR is dropping — stale air drains your breath. Move on', desk: 'AIR is dropping — stale air drains your breath. Move on' },
  { id: 'cell', when: (c) => c.vibroEmpty, touch: 'The Vibro Pick runs on chemical cells — LOAD one in KIT', desk: 'The Vibro Pick runs on chemical cells — LOAD one in KIT (TAB)' },
  { id: 'map', when: (c) => c.t > 120, touch: 'MAP — everything you have seen, and your markers', desk: 'M — map of everything you have seen, and markers' },
  { id: 'scan', when: (c) => c.stressNear || c.t > 200, touch: 'SCAN — sense scent trails and unstable rock', desk: 'Q — sense scent trails and unstable rock' },
];

export class Hints {
  constructor(seen = [], { enabled = true, gap = 2.5, show = 7 } = {}) {
    this.seen = new Set(seen); this.enabled = enabled;
    this.gap = gap; this.show = show;
    this.current = null; this.timer = 0; this.cool = 0;
  }
  /** @returns {{id:string, text:string}|null} a tip to show now (the caller displays it for `show` seconds) */
  update(dt, ctx, touch) {
    if (this.current) { this.timer -= dt; if (this.timer <= 0) { this.current = null; this.cool = this.gap; } return null; }
    if (this.cool > 0) { this.cool -= dt; return null; }
    if (!this.enabled) return null;
    for (const h of HINTS) {
      if (this.seen.has(h.id) || !h.when(ctx)) continue;
      this.seen.add(h.id); this.current = h.id; this.timer = this.show;
      return { id: h.id, text: touch ? h.touch : h.desk };
    }
    return null;
  }
  toJSON() { return [...this.seen]; }
}
