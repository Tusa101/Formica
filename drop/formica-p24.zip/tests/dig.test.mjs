import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { meshChunk } from '../src/world/surface-nets.js';
import { carveSphere } from '../src/world/terrain-ops.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { DigLog } from '../src/world/persistence.js';
import { TEST_TUNNELS } from '../src/levels/test-tunnels.js';
import { MATERIALS, MAT } from '../src/data/materials.js';
import { TOOLS } from '../src/data/tools.js';
import { Digger, aimRay } from '../src/gameplay/dig.js';
import { AntMotor } from '../src/player/ant-motor.js';
import { CONFIG } from '../src/config.js';

import * as V from '../src/core/vec3.js';
const hardness = (m) => MATERIALS[m].hardness;
function steer(m, want) {
  const a = V.dot(want, m.up); const p = [want[0] - m.up[0] * a, want[1] - m.up[1] * a, want[2] - m.up[2] * a];
  if (V.len(p) < 0.2) return; V.normalize(p, p);
  const c = V.cross([0, 0, 0], m.heading, p); const ang = Math.acos(Math.max(-1, Math.min(1, V.dot(m.heading, p))));
  m.look((V.dot(c, m.up) >= 0 ? -1 : 1) * Math.min(ang, 0.1), 0);
}
const L = buildLevelField(TEST_TUNNELS);
function levelField() {
  const { min, max } = TEST_TUNNELS.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  return f;
}
const worldOf = (field) => ({ field, dig: (c, r, mh, now) => carveSphere(field, c, r, { maxHardness: mh, hardness, now }) });

test('ADD §77: the ant digs from Room A through the wall into Room B with mandibles', () => {
  const field = levelField();
  const motor = new AntMotor(field, CONFIG.ant);
  motor.place(TEST_TUNNELS.spawn.pos, TEST_TUNNELS.spawn.yaw); // spawn faces +x, toward Room B
  const digger = new Digger(worldOf(field));
  assert.equal(digger.tool.id, 'mandibles');
  let bites = 0, t = 0, clock = 1;
  // player-like: aim level toward +x, keep steering toward +x, hold forward and DIG
  while (t < 60 && motor.pos[0] < -3) {
    const eye = motor.pos.map((v, i) => v + motor.up[i] * 0.06);
    bites += digger.update(1 / 60, { held: true, eye, dir: [1, 0, 0], up: motor.up, now: clock, canDig: motor.mode === 'surface' }).length;
    steer(motor, [1, 0, 0]);
    motor.step(1 / 60, { moveX: 0, moveY: 1, yaw: 0, pitch: 0, jump: false, fast: false, digging: digger.target.status === 'ok' });
    t += 1 / 60; clock += 1 / 60;
    assert.ok(field.densityAt(...motor.pos) < 0.05, 'ant never inside rock');
  }
  assert.ok(motor.pos[0] >= -3, `reached Room B (x=${motor.pos[0].toFixed(2)}, t=${t.toFixed(1)}s, bites=${bites})`);
  assert.ok(t < 20, `took ${t.toFixed(1)} s — digging should be quick (GDD §11)`);
  assert.ok(bites > 5);
});

test('limestone resists mandibles but yields to the Vibro Pick', () => {
  const field = levelField();
  let p = null;
  for (let y = -13; y < -7 && !p; y += 0.4) for (let x = -20; x < 20 && !p; x += 0.8) {
    if (L.density(x, y, 0) > 1 && field.materialAt(x, y, 0) === MAT.LIMESTONE && L.material(x, y, 0) === MAT.LIMESTONE) p = [x, y, 0];
  }
  assert.ok(p, 'found limestone');
  const before = field.densityAt(...p);
  carveSphere(field, p, 0.6, { maxHardness: TOOLS[0].maxHardness, hardness });
  assert.equal(field.densityAt(...p), before, 'mandibles cannot cut limestone');
  carveSphere(field, p, 0.6, { maxHardness: TOOLS[1].maxHardness, hardness });
  assert.ok(field.densityAt(...p) < 0, 'vibro pick cuts limestone');
});

test('world edge stays solid; spoil volume is counted once across chunk halos', () => {
  const field = levelField();
  const edge = [-31.7, 0, 0];
  carveSphere(field, edge, 1.0, { hardness });
  assert.ok(field.densityAt(-31.6, 0, 0) > 0, 'edge not dug');
  // sphere straddling the chunk border at x = 0 deep in solid rock
  const c = [0, 12.5, -24];
  assert.ok(L.density(...c) > 2);
  const r = carveSphere(field, c, 1.2, { hardness });
  const vol = Object.values(r.removed).reduce((a, b) => a + b, 0);
  const ideal = (4 / 3) * Math.PI * 1.2 ** 3;
  assert.ok(Math.abs(vol - ideal) / ideal < 0.25, `volume ${vol.toFixed(2)} vs ${ideal.toFixed(2)}`);
  assert.ok(r.chunks.size >= 2, 'touches both chunks');
});

test('after carving, neighbour chunks still mesh exactly like one big chunk', () => {
  const v = 0.5, f = (x, y, z) => Math.hypot(x - 4, y - 4, z - 4) - 2.5;
  const small = new DensityField(8, v), big = new DensityField(16, v);
  for (const cx of [0, 1]) for (const cy of [0, 1]) for (const cz of [0, 1]) small.set(cx, cy, cz, generateChunk(cx, cy, cz, 8, v, f, () => 0));
  big.set(0, 0, 0, generateChunk(0, 0, 0, 16, v, f, () => 0));
  for (const fld of [small, big]) carveSphere(fld, [4.1, 1.5, 3.9], 1.3, { hardness: () => 0, now: 5 });
  const tri = (m) => { const o = []; for (let t = 0; t < m.indices.length; t += 3) o.push([0, 1, 2].map((q) => { const i = m.indices[t + q] * 3; return `${m.positions[i]},${m.positions[i + 1]},${m.positions[i + 2]}`; }).join('|')); return o; };
  const b = big.get(0, 0, 0);
  const ref = tri(meshChunk(b.density, b.material, 16, v, 0, 0, 0, 4, b.cutTime)).sort();
  const parts = [];
  for (const ch of small.chunks.values()) parts.push(...tri(meshChunk(ch.density, ch.material, 8, v, ch.cx, ch.cy, ch.cz, 4, ch.cutTime)));
  assert.deepEqual(parts.sort(), ref);
  const m = meshChunk(b.density, b.material, 16, v, 0, 0, 0, 4, b.cutTime);
  assert.ok(m.cut.some((t) => t === 5), 'fresh-cut time reaches the mesh');
});

test('dig log round-trips: replayed field equals the edited field', () => {
  const mem = new Map(); const storage = { getItem: (k) => mem.get(k) ?? null, setItem: (k, v) => mem.set(k, v), removeItem: (k) => mem.delete(k) };
  const a = levelField();
  const log = new DigLog(TEST_TUNNELS, storage);
  const ops = [[-7.1, -1.2, 0.3, 0.55, 0.55], [-6.6, -1.1, 0.2, 0.55, 0.55], [-6.0, -1.0, 0.1, 0.385, 0.55]];
  for (const op of ops) { log.push(op); carveSphere(a, op.slice(0, 3), op[3], { maxHardness: op[4], hardness }); }
  assert.ok(log.save());
  const b = levelField();
  for (const [x, y, z, r, mh] of new DigLog(TEST_TUNNELS, storage).load()) carveSphere(b, [x, y, z], r, { maxHardness: mh, hardness });
  for (const [k, ch] of a.chunks) assert.deepEqual(ch.density, b.chunks.get(k).density, k);
});

test('aim ray finds the Room A wall and reports its material', () => {
  const field = levelField();
  const hit = aimRay(field, [-9, -1.2, 0], [1, 0, 0], 2);
  assert.ok(hit && hit.dist > 0 && hit.dist < 2, JSON.stringify(hit));
  assert.ok(hit.normal[0] < -0.5, 'normal points back into the room');
  assert.ok([MAT.CLAY, MAT.SAND, MAT.SOIL].includes(hit.material));
  assert.equal(aimRay(field, [-12.5, 0, 0], [0, 1, 0], 1), null, 'nothing within reach');
});
