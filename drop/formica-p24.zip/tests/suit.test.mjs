import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Suit } from '../src/gameplay/suit.js';
import { Research } from '../src/gameplay/research.js';
import { Inventory } from '../src/gameplay/inventory.js';
import { AntMotor } from '../src/player/ant-motor.js';
import { CONFIG } from '../src/config.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { GroundNav, reachableWithAdhesion } from '../src/world/ground-nav.js';

test('A3 §4: charge drains only on steep surfaces; empty cells are swapped; no cells → grip off', () => {
  const s = new Suit(); s.equip(); s.toggle();
  const inv = Inventory.from({ chemical_cell: 1 });
  assert.equal(s.update(1, 1, inv), 'swapped', 'first cell goes in');
  for (let t = 0; t < 30; t += 0.1) s.update(0.1, 1, inv);
  assert.equal(s.charge, 100, 'walking on floors is free');
  let ev = null; for (let t = 0; t < 95 && !ev; t += 0.1) ev = s.update(0.1, 0, inv);
  assert.equal(ev, 'empty'); assert.equal(s.adhesion, false);
  assert.ok(s.toggle() && !s.adhesion, 'cannot grip without charge');
});

test('A3 §36: three different components make the suit blueprint', () => {
  const r = new Research();
  r.analyze('suit_actuator', 'a'); r.analyze('suit_actuator', 'b'); r.analyze('grip_pads', 'c');
  assert.ok(!r.blueprints.has('adhesion_suit'));
  assert.equal(r.analyze('suit_control', 'd').unlocked, 'adhesion_suit');
});

test('the ceiling cache needs the suit; everything critical still does not', () => {
  const L = buildLevelField(T), { min, max } = T.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const nav = new NavGrid(f); nav.build();
  const g = new GroundNav(nav, f).build();
  const c = T.salvage.find((x) => x.id === 'sal-ceiling').pos;
  assert.ok(f.densityAt(...c) < 0 && f.densityAt(c[0], c[1] + 1.6, c[2]) > 0, 'just under the Pit Hall ceiling');
  assert.ok(reachableWithAdhesion(nav, T.shelter.respawn, c), 'with the rig');
  assert.ok(!g.reachable(T.shelter.respawn, c, { back: false }) || f.dropToSurface(c, 1) === null, 'not standing-reachable on foot');
  for (const id of ['sal-actuator-rig', 'sal-pads', 'sal-control']) {
    const s = T.salvage.find((x) => x.id === id), fl = f.dropToSurface(s.pos, 4);
    assert.ok(fl && g.reachable(T.shelter.respawn, [fl[0], fl[1] + 0.3, fl[2]]), `${id} on foot`);
  }
});

test('the player motor switches adhesion on the fly: climb with grip, slide down without', () => {
  const f = new DensityField(20, 0.4, [-1, -1, -1], [0, 0, 0]);
  for (let cz = -1; cz <= 0; cz++) for (let cy = -1; cy <= 0; cy++) for (let cx = -1; cx <= 0; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 20, 0.4, (x, y, z) => Math.hypot(x, y, z) - 4, () => 1));
  const m = new AntMotor(f, { ...CONFIG.ant });
  m.place([0, 0, 0], 0);
  m.p.adhesion = true;
  for (let i = 0; i < 60 * 4; i++) m.step(1 / 60, { moveX: 0, moveY: 1, yaw: 0, pitch: 0 });
  assert.ok(m.up[1] < 0.3, 'on the wall with grip');
  m.p.adhesion = false;
  for (let i = 0; i < 60 * 6; i++) m.step(1 / 60, null);
  assert.equal(m.mode, 'surface'); assert.ok(m.up[1] > 0.6 && m.pos[1] < -2.5, 'back on the floor');
});
