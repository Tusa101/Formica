import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Network } from '../src/gameplay/network.js';
import { RECIPES } from '../src/data/recipes.js';
import { ITEMS } from '../src/data/items.js';

test('lamps: place, find, pick up, save', () => {
  const n = new Network();
  n.addLamp([1, 0, 0]); n.addLamp([5, 0, 0]);
  assert.equal(n.lampNear([4.5, 0, 0]), 1);
  assert.deepEqual(n.removeLamp(1), [5, 0, 0]);
  assert.equal(n.lampNear([4.5, 0, 0]), -1);
  assert.deepEqual(new Network(JSON.parse(JSON.stringify(n.toJSON()))).lamps, [[1, 0, 0]]);
});

test('bites are recorded on a 0.4 u grid without duplicates and survive a save', () => {
  const n = new Network();
  assert.ok(n.markBite([1.1, 2.1, 3.1]));
  assert.ok(!n.markBite([1.15, 2.12, 3.08]), 'same grid point');
  assert.ok(n.markBite([2, 2, 3]));
  const c = new Network(JSON.parse(JSON.stringify(n.toJSON())));
  assert.equal(c.dug.size, 2);
  for (const p of c.dugPoints()) assert.ok([1.2, 2].some((x) => Math.abs(p[0] - x) < 1e-9));
});

test('the resin lamp is a field recipe', () => {
  const r = RECIPES.find((x) => x.id === 'resin_lamp');
  assert.ok(r && !r.blueprint && !r.station && ITEMS.resin_lamp.place === 'lamp');
});
