import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Receiver, IDENTIFY_MIN } from '../src/gameplay/receiver.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { GroundNav } from '../src/world/ground-nav.js';

const B = [
  { id: 'home', name: 'HOME', type: 'RITUAL', pos: [0, 0, 0], power: 1, range: 50, known: true },
  { id: 'far', name: 'FAR STATION', type: 'DEAD', pos: [30, 0, 0], power: 0.6, range: 12 },
  { id: 'ghost', name: 'GHOST', type: 'UNKNOWN', pos: [0, 0, 30], power: 0.5, range: 20, intermittent: true },
];
const run = (r, p, secs) => { const out = []; for (let t = 0; t < secs; t += 0.1) out.push(...r.update(0.1, p)); return out; };

test('strength falls with distance; nothing beyond range', () => {
  const r = new Receiver(B);
  const b = r.get('far');
  assert.ok(r.strength(b, [29, 0, 0]) > r.strength(b, [22, 0, 0]));
  assert.equal(r.strength(b, [10, 0, 0]), 0);
});

test('A3 §16: stages advance in order while in range; identification needs a usable signal', () => {
  const r = new Receiver(B);
  const ev = run(r, [26, 0, 0], 10).filter((e) => e.id === 'far');
  assert.deepEqual(ev.map((e) => e.stage), [1, 2, 3, 4, 5]);
  assert.equal(ev[0].text, 'WEAK SIGNAL DETECTED');
  assert.ok(ev[4].text.includes('FAR STATION'));
  const weak = new Receiver(B);
  run(weak, [19.2, 0, 0], 12);
  assert.ok(weak.strength(weak.get('far'), [19.2, 0, 0]) < IDENTIFY_MIN);
  assert.equal(weak.state('far').stage, 4, 'direction but not identified from afar');
});

test('A3 §17: a known beacon always gives direction and distance; unknown ones only direction after estimation', () => {
  const r = new Receiver(B);
  const o = r.readout([100, 0, 100]);
  assert.equal(o.id, 'home'); assert.ok(o.dist > 100); assert.equal(o.strength, 0);
  run(r, [26, 0, 0], 5);
  r.tracked = 'far';
  const f = r.readout([26, 0, 0]);
  assert.ok(f.direction && f.dist === null, 'direction, no distance yet');
});

test('intermittent signals come and go; the Signal Horizon upgrade reveals more', () => {
  const r = new Receiver(B);
  const seen = new Set();
  for (let t = 0; t < 20; t += 0.1) { r.update(0.1, [0, 0, 15]); seen.add(r.state('ghost').strength > 0); }
  assert.deepEqual([...seen].sort(), [false, true]);
  const h = new Receiver(B);
  assert.equal(h.upgrade(2.5, [2, 0, 2]), 2);
});

test('tracking cycles over followable signals; player beacons; save/load', () => {
  const r = new Receiver(B);
  run(r, [26, 0, 0], 10);
  assert.equal(r.trackable().length, 2);
  r.tracked = 'home'; assert.equal(r.cycle(), 'far'); assert.equal(r.cycle(), 'home');
  const pb = r.addPlayerBeacon([5, 0, 5]);
  assert.ok(r.canTrack(pb.id));
  const c = new Receiver(B, JSON.parse(JSON.stringify(r.toJSON())));
  assert.equal(c.state('far').stage, 5); assert.equal(c.trackable().length, 3);
});

test('A3 §45.6: the level has optional signals, all reachable on foot from the shelter; the shelter upgrade reveals ≥ 3', () => {
  assert.ok(T.beacons.filter((b) => !b.known).length >= 1);
  const L = buildLevelField(T), { min, max } = T.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const nav = new NavGrid(f); nav.build();
  const g = new GroundNav(nav, f).build();
  for (const b of T.beacons) {
    const fl = f.dropToSurface(b.pos, 6);
    assert.ok(fl, `${b.id} above a floor`);
    assert.ok(g.reachable(T.shelter.respawn, [fl[0], fl[1] + 0.3, fl[2]]), `${b.id} reachable on foot (and back)`);
  }
  const r = new Receiver(T.beacons);
  assert.ok(r.upgrade(2.5, T.shelter.respawn) >= 3);
});
