import { test } from 'node:test';
import assert from 'node:assert/strict';
import { settings, loadSettings, setSetting, DEFAULTS, LIMITS } from '../src/settings.js';
import { DynamicResolution } from '../src/core/quality.js';
import { migrate, exportSave, importSave, resetAll, saveKeys, compactOps, SAVE_FORMAT } from '../src/save/save-manager.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { carveSphere, fillSphere } from '../src/world/terrain-ops.js';

function mem() {
  const m = new Map();
  return { get length() { return m.size; }, key: (i) => [...m.keys()][i] ?? null, getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), _m: m };
}

test('settings: defaults, clamping, persistence', () => {
  const s = mem();
  loadSettings(s);
  assert.equal(settings.quality, 'auto');
  setSetting('lookTouch', 1, s);
  assert.equal(settings.lookTouch, LIMITS.lookTouch[1]);
  setSetting('quality', 'low', s);
  settings.quality = 'high';
  loadSettings(s);
  assert.equal(settings.quality, 'low');
  s.setItem('formica.settings', '{"quality":"ultra"}'); loadSettings(s);
  assert.equal(settings.quality, 'auto');
  assert.equal(settings.volume, DEFAULTS.volume);
});

test('dynamic resolution lowers the ratio under load and raises it when there is headroom', () => {
  const d = new DynamicResolution({ min: 0.6, max: 1.5 });
  let r = null;
  for (let t = 0; t < 2.1; t += 0.1) r = d.update(0.1, 25) ?? r;
  assert.ok(r < 1.5 && r >= 0.6);
  for (let t = 0; t < 30; t += 0.1) d.update(0.1, 20);
  assert.equal(d.ratio, 0.6, 'floors at min');
  for (let t = 0; t < 60; t += 0.1) d.update(0.1, 60);
  assert.equal(d.ratio, 1.5, 'recovers to max');
});

test('saves: version migration, export → import round trip, reset keeps settings', () => {
  const s = mem();
  s.setItem('formica.world.x', '{"ops":[1]}'); s.setItem('formica.player.x', '{"a":1}'); s.setItem('formica.settings', '{"volume":0.2}'); s.setItem('other.app', 'keep');
  assert.deepEqual(migrate(s), { from: 1, to: SAVE_FORMAT });
  const dump = exportSave(s);
  resetAll(s);
  assert.deepEqual(saveKeys(s), ['formica.saveFormat', 'formica.settings']);
  assert.equal(s.getItem('other.app'), 'keep');
  importSave(s, dump);
  assert.equal(s.getItem('formica.world.x'), '{"ops":[1]}');
  assert.throws(() => importSave(s, '{"hello":1}'));
});

test('dig-log compaction is exact: the density field is unchanged', () => {
  const build = () => { const f = new DensityField(16, 0.4, [0, 0, 0], [0, 0, 0]); f.set(0, 0, 0, generateChunk(0, 0, 0, 16, 0.4, () => 2, () => 1)); return f; };
  const ops = [];
  for (let i = 0; i < 40; i++) ops.push([2 + (i % 5) * 0.05, 3, 3 + Math.floor(i / 5) * 0.2, i % 3 === 0 ? 0.5 : 0.72, 0.55]);
  ops.push([3, 3, 3, 0.9, 1, 1]); // a fill in the middle
  ops.push([3, 3, 3, 0.5, 0.55], [3, 3, 3, 0.5, 0.55], [3.02, 3, 3, 0.8, 0.55]);
  const apply = (f, list) => { for (const [x, y, z, r, m, k] of list) if (k === 1) fillSphere(f, [x, y, z], r, m); else carveSphere(f, [x, y, z], r, { maxHardness: m, hardness: () => 0 }); };
  const a = build(), b = build();
  const c = compactOps(ops);
  apply(a, ops); apply(b, c);
  assert.ok(c.length < ops.length, `${ops.length} → ${c.length}`);
  assert.deepEqual(a.get(0, 0, 0).density, b.get(0, 0, 0).density);
});
