import { test } from 'node:test';
import assert from 'node:assert/strict';
import { stickVector, clampKnob, keyVector } from '../src/core/stick.js';

test('inside deadzone → zero', () => {
  assert.deepEqual(stickVector(3, 0, 56, 0.12, 1.6), { x: 0, y: 0, mag: 0 });
});
test('full deflection → magnitude 1, screen-up is forward', () => {
  const v = stickVector(0, -200, 56, 0.12, 1.6);
  assert.equal(v.mag, 1);
  assert.ok(Math.abs(v.y - 1) < 1e-9 && Math.abs(v.x) < 1e-9);
});
test('response curve is monotonic', () => {
  let prev = -1;
  for (let d = 0; d <= 56; d += 4) {
    const m = stickVector(d, 0, 56, 0.12, 1.6).mag;
    assert.ok(m >= prev); prev = m;
  }
});
test('knob clamps to ring', () => {
  const k = clampKnob(300, 400, 50);
  assert.ok(Math.abs(Math.hypot(k.x, k.y) - 50) < 1e-9);
  assert.deepEqual(clampKnob(10, 10, 50), { x: 10, y: 10 });
});
test('keyboard diagonal is normalised', () => {
  const v = keyVector(false, true, false, true);
  assert.ok(Math.abs(Math.hypot(v.x, v.y) - 1) < 1e-9);
  assert.equal(keyVector(true, true, false, false).mag, 0);
});
