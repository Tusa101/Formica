import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MANDIBLE, ANTENNA } from '../src/player/body-shape.js';
import { CONFIG } from '../src/config.js';

// Project a camera-space point: returns NDC or null when behind the near plane.
function ndc([x, y, z], aspect) {
  const d = -z;
  if (d <= CONFIG.render.near) return null;
  const t = Math.tan((CONFIG.render.fov * Math.PI) / 360);
  return [x / (d * t * aspect), y / (d * t)];
}
const inside = (p) => p && Math.abs(p[0]) < 1 && Math.abs(p[1]) < 1;

test('first-person parts: bases start outside the view, tips are visible (phone and desktop aspect)', () => {
  for (const aspect of [800 / 360, 16 / 9, 4 / 3]) {
    for (const [name, pts] of [['mandible', MANDIBLE], ['antenna', ANTENNA]]) {
      assert.ok(!inside(ndc(pts[0], aspect)), `${name} base hidden @${aspect.toFixed(2)}`);
      assert.ok(inside(ndc(pts.at(-1), aspect)), `${name} tip visible @${aspect.toFixed(2)}`);
      assert.ok(!inside(ndc(pts[1], aspect)) || name === 'antenna', `${name} enters from the edge`);
    }
  }
});

test('headlamp aims ahead, not down', () => {
  const a = CONFIG.lamp.aim;
  assert.ok(a[2] < 0 && a[1] >= 0, 'forward and slightly up');
  assert.ok(CONFIG.lamp.offset[1] > 0, 'mounted above the eye');
});
