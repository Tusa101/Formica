import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { Topology } from '../src/world/topology.js';
import { Atmosphere } from '../src/world/atmosphere.js';
import { AntMotor } from '../src/player/ant-motor.js';
import { CONFIG } from '../src/config.js';
import { Scout } from '../src/ai/scout.js';
import { Spider, SPIDER } from '../src/ai/spider.js';
import { DeepThing, DEEP } from '../src/ai/deep-thing.js';
import { runBot, groundRoute } from './bot.mjs';

const L = buildLevelField(T), { min, max } = T.chunks;
const field = new DensityField(40, 0.4, min, max);
for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
  field.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
const topo = new Topology(field, T); topo.build();
const newAir = () => { const a = new Atmosphere(topo.nav, T.air, (p) => L.zoneAt(...p, 0.3)); a.init(); return a; };

// The ant walks Room A → South Loop → Room B, laying a trail (optionally masked after `maskAt` s), then waits.
const LEG = [[-13, -1.6, -3.5], [-15, -1.4, -12], [-6, -0.8, -19], [4, -1.2, -13], [1, -1.6, -3.5], [-0.5, -2.4, 0.5]];
function walkAndTrack({ maskAt = Infinity, waitAfter = 120, scoutHome = [-12.5, -2.2, 0] } = {}) {
  const air = newAir();
  const ant = new AntMotor(field, CONFIG.ant); ant.place(T.spawn.pos, T.spawn.yaw);
  let t = 0;
  const route = groundRoute(field, LEG, CONFIG.ant.hover);
  runBot(ant, route, { onStep: (m) => { t += 1 / 60; if (t < maskAt) air.deposit('player', m.pos, 1.5 / 60); air.update(1 / 60); } });
  const scout = new Scout(field, topo, scoutHome, [scoutHome], 5);
  const events = [];
  for (let w = 0; w < waitAfter; w += 1 / 60) {
    scout.step(1 / 60, { air, player: ant.pos });
    air.update(1 / 60);
    events.push(...scout.events.splice(0));
    if (scout.state === 'gone' || events.some((e) => e.type === 'found')) break;
  }
  return { scout, events, ant };
}

test('GDD §73: a scout picks up the trail and follows it to the ant that stopped', () => {
  const { events } = walkAndTrack();
  const types = events.map((e) => e.type);
  assert.ok(types.includes('trail'), types.join(','));
  assert.ok(types.includes('found'), `scout did not find the ant: ${types.join(',')}`);
});

test('counter-tracking: with a scent mask the trail ends, the scout searches and gives up', () => {
  const { events } = walkAndTrack({ maskAt: 12, waitAfter: 150 });
  const types = events.map((e) => e.type);
  assert.ok(types.includes('trail'));
  assert.ok(!types.includes('found'), types.join(','));
  assert.ok(types.includes('lost'));
});

test('without a trail the scout never heads for the ant (no magic knowledge)', () => {
  const air = newAir();
  const scout = new Scout(field, topo, [-12.5, -2.2, 0], [[-12.5, -2.2, 0], [-6, -0.8, -19]], 3);
  const antPos = [16, -5.2, -14]; // far away in the shelter
  for (let t = 0; t < 40; t += 1 / 60) { scout.step(1 / 60, { air, player: antPos }); air.update(1 / 60); }
  assert.ok(!scout.events.some((e) => e.type === 'trail' || e.type === 'found'));
});

test('ADD §2: the territorial spider warns, charges only after lingering, and returns home; bites scare it off', () => {
  const lair = field.dropToSurface(T.creatures[1].pos, 6); lair[1] += 0.3;
  const sp = new Spider(field, topo, lair, 4);
  const run = (secs, player) => { for (let t = 0; t < secs; t += 1 / 60) sp.step(1 / 60, { player }); };
  run(3, null);
  assert.equal(sp.state, 'rest');
  const fl = field.dropToSurface([lair[0] + 1.2, lair[1] + 0.6, lair[2] - 2.4], 6); const near = [fl[0], fl[1] + CONFIG.ant.hover, fl[2]];
  run(1, near);
  assert.equal(sp.state, 'threat');
  run(5, near);
  const ev = sp.events.map((e) => e.type);
  assert.ok(ev.includes('charge') && ev.includes('hit'), ev.join(','));
  run(12, null);
  assert.equal(sp.state, 'rest');
  assert.ok(sp.distTo(lair) < 2.5);
  sp.hurt(); sp.hurt(); sp.hurt();
  assert.equal(sp.state, 'flee');
});

test('something huge: drawn by loud noise, deaf to footsteps, never rises above the ceiling', () => {
  const d = new DeepThing(T.deep.loop.map((p) => p.slice()));
  let pulses = 0;
  const start = d.pos.slice();
  for (let t = 0; t < 10; t += 0.1) { if (d.step(0.1, [{ pos: [start[0] + 10, 0, start[2]], strength: 0.2 }])) pulses++; }
  assert.ok(pulses >= 5, 'pulses');
  const loudAt = [d.pos[0] + 8, 2, d.pos[2]];
  const before = Math.hypot(d.pos[0] - loudAt[0], d.pos[2] - loudAt[2]);
  for (let t = 0; t < 8; t += 0.1) d.step(0.1, t < 0.2 ? [{ pos: loudAt, strength: 2 }] : []);
  const after = Math.hypot(d.pos[0] - loudAt[0], d.pos[2] - loudAt[2]);
  assert.ok(after < before - 3, `${before.toFixed(1)} → ${after.toFixed(1)}`);
  assert.ok(d.pos[1] <= DEEP.ceiling + 1e-9);
});
