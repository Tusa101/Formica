import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { carveSphere } from '../src/world/terrain-ops.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { TEST_TUNNELS } from '../src/levels/test-tunnels.js';
import { Topology } from '../src/world/topology.js';
import { NavGrid } from '../src/world/navgrid.js';
import { Beetle } from '../src/ai/beetle.js';

const L = buildLevelField(TEST_TUNNELS);
function levelField() {
  const { min, max } = TEST_TUNNELS.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  return f;
}
/** Digs a straight ant-sized tunnel a→b the way the mandibles would, reporting each bite to the topology. */
function digTunnel(field, topo, a, b, r = 0.72) {
  const n = Math.ceil(Math.hypot(...a.map((v, i) => b[i] - v)) / 0.45);
  for (let s = 0; s <= n; s++) {
    const c = a.map((v, i) => v + (b[i] - v) * (s / n));
    carveSphere(field, c, r, { hardness: () => 0 });
    topo.onEdit(c, r);
  }
}
const allEvents = (topo) => { const ev = []; for (let i = 0; i < 3; i++) ev.push(...topo.tick(1)); return ev; };

const field = levelField();
const topo = new Topology(field, TEST_TUNNELS);
topo.build();

test('level has three cavities: the tunnel network, the Sealed Chamber and the Shelter\'s Collapsed Chamber', () => {
  assert.equal(topo.cavityCount, 3, `cavities: ${[...topo.nav.sizes.values()]}`);
  assert.equal(topo.zoneDistance('Room B', 'Sealed Chamber'), Infinity);
  assert.ok(topo.zoneDistance('Room A', 'Room B') < Infinity, 'A and B linked by the loop');
  assert.ok(topo.graph.nodes.length > 50 && topo.graph.edgeCount > 50);
  assert.ok(topo.zoneNodes.every((n) => n >= 0), 'every named zone maps to a region node');
});

test('beetle cannot leave the sealed chamber before it is opened', () => {
  const b = new Beetle(field, topo, TEST_TUNNELS.creatures[0].pos);
  assert.equal(b.goTo([-0.5, -2, 0]), false);
});

test('digging Room B → Sealed Chamber raises a "connected" event and merges the cavities', () => {
  digTunnel(field, topo, [0, -2.2, 3.6], [0, -2.0, 7.6]);
  const ev = allEvents(topo);
  const c = ev.find((e) => e.type === 'connected');
  assert.ok(c, JSON.stringify(ev));
  assert.deepEqual([c.a, c.b].sort(), ['Room B', 'Sealed Chamber']);
  assert.equal(topo.cavityCount, 2, 'only the Collapsed Chamber stays sealed');
});

test('scratching a wall produces no topology event', () => {
  digTunnel(field, topo, [-9.6, -1.6, 3.5], [-9.9, -1.6, 3.9]);
  assert.deepEqual(allEvents(topo), []);
});

test('digging through the A|B wall raises a "passage" event and shortens A→B', () => {
  const before = topo.zoneDistance('Room A', 'Room B');
  digTunnel(field, topo, [-8.2, -2.2, 0], [-4.4, -2.2, 0]);
  const ev = allEvents(topo);
  const p = ev.find((e) => e.type === 'passage');
  assert.ok(p, JSON.stringify(ev));
  assert.deepEqual([p.a, p.b].sort(), ['Room A', 'Room B']);
  const after = topo.zoneDistance('Room A', 'Room B');
  assert.ok(after < before * 0.6, `${before.toFixed(1)} → ${after.toFixed(1)}`);
});

test('incremental grid updates equal a full rebuild', () => {
  const fresh = new NavGrid(field); fresh.build();
  assert.deepEqual(fresh.open, topo.nav.open);
  // same partition (label ids may differ)
  const map = new Map();
  for (let i = 0; i < fresh.count; i++) if (fresh.open[i]) {
    const a = fresh.label[i], b = topo.nav.label[i];
    if (!map.has(a)) map.set(a, b); else assert.equal(map.get(a), b);
  }
});

test('ADD §77.3: the beetle walks from the Sealed Chamber into Room A on the real motor', () => {
  const b = new Beetle(field, topo, TEST_TUNNELS.creatures[0].pos, 11);
  assert.ok(b.goTo([-12.5, -2.3, 0], 'Room A'), 'path exists');
  let t = 0;
  while (t < 120 && b.state === 'walk') { b.step(1 / 60); t += 1 / 60; assert.ok(field.densityAt(...b.pos) < 0.05, 'beetle in rock'); }
  const d = Math.hypot(b.pos[0] + 12.5, b.pos[2]);
  assert.ok(d < 4, `beetle ended ${d.toFixed(1)} from Room A centre after ${t.toFixed(1)} s at ${b.pos.map((v) => v.toFixed(1))}`);
});

test('after a "connected" event the beetle leaves its chamber to explore the far zone', () => {
  const b = new Beetle(field, topo, TEST_TUNNELS.creatures[0].pos, 5);
  b.notice({ type: 'connected', a: 'Room B', b: 'Sealed Chamber', at: [0, -2, 7] });
  b.seenVersion = -1; // as if the topology just changed
  let t = 0, minD = Infinity;
  while (t < 40) { b.step(1 / 60); t += 1 / 60; minD = Math.min(minD, Math.hypot(b.pos[0] + 0.5, b.pos[2])); }
  assert.ok(minD < 4, `closest approach to Room B centre ${minD.toFixed(1)}`);
});
