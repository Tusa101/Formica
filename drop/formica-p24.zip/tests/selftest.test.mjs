import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkLayout, rectsOverlap } from '../src/ui/selftest.js';

const R = (left, top, w, h) => ({ left, top, right: left + w, bottom: top + h, width: w, height: h });
const VP = { width: 800, height: 400, safe: { top: 0, right: 30, bottom: 0, left: 30 } };

test('touching edges do not count as overlap', () => {
  assert.equal(rectsOverlap(R(0, 0, 10, 10), R(10, 0, 10, 10)), false);
  assert.equal(rectsOverlap(R(0, 0, 10, 10), R(5, 5, 10, 10)), true);
});
test('clean layout passes', () => {
  const items = [
    { id: 'a', rect: R(40, 10, 100, 50), interactive: true },
    { id: 'b', rect: R(600, 300, 60, 60), interactive: true },
  ];
  assert.deepEqual(checkLayout(items, VP, 44), []);
});
test('detects safe-area violation, overlap and tiny targets', () => {
  const items = [
    { id: 'a', rect: R(10, 10, 100, 50), interactive: false },
    { id: 'b', rect: R(60, 20, 30, 30), interactive: true },
  ];
  const p = checkLayout(items, VP, 44);
  assert.ok(p.some((s) => s.startsWith('a: outside')));
  assert.ok(p.some((s) => s.includes('overlaps')));
  assert.ok(p.some((s) => s.startsWith('b: touch target')));
});
test('same group may overlap', () => {
  const items = [
    { id: 'a', rect: R(40, 10, 100, 50), interactive: false, group: 'g' },
    { id: 'b', rect: R(60, 20, 100, 50), interactive: false, group: 'g' },
  ];
  assert.deepEqual(checkLayout(items, VP, 44), []);
});
