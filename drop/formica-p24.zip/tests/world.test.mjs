import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createNoise } from '../src/world/noise.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { meshChunk } from '../src/world/surface-nets.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { TEST_TUNNELS } from '../src/levels/test-tunnels.js';

// Hollow sphere (empty inside) centred at c in solid rock.
const sphereCave = (c, r) => (x, y, z) => Math.hypot(x - c[0], y - c[1], z - c[2]) - r;
const mat0 = () => 0;

test('noise is deterministic and bounded', () => {
  const a = createNoise(7), b = createNoise(7), c = createNoise(8);
  let diff = false;
  for (let i = 0; i < 500; i++) {
    const x = i * 0.37, y = i * 0.11, z = -i * 0.23;
    const v = a.fbm(x, y, z);
    assert.equal(v, b.fbm(x, y, z));
    assert.ok(v > -1.2 && v < 1.2);
    if (v !== c.fbm(x, y, z)) diff = true;
  }
  assert.ok(diff, 'different seeds differ');
});

test('surface nets: normals point into the cavity and match triangle winding', () => {
  const N = 16, v = 0.5;
  const f = sphereCave([4, 4, 4], 2.6);
  const g = generateChunk(0, 0, 0, N, v, f, mat0);
  const m = meshChunk(g.density, g.material, N, v, 0, 0, 0);
  assert.ok(m.triangleCount > 100);
  let agree = 0;
  for (let t = 0; t < m.indices.length; t += 3) {
    const [a, b, c] = [m.indices[t], m.indices[t + 1], m.indices[t + 2]].map((i) => i * 3);
    const P = m.positions, Nn = m.normals;
    const e1 = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]];
    const e2 = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]];
    const cr = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
    // vertex normal should point toward the centre (the empty side)
    const toC = [4 - P[a], 4 - P[a + 1], 4 - P[a + 2]];
    assert.ok(Nn[a] * toC[0] + Nn[a + 1] * toC[1] + Nn[a + 2] * toC[2] > 0);
    if (cr[0] * Nn[a] + cr[1] * Nn[a + 1] + cr[2] * Nn[a + 2] > 0) agree++;
  }
  assert.equal(agree, m.triangleCount, 'all triangles front-face the empty side');
  for (let i = 0; i < m.vertexCount; i++) {
    const p = [m.positions[i * 3], m.positions[i * 3 + 1], m.positions[i * 3 + 2]];
    assert.ok(Math.abs(Math.hypot(p[0] - 4, p[1] - 4, p[2] - 4) - 2.6) < 0.2);
  }
});

test('eight small chunks mesh exactly like one big chunk (no seams)', () => {
  const v = 0.5, f = sphereCave([4, 4, 4], 3.1);
  const tri = (m) => {
    const out = [];
    for (let t = 0; t < m.indices.length; t += 3) {
      out.push([0, 1, 2].map((q) => { const i = m.indices[t + q] * 3; return `${m.positions[i]},${m.positions[i + 1]},${m.positions[i + 2]}`; }).join('|'));
    }
    return out;
  };
  const big = generateChunk(0, 0, 0, 16, v, f, mat0);
  const ref = tri(meshChunk(big.density, big.material, 16, v, 0, 0, 0)).sort();
  const parts = [];
  for (const cx of [0, 1]) for (const cy of [0, 1]) for (const cz of [0, 1]) {
    const g = generateChunk(cx, cy, cz, 8, v, f, mat0);
    parts.push(...tri(meshChunk(g.density, g.material, 8, v, cx, cy, cz)));
  }
  parts.sort();
  assert.ok(ref.length > 200);
  assert.deepEqual(parts, ref);
});

test('Test Tunnels level: rooms empty, wall solid, loop open', () => {
  const L = buildLevelField(TEST_TUNNELS);
  assert.ok(L.density(-12.5, 0, 0) < 0, 'Room A empty');
  assert.ok(L.density(-0.5, 0, 0) < 0, 'Room B empty');
  assert.ok(L.density(-6.25, 0, 0) > 0, 'wall between A and B is solid');
  const loop = TEST_TUNNELS.cavities.find((c) => c.name === 'South Loop').points;
  for (let i = 0; i < loop.length - 1; i++) {
    for (let t = 0; t <= 1; t += 0.1) {
      const p = loop[i].map((a, k) => a + (loop[i + 1][k] - a) * t);
      assert.ok(L.density(...p) < 0, `loop open at ${p.map((x) => x.toFixed(1))}`);
    }
  }
  assert.ok(L.density(20, 12, 10) > 0 || L.density(20, 11.5, 10) > 0, 'hall has a roof');
  assert.equal(L.zoneAt(-12.5, 0, 0), 'Room A');
  assert.ok(L.density(-31, 0, 0) > 0 && L.density(0, -15.5, 0) > 0, 'solid margin at world edge');
});

test('DensityField.densityAt matches the analytic field', () => {
  const N = 8, v = 0.5, f = sphereCave([2, 2, 2], 1.5);
  const field = new DensityField(N, v);
  for (const cx of [-1, 0]) for (const cy of [-1, 0]) for (const cz of [-1, 0]) field.set(cx, cy, cz, generateChunk(cx, cy, cz, N, v, f, mat0));
  for (const p of [[2, 2, 2], [0.3, 1.1, 2.9], [-1.2, 0.7, 3.3], [3.2, 3.3, 0.1]]) {
    assert.ok(Math.abs(field.densityAt(...p) - f(...p)) < 0.08, `at ${p}`);
  }
  const s = field.dropToSurface([2, 2, 2]);
  assert.ok(s && Math.abs(s[1] - 0.5) < 0.1, 'floor of the sphere found');
});
