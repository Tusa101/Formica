import { test } from 'node:test';
import assert from 'node:assert/strict';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { CATALOG } from '../src/data/analysis.js';
import { Places } from '../src/gameplay/pois.js';
import { Receiver } from '../src/gameplay/receiver.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { GroundNav } from '../src/world/ground-nav.js';

const L = buildLevelField(T), { min, max } = T.chunks;
const f = new DensityField(40, 0.4, min, max);
for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
  f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
const nav = new NavGrid(f); nav.build();
const g = new GroundNav(nav, f).build();
const H = T.shelter.respawn;
const onFloor = (p) => { const s = f.dropToSurface(p, 5); return s ? [s[0], s[1] + 0.3, s[2]] : p; };

test('A3 §20/§45.5: ≥ 3 points of interest near the shelter — each with a beacon, reachable on foot and back', () => {
  assert.ok(T.pois.length >= 3);
  for (const q of T.pois) {
    assert.ok(T.beacons.some((b) => b.id === q.beacon), `${q.id} beacon`);
    const d = Math.hypot(...q.center.map((v, i) => v - H[i]));
    assert.ok(d >= 8 && d <= 42, `${q.id} at ${d.toFixed(0)} u`);
    assert.ok(g.reachable(H, onFloor(q.center)), `${q.id} reachable`);
    assert.ok(f.densityAt(...q.center) < 0, `${q.id} centre in open space`);
  }
});

test('A3 §39/§45.7–8: each POI has something to analyze; together they teach ≥ 1 blueprint and ≥ 2 fragments', () => {
  let blueprints = 0, fragments = 0;
  for (const q of T.pois) {
    const inside = T.salvage.filter((s) => Math.hypot(...s.pos.map((v, i) => v - q.center[i])) <= q.r + 1.5);
    assert.ok(inside.length >= 1, `${q.id} has an analysis target`);
    for (const s of inside) { const d = CATALOG[s.kind]; if (d.blueprint) blueprints++; if (d.fragment) fragments++; }
  }
  assert.ok(blueprints >= 1 && fragments >= 2, `${blueprints} blueprints, ${fragments} fragments`);
  const ws = T.pois.find((q) => q.id === 'water-station');
  assert.ok(T.waterSources.some((w) => Math.hypot(...w.pos.map((v, i) => v - ws.center[i])) < ws.r + 1), 'the water station gives water');
});

test('places are discovered once; the Receiver Amplifier makes the anomaly audible from the shelter', () => {
  const pl = new Places(T.pois);
  assert.equal(pl.update(T.pois[0].center).length, 1);
  assert.equal(pl.update(T.pois[0].center).length, 0);
  assert.deepEqual(new Places(T.pois, pl.toJSON()).discovered, pl.discovered);
  const r = new Receiver(T.beacons);
  r.upgrade(2.5, H);
  const an = r.get('anomaly');
  assert.equal(r.strength(an, H), 0, 'the shelter receiver alone does not hear it');
  r.upgrade(2.5 * 1.6, H);
  assert.ok(r.strength(an, H) > 0, 'amplified: audible');
});
