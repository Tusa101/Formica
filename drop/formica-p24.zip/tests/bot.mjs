// Route bot: steers the real AntMotor along waypoints through Test Tunnels. Shared by tests.
import * as V from '../src/core/vec3.js';
export const ROUTE = [
  [-13, -1.6, -3.5], [-15, -1.4, -12], [-6, -0.8, -19], [4, -1.2, -13], [1, -1.6, -3.5], [-0.5, -1, 0],
  // P14: ground-only — switchback ramp up to the Upper Gallery, gentle descent into the Pit Hall, jump down into the Pit
  [3.2, -2.3, -2], [9.5, -0.2, -6.8], [13.5, 2.4, -1.5], [9.5, 5, 3.2], [4.5, 7.6, -1.2], [9.5, 10.2, -5.8], [9.8, 12.3, 2.2], [13, 12, 4.5],
  [21.5, 10.8, 1.8], [27, 9, 2.5], [28.5, 6.5, 7], [24.5, 4.5, 10.5], [21, 6.5, 18.5], [22, 5.2, 13.5], [20, -11.5, 10], [14.5, -9, 4.5], [8, -5, 4.2], [4, -2.6, 1.5], [1.2, -1.9, 0.6], [-0.5, -1, 0],
  [1, -1.6, -3.5], [4, -1.2, -13], [-6, -0.8, -19], [-15, -1.4, -12], [-13, -1.6, -3.5], [-12.5, -1, 0],
  [-13, -0.5, 4.2], [-16.5, -0.3, 13], [-8, -0.2, 19], [-5.5, 0, 20],
];
/** Inserts a waypoint every `step` units on walkable segments (on foot the bot must follow tunnel bends, not cut them). */
export function densify(route, step = 2) {
  const out = [route[0]];
  for (let i = 1; i < route.length; i++) {
    const a = route[i - 1], b = route[i];
    const h = Math.hypot(b[0] - a[0], b[2] - a[2]), dy = b[1] - a[1];
    const n = Math.abs(dy) < h * 1.2 ? Math.floor(Math.hypot(h, dy) / step) : 0; // not across drops
    for (let k = 1; k <= n; k++) { const t = k / (n + 1); out.push(a.map((v, j) => v + (b[j] - v) * t)); }
    out.push(b);
  }
  return out;
}

/** Snaps waypoints that float above a nearby floor down onto it (the ant always walks on a surface). */
export function groundRoute(field, route, hover) {
  return route.map((p) => { const s = field.dropToSurface(p, 4); return s ? [s[0], s[1] + hover, s[2]] : p; });
}
export function runBot(motor, route, { maxTime = 600, reach = motor.p.adhesion === false ? 1.0 : 1.6, dt = 1 / 60, onStep } = {}) {
  let wi = 0, t = 0, lastProgress = 0, bestD = Infinity;
  const d3 = [0, 0, 0], proj = [0, 0, 0], c = [0, 0, 0];
  while (wi < route.length && t < maxTime) {
    const wp = route[wi];
    V.sub(d3, wp, motor.pos);
    const dist = V.len(d3);
    if (dist < reach) { wi++; bestD = Infinity; lastProgress = t; continue; }
    if (dist < bestD - 0.05) { bestD = dist; lastProgress = t; }
    if (t - lastProgress > 25) return { ok: false, stuckAt: wi, wp, pos: [...motor.pos], t };
    const dn = dist; V.scale(d3, d3, 1 / dn);
    const along = V.dot(d3, motor.up);
    proj[0] = d3[0] - motor.up[0] * along; proj[1] = d3[1] - motor.up[1] * along; proj[2] = d3[2] - motor.up[2] * along;
    let yaw = 0;
    if (V.len(proj) > 0.15) {
      V.normalize(proj, proj);
      const cosA = Math.max(-1, Math.min(1, V.dot(motor.heading, proj)));
      const sign = V.dot(V.cross(c, motor.heading, proj), motor.up) >= 0 ? -1 : 1;
      yaw = Math.min(Math.acos(cosA), 0.08) * sign;
    }
    motor.look(yaw, 0);
    motor.step(dt, { moveX: 0, moveY: 1, yaw: 0, pitch: 0, jump: false, fast: false });
    onStep?.(motor, t);
    t += dt;
  }
  return { ok: wi >= route.length, t, reached: wi };
}
