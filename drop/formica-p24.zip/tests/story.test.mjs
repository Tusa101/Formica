import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RiteStory } from '../src/story/rite.js';
import { BaseNetwork } from '../src/gameplay/base.js';
import { Inventory } from '../src/gameplay/inventory.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { carveSphere, fillSphere } from '../src/world/terrain-ops.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { MAT } from '../src/data/materials.js';

const run = (st, secs, ctx = {}) => { const out = []; for (let t = 0; t < secs; t += 0.1) out.push(...st.update(0.1, ctx)); return out; };

test('opening (ADD §4): escorts → seal → Rite Kit boot → first recording, in order, once', () => {
  const st = new RiteStory(); st.start();
  const a = run(st, 15, { distance: 37 });
  assert.deepEqual(a.map((x) => x.type), ['say', 'say', 'seal', 'system', 'say']);
  assert.ok(a[3].lines.at(-1).includes('~35'), 'distance rounded to 5');
  assert.equal(st.phase, 'journey');
  assert.ok(st.signal);
  assert.equal(run(st, 5).length, 0, 'nothing repeats');
});

test('contextual recordings fire once; the dynamic event needs the lure first; finale ends the rite', () => {
  const st = new RiteStory(); st.start(); run(st, 15);
  assert.equal(run(st, 0.2, { seesResin: true }).length, 1);
  assert.equal(run(st, 0.2, { seesResin: true }).length, 0);
  assert.equal(run(st, 0.2, { deepNear: true }).length, 0, 'no shift before the lure');
  assert.deepEqual(run(st, 0.2, { powerRepaired: true }).map((x) => x.type), ['lure']);
  assert.deepEqual(run(st, 0.2, { deepNear: true }).map((x) => x.type), ['shift']);
  run(st, 0.2, { inShelter: true });
  assert.ok(!st.signal, 'bearing gone once the shelter is found');
  assert.deepEqual(run(st, 0.2, { transmitted: true }).map((x) => x.type), ['finale']);
  assert.equal(st.phase, 'ended');
  const copy = new RiteStory(JSON.parse(JSON.stringify(st.toJSON())));
  assert.ok(copy.did('shift') && copy.phase === 'ended');
});

test('GDD §64 finale on A3 power: the beacon runs on the auxiliary generator, essentials untouched', () => {
  const b = new BaseNetwork(T.shelter.modules);
  const inv = Inventory.from({ resin: 20, scrap: 20, chitin: 20, chemical_cell: 1 }, 99);
  for (const id of ['generator', 'air', 'fabricator', 'beacon']) assert.ok(b.repair(id, inv).ok, id);
  assert.equal(b.isPowered('beacon'), false, 'the starter generator never covers expansion');
  b.toggle('fabricator');
  assert.equal(b.isPowered('beacon'), false, 'switching things off is not enough any more');
  b.toggle('fabricator');
  assert.ok(b.repair('power', inv).ok && b.refuel('power', inv).ok);
  assert.ok(b.isPowered('beacon'));
  for (const id of ['air', 'condenser', 'lights', 'terminal', 'fabricator']) assert.ok(b.isPowered(id), id);
});

test('level: sealing cuts the ritual route; the South Loop rubble leaves a crawl space; the shift opens the beacon room; roots are solid', () => {
  const L = buildLevelField(T), { min, max } = T.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  for (const r of T.roots) { const m = r.points[1]; assert.ok(L.density(...m) > 0 && L.material(...m) === MAT.ROOT); }
  const R = T.rite;
  for (const s of [...R.seal, ...R.loopRubble]) fillSphere(f, s.c, s.r, MAT.SAND);
  const nav = new NavGrid(f); nav.build();
  const lab = (p) => nav.label[nav.nearestOpen(p, 3)];
  const start = lab(R.spawn.pos);
  assert.equal(start, lab([-12.5, -2, 0]), 'spawn connects to Room A');
  assert.notEqual(start, lab([-26.5, -1.3, 0.3]), 'the way back is sealed');
  assert.equal(start, lab(T.shelter.respawn), 'the shelter is still reachable (crawl over the loop rubble)');
  assert.notEqual(lab(T.shelter.respawn), lab([16, -4.2, -6]), 'beacon room sealed');
  for (const c of R.shift.carve) carveSphere(f, c, R.shift.r, { hardness: () => 0 });
  nav.build();
  assert.equal(nav.label[nav.nearestOpen(T.shelter.respawn, 3)], nav.label[nav.nearestOpen([16, -4.2, -6], 3)], 'the shift opened it');
});

test('A3 §40: first-hour goals advance through the five stages and the finale', () => {
  const st = new RiteStory(); st.start();
  run(st, 15);
  const goals = [st.goal];
  const step = (ctx) => { run(st, 0.2, ctx); goals.push(st.goal); };
  step({ inShelter: true });
  step({ inShelter: true, generatorRepaired: true });
  step({ placeFound: true });
  step({ blueprintLearned: true });
  const fab = st.update(0.2, { fabricated: true });
  goals.push(st.goal);
  step({ beaconRepaired: true });
  assert.deepEqual(goals.map((g) => g.split(' ')[0]), ['Follow', 'Restore', 'Follow', 'Analyze', 'Return', 'Reach', 'Power']);
  assert.ok(fab.some((a) => a.type === 'system' && a.lines[0] === 'FABRICATION COMPLETE'));
  assert.equal(run(st, 1, { fabricated: true, generatorRepaired: true }).length, 0, 'beats fire once');
});
