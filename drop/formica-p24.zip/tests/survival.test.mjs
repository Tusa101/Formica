import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Survival } from '../src/gameplay/survival.js';
import { Inventory } from '../src/gameplay/inventory.js';
import { craft } from '../src/gameplay/crafting.js';
import { RITE_KIT, ITEMS } from '../src/data/items.js';
import { RECIPES } from '../src/data/recipes.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';

const sim = (s, secs, ctx) => { for (let t = 0; t < secs; t += 0.1) s.update(0.1, ctx); };

test('GDD §13/§69: 20 minutes of walking without eating leaves energy and water above half', () => {
  const s = new Survival();
  sim(s, 20 * 60, { air: 1, running: false });
  assert.ok(s.energy > 50 && s.hydration > 50, `E ${s.energy.toFixed(0)} W ${s.hydration.toFixed(0)}`);
  assert.equal(s.health, 100);
});

test('bad air drains breath first, then health; a filter or capsule buys time', () => {
  const s = new Survival();
  sim(s, 5, { air: 0.1 });
  assert.ok(s.breath < 60 && s.health === 100, 'breath first');
  sim(s, 20, { air: 0.1 });
  assert.ok(s.health < 100, 'then health');
  const f = new Survival(); f.use('spiracle_filter');
  const n = new Survival();
  sim(f, 12, { air: 0.3 }); sim(n, 12, { air: 0.3 });
  assert.ok(f.breath > n.breath + 20, `filter ${f.breath.toFixed(0)} vs ${n.breath.toFixed(0)}`);
  const c = new Survival(); c.use('air_capsule'); sim(c, 50, { air: 0 });
  assert.ok(c.breath > 95, 'capsule gives a clean minute');
});

test('breath recovers in good air; food, water and patches restore', () => {
  const s = new Survival({ breath: 10, energy: 20, hydration: 20, health: 40 });
  sim(s, 5, { air: 1 });
  assert.ok(s.breath > 99);
  s.use('food_ration'); s.use('water'); s.use('resin_patch');
  assert.ok(s.energy >= 59 && s.hydration >= 54 && s.health >= 70);
});

test('the Vibro Pick needs chemical cells; mandibles only cost body energy', () => {
  const s = new Survival();
  assert.equal(s.canBite('vibropick'), false);
  assert.equal(s.bite('vibropick'), false);
  const e0 = s.energy; assert.ok(s.bite('mandibles')); assert.ok(s.energy < e0);
  s.use('chemical_cell');
  let bites = 0; while (s.bite('vibropick')) bites++;
  assert.ok(bites >= 60 && bites <= 70, `${bites} bites per cell`);
});

test('death and respawn keep the kit', () => {
  const s = new Survival({ health: 3 });
  sim(s, 5, { air: 0 });
  sim(s, 10, { air: 0 });
  assert.ok(s.dead);
  s.respawn();
  assert.ok(!s.dead && s.health === 50 && s.breath === 100);
});

test('ADD §5 Rite Kit fits the carry limit; crafting spends materials and respects weight', () => {
  const inv = new Inventory();
  for (const [id, n] of Object.entries(RITE_KIT)) assert.ok(inv.add(id, n), id);
  assert.equal(inv.count('family_token'), 1);
  assert.ok(inv.weight < inv.limit / 2, `kit weight ${inv.weight}`);
  assert.equal(craft(inv, 'resin_support').ok, false, 'needs chitin');
  inv.add('chitin', 1);
  assert.ok(craft(inv, 'resin_support').ok);
  assert.equal(inv.count('resin'), 1); assert.equal(inv.count('resin_support'), 1);
  const heavy = new Inventory(1.45); assert.ok(heavy.add('resin', 2)); assert.ok(heavy.add('chitin', 1));
  assert.equal(craft(heavy, 'resin_support').reason, 'too heavy');
  assert.ok(!heavy.add('scrap', 3), 'over limit refused');
  for (const r of RECIPES) { assert.ok(ITEMS[r.out], r.id); for (const k of Object.keys(r.needs)) assert.ok(ITEMS[k], k); }
  assert.deepEqual(Inventory.from(inv.toJSON()).toJSON(), inv.toJSON());
});

test('every pickup and water source lies on a reachable floor', () => {
  const L = buildLevelField(T), { min, max } = T.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const nav = new NavGrid(f); nav.build();
  const main = nav.label[nav.nearestOpen(T.spawn.pos, 4)];
  for (const p of [...T.pickups, ...T.waterSources]) {
    assert.ok(ITEMS[p.item] || !p.item, p.id);
    const s = f.dropToSurface(p.pos, 6);
    assert.ok(s, `${p.id} has a floor`);
    const lab = nav.label[nav.nearestOpen([s[0], s[1] + 0.3, s[2]], 3)];
    if (!p.id.startsWith('sealed')) assert.equal(lab, main, `${p.id} reachable`);
  }
  assert.equal(new Set(T.pickups.map((p) => p.id)).size, T.pickups.length, 'unique ids');
});
