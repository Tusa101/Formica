import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { carveSphere } from '../src/world/terrain-ops.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { TEST_TUNNELS } from '../src/levels/test-tunnels.js';
import { Topology } from '../src/world/topology.js';
import { Atmosphere } from '../src/world/atmosphere.js';
import { receivedVibration } from '../src/world/vibration.js';
import { Beetle } from '../src/ai/beetle.js';
import { MAT } from '../src/data/materials.js';

const L = buildLevelField(TEST_TUNNELS);
function levelWorld() {
  const { min, max } = TEST_TUNNELS.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const topo = new Topology(f, TEST_TUNNELS); topo.build();
  const air = new Atmosphere(topo.nav, TEST_TUNNELS.air, (p) => L.zoneAt(...p, 0.3)); air.init();
  const dig = (a, b) => { const n = Math.ceil(Math.hypot(...a.map((v, i) => b[i] - v)) / 0.45); for (let s = 0; s <= n; s++) { const c = a.map((v, i) => v + (b[i] - v) * (s / n)); carveSphere(f, c, 0.72, { hardness: () => 0 }); topo.onEdit(c, 0.72); } air.markDirty(); };
  const sim = (secs, fn) => { for (let t = 0; t < secs; t += 0.1) { fn?.(); air.update(0.1); } };
  return { f, topo, air, dig, sim };
}
const opening = [[0, -2.2, 3.6], [0, -2.0, 7.6]];

test('stale chamber air stays sealed until the chamber is opened, then the atmospheres mix (ADD §78)', () => {
  const w = levelWorld();
  const inB = [0, -2.1, 4.5], inC = [0, -1.2, 9.6]; // inB: Room B end of the new opening
  assert.ok(w.air.quality(inC) < 0.2, `chamber starts stale (${w.air.quality(inC).toFixed(2)})`);
  w.sim(20);
  assert.ok(w.air.quality(inB) > 0.95, 'rock keeps it sealed');
  w.dig(...opening);
  const qc0 = w.air.quality(inC);
  w.sim(40);
  assert.ok(w.air.quality(inB) < 0.85, `Room B side of the opening got worse (${w.air.quality(inB).toFixed(2)})`);
  assert.ok(w.air.quality(inC) > qc0 + 0.05, `chamber air improved (${qc0.toFixed(2)} → ${w.air.quality(inC).toFixed(2)})`);
});

test('without vents, oxygen is conserved by diffusion', () => {
  const w = levelWorld();
  w.air.vents = []; w.air.seeps = [];
  const t0 = w.air.totalO2();
  w.sim(10);
  assert.ok(Math.abs(w.air.totalO2() - t0) / t0 < 1e-4);
});

test('scent decays, never passes through rock, and flows out through a fresh opening', () => {
  const w = levelWorld();
  const src = [0, -1.4, 9.6], inB = [0, -2.2, 3.4];
  w.sim(30, () => w.air.deposit('beetle', src, 0.05));
  assert.ok(w.air.scentAt('beetle', src) > 0.1);
  assert.equal(w.air.scentAt('beetle', inB), 0, 'no scent through the wall');
  w.dig(...opening);
  w.sim(60, () => w.air.deposit('beetle', src, 0.05));
  assert.ok(w.air.scentAt('beetle', inB) > 0.001, `scent reached Room B (${w.air.scentAt('beetle', inB)})`);
  const before = w.air.scentAt('beetle', src);
  w.sim(90);
  assert.ok(w.air.scentAt('beetle', src) < before * 0.6, 'decays without a source');
  assert.ok(w.air.crumbs.get('beetle').length >= 1);
});

test('vibration: an air gap damps more than solid rock; sand damps more than limestone', () => {
  const solid = { densityAt: () => 1, materialAt: () => MAT.CLAY };
  const gap = { densityAt: (x) => (x > 3 && x < 7 ? -1 : 1), materialAt: () => MAT.CLAY };
  const sand = { densityAt: () => 1, materialAt: () => MAT.SAND };
  const lime = { densityAt: () => 1, materialAt: () => MAT.LIMESTONE };
  const r = (f) => receivedVibration(f, [0, 0, 0], [10, 0, 0], 2);
  assert.ok(r(gap) < r(solid) * 0.3, `${r(gap)} vs ${r(solid)}`);
  assert.ok(r(sand) < r(lime) * 0.5);
  assert.ok(receivedVibration(solid, [0, 0, 0], [2, 0, 0], 2) > r(solid));
});

test('the beetle moves away from a strong vibration', () => {
  const w = levelWorld();
  w.dig(...opening);
  const b = new Beetle(w.f, w.topo, [0, -1.5, 9.6], 3);
  const source = [0, -1.5, 7.5];
  const d0 = Math.hypot(...b.pos.map((v, i) => v - source[i]));
  b.feel({ pos: source, received: 0.8 });
  assert.equal(b.state, 'walk');
  for (let t = 0; t < 15; t += 1 / 60) b.step(1 / 60);
  const d1 = Math.hypot(...b.pos.map((v, i) => v - source[i]));
  assert.ok(d1 > d0 + 1, `${d0.toFixed(1)} → ${d1.toFixed(1)}`);
});
