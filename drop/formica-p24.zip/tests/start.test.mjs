import { test } from 'node:test';
import assert from 'node:assert/strict';
import { placeLamps } from '../src/world/lamp-path.js';
import { chooseSources } from '../src/world/lamp-path.js';
import { Hints, HINTS } from '../src/story/hints.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';

test('ritual lamps line the whole way from the start to the shelter, on open floor', () => {
  const L = buildLevelField(T), { min, max } = T.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const nav = new NavGrid(f); nav.build();
  const lamps = placeLamps(T.rite.lampPath, (p) => (f.densityAt(...p) < 0 ? f.dropToSurface(p, 3) : null));
  assert.ok(lamps.length >= 14, `${lamps.length} lamps`);
  const main = nav.label[nav.nearestOpen(T.rite.spawn.pos, 3)];
  for (const l of lamps) {
    assert.ok(f.densityAt(l.pos[0], l.pos[1] + 0.5, l.pos[2]) < 0, 'room above the lamp');
    assert.equal(nav.label[nav.nearestOpen([l.pos[0], l.pos[1] + 0.3, l.pos[2]], 3)], main, 'reachable');
  }
  for (let i = 1; i < lamps.length; i++) {
    const g = Math.hypot(...lamps[i].pos.map((v, k) => v - lamps[i - 1].pos[k]));
    assert.ok(g < 6.5, `gap ${g.toFixed(1)} between lamp ${i - 1} and ${i}`);
  }
  assert.ok(Math.hypot(...lamps[0].pos.map((v, k) => v - T.rite.spawn.pos[k])) < 2.5, 'first lamp at the start');
  assert.ok(Math.hypot(...lamps.at(-1).pos.map((v, k) => v - T.shelter.respawn[k])) < 4, 'last lamp at the shelter');
  assert.ok(lamps.some((l) => l.flicker) && lamps.filter((l) => l.flicker).length < lamps.length / 4);
});

test('light pool picks the nearest sources with hysteresis and a fixed count', () => {
  const src = [0, 4, 8, 12, 16].map((x) => ({ pos: [x, 0, 0] }));
  assert.deepEqual(chooseSources(src, [0, 0, 0], 2), [0, 1]);
  assert.deepEqual(chooseSources(src, [6.2, 0, 0], 2, [0, 1]), [1, 2], 'far one swapped out');
  assert.deepEqual(chooseSources(src, [6.4, 0, 0], 2, [1, 2]), [1, 2], 'stays on near-ties');
  assert.equal(chooseSources(src, [100, 0, 0], 3).length, 3);
});

test('control tips: in order, once each, one at a time, touch vs keyboard, can be switched off', () => {
  const h = new Hints();
  const ctx = { playing: true, t: 0, signal: true };
  const shown = [];
  const run = (secs, extra = {}) => { for (let t = 0; t < secs; t += 0.1) { ctx.t += 0.1; const x = h.update(0.1, { ...ctx, ...extra }, true); if (x) shown.push(x); } };
  run(20);
  assert.deepEqual(shown.map((x) => x.id), ['move', 'signal']);
  assert.equal(shown[0].text, HINTS[0].touch);
  run(12, { aimPickup: true, wallAhead: true });
  assert.deepEqual(shown.map((x) => x.id).slice(2), ['walls', 'use']);
  run(30, { aimPickup: true, wallAhead: true });
  assert.equal(shown.length, 4, 'nothing repeats');
  const k = new Hints(['move']); assert.equal(k.update(0.1, { playing: true, t: 5 }, false), null);
  const off = new Hints([], { enabled: false }); assert.equal(off.update(0.1, { playing: true, t: 5 }, false), null);
  assert.deepEqual(new Hints(h.toJSON()).toJSON().sort(), h.toJSON().sort());
});
