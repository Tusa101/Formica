import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { fillSphere } from '../src/world/terrain-ops.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { GroundNav, reachableWithAdhesion } from '../src/world/ground-nav.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { RITE_KIT } from '../src/data/items.js';
import { MODULE_TYPES } from '../src/data/modules.js';
import { MAT } from '../src/data/materials.js';

function fieldOf(fn, min, max, N = 20, v = 0.4) {
  const f = new DensityField(N, v, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, N, v, fn.density || fn, fn.material || (() => 1)));
  return f;
}
function world(opts) {
  const L = buildLevelField(T, opts);
  const f = fieldOf(L, T.chunks.min, T.chunks.max, 40);
  // the Rite's opening: route sealed behind the initiate, old rubble in the South Loop
  for (const s of [...T.rite.seal, ...T.rite.loopRubble]) fillSphere(f, s.c, s.r, MAT.SAND);
  const nav = new NavGrid(f); nav.build();
  const g = new GroundNav(nav, f).build();
  return { f, nav, g };
}

test('synthetic: walk up a gentle step, not a wall; drops are one-way', () => {
  // box room with a 0.6 u step (walkable) and a 3 u shelf (wall)
  const box = (x, y, z) => { const q = [Math.abs(x) - 6, Math.abs(y + 1) - 3, Math.abs(z) - 3]; return Math.hypot(...q.map((a) => Math.max(a, 0))) + Math.min(Math.max(...q), 0); };
  const block = (x, y, z, x0, x1, top) => Math.max(x0 - x, x - x1, y - top, -y - 5, Math.abs(z) - 4);
  const f = fieldOf((x, y, z) => Math.max(box(x, y, z), -block(x, y, z, -2, -0.01, -3.4), -block(x, y, z, 2, 7, -1)), [-1, -1, -1], [0, 0, 0]);
  const nav = new NavGrid(f); nav.build();
  const g = new GroundNav(nav, f).build();
  const floor = [-4, -3.4, 0], step = [-1, -2.9, 0], shelf = [4, -0.4, 0];
  assert.ok(g.reachable(floor, step), 'onto a low step and back');
  assert.ok(!g.reachable(floor, shelf, { back: false }), 'cannot walk up a 3 u wall');
  assert.ok(g.reachable(shelf, floor, { back: false }), 'can jump down from the shelf');
  assert.ok(!g.reachable(shelf, floor), '…but not come back');
});

const w = world();
const S = T.rite.spawn.pos, H = T.shelter.respawn;
const floorOf = (p) => { const s = w.f.dropToSurface(p, 6); return s ? [s[0], s[1] + 0.3, s[2]] : p; };

test('A3 §45.1/§45.9: from the Rite start the shelter is reachable on foot — and the ant can walk back', () => {
  assert.ok(w.g.reachable(S, H), 'start ⇄ shelter on foot');
});

test('A3 §45.2–3: every shelter module except the gated beacon, the condenser and a water drip are reachable on foot', () => {
  for (const m of T.shelter.modules) {
    if (m.type === 'lighting') continue; // hangs from the ceiling
    const ok = w.g.reachable(H, floorOf(m.pos));
    if (m.id === 'beacon') assert.ok(!ok, 'beacon room is behind the rubble gate');
    else assert.ok(ok, `${m.id} reachable`);
  }
  assert.ok(T.waterSources.some((d) => w.g.reachable(H, floorOf(d.pos))), 'a drip is reachable');
});

test('A3 §45.4: resources for the tutorial repairs are reachable (with the Rite Kit)', () => {
  const need = {};
  for (const id of ['power', 'air', 'fabricator']) {
    const m = T.shelter.modules.find((x) => x.id === id);
    for (const [k, n] of Object.entries(MODULE_TYPES[m.type].repair[m.state])) need[k] = (need[k] || 0) + n;
  }
  const have = { ...RITE_KIT };
  const reach = w.g.reachableFrom(S);
  for (const p of T.pickups) if (reach.has(w.g.cellNear(floorOf(p.pos)))) have[p.item] = (have[p.item] || 0) + (p.n || 1);
  for (const [k, n] of Object.entries(need)) assert.ok((have[k] || 0) >= n, `${k}: need ${n}, reachable ${have[k] || 0}`);
});

test('A3 §7: the beacon is behind a visible gate — open it and the room is reachable; never blind rock', () => {
  const beacon = floorOf(T.shelter.modules.find((m) => m.id === 'beacon').pos);
  const open = world({ openGates: true });
  assert.ok(open.g.reachable(H, beacon), 'reachable once the rubble is cleared');
  for (const gate of T.gates) {
    const mid = gate.a.map((v, i) => (v + gate.b[i]) / 2);
    // the gate's near face borders space the ant can already reach
    const reach = w.g.reachableFrom(H);
    let borders = false;
    for (let dz = -3; dz <= 0 && !borders; dz += 0.4) { const c = w.g.cellNear([mid[0], mid[1], gate.a[2] - 1 + dz], 1); if (c >= 0 && reach.has(c)) borders = true; }
    assert.ok(borders, `${gate.id} is visible from reachable space`);
  }
});

test('A3 §45.9: nothing critical needs the Adhesion Suit; the sandbox course is walkable', () => {
  const critical = [H, ...T.shelter.modules.filter((m) => m.type !== 'lighting' && m.id !== 'beacon').map((m) => floorOf(m.pos))];
  for (const p of critical) {
    assert.ok(reachableWithAdhesion(w.nav, S, p));
    assert.ok(w.g.reachable(S, p), `on foot: ${p.map((v) => v.toFixed(1))}`);
  }
  const sand = world({ openGates: false });
  for (const gate of T.course.gates) assert.ok(sand.g.reachable(T.spawn.pos, floorOf(gate.pos), { back: false }), `course gate ${gate.name}`);
});
