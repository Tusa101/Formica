import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG, BUILD } from '../src/config.js';

test('CONFIG is deeply frozen', () => {
  assert.ok(Object.isFrozen(CONFIG) && Object.isFrozen(CONFIG.render));
});
test('sane ranges', () => {
  assert.ok(CONFIG.sim.step > 0 && CONFIG.sim.step <= 1 / 30);
  assert.ok(CONFIG.input.stickDeadzone >= 0 && CONFIG.input.stickDeadzone < 0.5);
  assert.ok(CONFIG.ui.minTouchTarget >= 44);
  assert.ok(CONFIG.render.near > 0 && CONFIG.render.far > CONFIG.render.fogFar);
});
test('BUILD is a string', () => { assert.equal(typeof BUILD, 'string'); });
