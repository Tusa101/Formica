import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { carveSphere } from '../src/world/terrain-ops.js';
import { NavGrid } from '../src/world/navgrid.js';
import { Exploration } from '../src/gameplay/exploration.js';
import { VibrationSense, SECTORS } from '../src/gameplay/senses.js';

// two rooms separated by a 2-unit wall, a long corridor out of room A
function world() {
  const f = new DensityField(20, 0.4, [-2, -1, -2], [1, 0, 1]);
  const fn = (x, y, z) => Math.min(Math.hypot(x + 5, y, z) - 2.5, Math.hypot(x - 2, y, z) - 2.5, Math.max(Math.abs(y) - 0.8, Math.abs(z) - 0.8, x < -30 || x > -5 ? 9 : -1));
  for (let cz = -2; cz <= 1; cz++) for (let cy = -1; cy <= 0; cy++) for (let cx = -2; cx <= 1; cx++) f.set(cx, cy, cz, generateChunk(cx, cy, cz, 20, 0.4, fn, () => 1));
  const nav = new NavGrid(f); nav.build();
  return { f, nav };
}

test('seeing stops at rock and at the radius; digging opens more', () => {
  const { f, nav } = world();
  const ex = new Exploration(nav);
  ex.reveal([-5, 0, 0], 5);
  const seen = (p) => ex.seen[nav.nearestOpen(p, 1)] === 1;
  assert.ok(seen([-5, 0, 0]) && seen([-6.5, 0, 0]));
  assert.ok(!seen([2, 0, 0]), 'room B hidden behind the wall');
  assert.ok(!seen([-20, 0, 0]), 'far corridor beyond radius');
  carveSphere(f, [-1.5, 0, 0], 1.2, { hardness: () => 0 });
  nav.updateBox([-4, -2, -2], [1, 2, 2]);
  ex.reveal([-2.5, 0, 0], 5);
  assert.ok(seen([1, 0, 0]), 'after the dig the ant sees into room B');
});

test('route history is spaced and capped; markers round-trip; seen cells compress', () => {
  const { nav } = world();
  const ex = new Exploration(nav, { routeMax: 10 });
  for (let x = 0; x < 30; x += 0.2) ex.addRoute([x, 0, 0]);
  assert.equal(ex.route.length, 10);
  assert.ok(Math.abs(ex.route[1][0] - ex.route[0][0] - 1.6) < 0.3);
  const m = ex.addMarker('danger', [1, 2, 3]); ex.addMarker('home', [-5, 0, 0]);
  assert.equal(ex.nearestMarker([1, 2, 3.5]).id, m.id);
  ex.reveal([-5, 0, 0], 5);
  const copy = new Exploration(nav); copy.load(JSON.parse(JSON.stringify(ex.toJSON())));
  assert.deepEqual(copy.seen, ex.seen);
  assert.equal(copy.markers.length, 2);
  assert.ok(JSON.stringify(ex.toJSON().seen).length < 2000, 'run-length encoded');
  copy.removeMarker(m.id); assert.equal(copy.markers.length, 1);
});

test('vibration sense: right → right sector, behind → rear, below → "below"; decays', () => {
  const vs = new VibrationSense();
  const eye = [0, 0, 0], fwd = [0, 0, -1], up = [0, 1, 0];
  assert.equal(vs.feel({ pos: [5, 0, 0], received: 0.5 }, eye, fwd, up), SECTORS / 4, 'right');
  assert.equal(vs.feel({ pos: [0, 0, 5], received: 0.5 }, eye, fwd, up), SECTORS / 2, 'behind');
  assert.equal(vs.feel({ pos: [-5, 0, 0], received: 0.5 }, eye, fwd, up), (3 * SECTORS) / 4, 'left');
  vs.feel({ pos: [0, -5, 0.3], received: 0.5 }, eye, fwd, up);
  assert.ok(vs.down > 0.9);
  for (let t = 0; t < 2; t += 0.1) vs.update(0.1);
  assert.ok(Math.max(...vs.s) < 0.05 && vs.down < 0.05);
});
