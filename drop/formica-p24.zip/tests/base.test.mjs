import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BaseNetwork } from '../src/gameplay/base.js';
import { Inventory } from '../src/gameplay/inventory.js';
import { craft } from '../src/gameplay/crafting.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';

const fresh = () => new BaseNetwork(T.shelter.modules);
const inv = (items) => Inventory.from(items, 40);

test('A3 §26: the degraded starter generator keeps air and light alive; after one cheap repair all essentials run', () => {
  const b = fresh();
  assert.equal(b.supply, 0.6);
  assert.ok(b.isPowered('air') && b.isPowered('lights'));
  assert.ok(!b.isPowered('condenser'), 'water needs the repaired generator');
  const i = inv({ resin: 3 });
  assert.ok(b.repair('generator', i).ok, 'the Rite Kit resin is enough');
  assert.equal(b.supply, 1.2);
  for (const id of ['air', 'condenser', 'lights', 'terminal']) assert.ok(b.isPowered(id), id);
  assert.ok(b.repair('fabricator', inv({ resin: 3, scrap: 2, chitin: 1 })).ok);
  assert.ok(b.isPowered('fabricator'));
  assert.ok(Math.abs(b.demand - 1.1) < 1e-9 && !b.insufficient, 'essential load 1.10 < 1.20');
  assert.equal(b.airSources().find((s) => s.pos === b.get('air').pos).radius, 1.6, 'processor still degraded');
});

test('A3 §27: essentials stay powered indefinitely — no fuel, ten hours', () => {
  const b = fresh();
  b.repair('generator', inv({ resin: 2 })); b.repair('fabricator', inv({ resin: 3, scrap: 2, chitin: 1 }));
  for (let t = 0; t < 10 * 3600; t += 5) b.update(5);
  for (const id of ['air', 'condenser', 'lights', 'terminal', 'fabricator']) assert.ok(b.isPowered(id), id);
});

test('A3 §28–29: expansion exceeds starter power; optional loads are shed, the auxiliary generator covers the excess', () => {
  const b = fresh();
  const i = inv({ resin: 20, scrap: 20, chitin: 20, chemical_cell: 2 });
  for (const id of ['generator', 'fabricator', 'beacon']) assert.ok(b.repair(id, i).ok, id);
  assert.ok(b.insufficient && !b.isPowered('beacon'), 'DEMAND 1.90 > GENERATION 1.20');
  for (const id of ['air', 'condenser', 'lights']) assert.ok(b.isPowered(id), `${id} protected`);
  const boost = b.place('booster', [21, -4.5, -14]);
  assert.ok(!b.get(boost.id).powered && b.isPowered('air'), 'booster shed before air');
  assert.ok(b.repair('power', i).ok);
  assert.ok(!b.isPowered('beacon'), 'aux generator has no fuel yet');
  assert.ok(b.refuel('power', i).ok);
  assert.ok(b.isPowered('beacon') && b.get(boost.id).powered);
  const f0 = b.get('power').fuel;
  b.update(10);
  const burned = f0 - b.get('power').fuel;
  assert.ok(Math.abs(burned - (10 * (b.used - 1.2)) / 15) < 1e-6, 'fuel burns only for the load above the starter generator');
});

test('air pipes extend the network only within range and line of sight; boosters need power', () => {
  const wall = (a, b) => !(Math.min(a[0], b[0]) < 30 && Math.max(a[0], b[0]) > 30); // rock at x = 30
  const b = new BaseNetwork([{ id: 'p', type: 'power', pos: [0, 0, 0], state: 'working', fuel: 100 }, { id: 'air', type: 'air', pos: [0, 0, 0], state: 'working' }], { los: wall });
  const p1 = b.place('pipe', [5, 0, 0]);
  const p2 = b.place('pipe', [10.5, 0, 0]);
  const far = b.place('pipe', [20, 0, 0]);
  assert.ok(b.linked.has(p1.id) && b.linked.has(p2.id));
  assert.ok(!b.linked.has(far.id), 'gap of 9.5 is too long for pipes');
  const boost = b.place('booster', [21.5, 0, 0]);
  assert.ok(b.linked.has(boost.id) && b.linked.has(far.id), 'booster bridges 11 u and relays');
  const behind = b.place('pipe', [31, 0, 0]);
  assert.ok(!b.linked.has(behind.id), 'rock blocks the link');
  assert.equal(b.airSources().length, 1 + 4);
});

test('forward camp: own air bubble on a 10-minute battery, refillable with a cell', () => {
  const b = new BaseNetwork([]);
  const c = b.place('camp', [0, 0, 0]);
  assert.equal(b.airSources().length, 1);
  for (let s = 0; s < 601; s++) b.update(1);
  assert.equal(b.airSources().length, 0);
  assert.ok(b.refuel(c.id, inv({ chemical_cell: 1 })).ok);
  assert.equal(b.airSources().length, 1);
});

test('fabricator recipes need a working fabricator; state survives save/load', () => {
  const i = inv({ resin: 5, chitin: 5, scrap: 3, chemical_cell: 1, formic_metal: 2 });
  assert.equal(craft(i, 'air_pipe').reason, 'needs fabricator');
  assert.ok(craft(i, 'air_pipe', { fabricator: true }).ok);
  assert.equal(i.count('air_pipe'), 2);
  const b = fresh(); b.repair('generator', inv({ resin: 2 })); b.place('pipe', [16, -5, -12]);
  const c = fresh(); c.load(JSON.parse(JSON.stringify(b.toJSON())));
  assert.equal(c.get('generator').state, 'working');
  assert.equal(c.ofType('pipe').length, 1);
});

import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { Atmosphere } from '../src/world/atmosphere.js';

test('A3 §24–25: the home is safe — the shelter air is breathable from the start and clears quickly', () => {
  const L = buildLevelField(T), { min, max } = T.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const nav = new NavGrid(f); nav.build();
  const air = new Atmosphere(nav, T.air, (p) => L.zoneAt(...p, 0.3)); air.init();
  const b = new BaseNetwork(T.shelter.modules.map((m) => { const s = f.dropToSurface(m.pos, 6); return { ...m, pos: s ? [s[0], s[1] + 0.3, s[2]] : m.pos }; }));
  air.setSources(b.airSources());
  const q0 = air.quality(T.shelter.respawn);
  assert.ok(q0 >= 0.7, `breathable at arrival (${q0.toFixed(2)})`);
  for (let t = 0; t < 60; t += 0.1) air.update(0.1);
  assert.ok(air.quality(T.shelter.respawn) > 0.85, `clears with the degraded processor (${air.quality(T.shelter.respawn).toFixed(2)})`);
  assert.ok(!(T.air.seeps || []).length, 'no CO₂ seep at home');
  assert.ok(T.shelter.stash.food_ration >= 1, 'starting food in storage');
});
