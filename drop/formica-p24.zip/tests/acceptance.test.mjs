// ADDENDUM 03 §47 — demo acceptance test, run on the real systems without a renderer.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG } from '../src/config.js';
import { modeUp } from '../src/player/camera-math.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { carveSphere, fillSphere } from '../src/world/terrain-ops.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { GroundNav } from '../src/world/ground-nav.js';
import { Topology } from '../src/world/topology.js';
import { BaseNetwork } from '../src/gameplay/base.js';
import { Inventory } from '../src/gameplay/inventory.js';
import { Receiver } from '../src/gameplay/receiver.js';
import { Research } from '../src/gameplay/research.js';
import { craft } from '../src/gameplay/crafting.js';
import { findShortcuts } from '../src/gameplay/subsurface.js';
import { RITE_KIT } from '../src/data/items.js';
import { MAT } from '../src/data/materials.js';

const L = buildLevelField(T), { min, max } = T.chunks;
const f = new DensityField(40, 0.4, min, max);
for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
  f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
for (const s of [...T.rite.seal, ...T.rite.loopRubble]) fillSphere(f, s.c, s.r, MAT.SAND);
const nav = new NavGrid(f); nav.build();
const g = new GroundNav(nav, f).build();
const S = T.rite.spawn.pos, H = T.shelter.respawn;
const floor = (p) => { const s = f.dropToSurface(p, 5); return s ? [s[0], s[1] + 0.3, s[2]] : p; };

test('A3 §47 — the demo loop, end to end', () => {
  // 1. comfortable movement: no forced roll
  assert.equal(CONFIG.ant.adhesion, false);
  assert.deepEqual(modeUp([0, 0, 0], [1, 0, 0], 'horizon', 0.35), [0, 1, 0]);
  // 2. reach the shelter by following a signal — on foot, and back
  const rx = new Receiver(T.beacons);
  assert.equal(rx.readout(S).id, 'shelter', 'the shelter beacon is tracked from the start');
  assert.ok(g.reachable(S, H));
  // 3. restore it with what the Rite Kit carries
  const inv = Inventory.from(RITE_KIT, 30);
  const base = new BaseNetwork(T.shelter.modules);
  assert.ok(base.repair('generator', inv).ok);
  // 4. essentials stay powered indefinitely
  for (let t = 0; t < 3600; t += 10) base.update(10);
  for (const id of ['air', 'condenser', 'lights']) assert.ok(base.isPowered(id), id);
  // 5. expansion exceeds starter power
  assert.ok(base.repair('beacon', Inventory.from({ scrap: 4, chitin: 2, resin: 2 })).ok);
  assert.ok(base.insufficient && !base.isPowered('beacon'));
  // 6. nearby destinations are detected from the restored shelter
  assert.ok(rx.upgrade(2.5, H) >= 3);
  // 7. leave with a purpose: a local signal to follow
  for (let t = 0; t < 12; t += 0.1) rx.update(0.1, H);
  assert.ok(rx.trackable().some((b) => b.id !== 'shelter'));
  // 8. follow connected routes, not blind digging
  const cache = T.pois.find((q) => q.id === 'cache');
  assert.ok(g.reachable(H, floor(cache.center)));
  // 9–10. scan a machine: blueprint + salvage
  const rs = new Research();
  const coil = rs.analyze('receiver_coil', 'sal-coil');
  assert.equal(coil.unlocked, 'receiver_amp');
  const crate = rs.analyze('cache_crate', 'sal-crate-1');
  for (const r of [coil, crate]) for (const [k, n] of Object.entries(r.salvage)) inv.add(k, n);
  // 11. return home and fabricate the learned item
  assert.ok(craft(inv, 'receiver_amp', { fabricator: true }, rs.blueprints).ok);
  assert.equal(inv.count('receiver_amp'), 1);
  // 12. the Subsurface Scanner finds nearby geometry; digging a shortcut connects it
  const topo = new Topology(f, T); topo.build();
  const sc = findShortcuts(f, topo, [-10, -1.9, 0]).find((c) => !c.sealed);
  assert.ok(sc && sc.walk - sc.straight > 15);
  const n = Math.ceil(sc.thickness / 0.45) + 2;
  for (let s = 0; s <= n; s++) { const c = sc.hit.map((v, i) => v + (sc.beyond[i] - v) * (s / n)); carveSphere(f, c, 0.72, { hardness: () => 0 }); topo.onEdit(c, 0.72); }
  assert.ok([...topo.tick(1), ...topo.tick(1)].some((e) => e.type === 'passage'), 'a useful shortcut');
});
