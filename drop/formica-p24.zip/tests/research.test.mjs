import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Research, OUTCOME } from '../src/gameplay/research.js';
import { CATALOG } from '../src/data/analysis.js';
import { RECIPES } from '../src/data/recipes.js';
import { ITEMS } from '../src/data/items.js';
import { Inventory } from '../src/gameplay/inventory.js';
import { craft } from '../src/gameplay/crafting.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { GroundNav } from '../src/world/ground-nav.js';

test('A3 §31–33: all five outcomes; salvage only for salvageable objects', () => {
  const r = new Research();
  const bp = r.analyze('pipe_segment', 'a');
  assert.equal(bp.outcome, OUTCOME.BLUEPRINT); assert.equal(bp.unlocked, 'air_pipe'); assert.ok(bp.destroy); assert.equal(bp.salvage.formic_metal, 1);
  const dup = r.analyze('pipe_segment', 'b');
  assert.equal(dup.outcome, OUTCOME.KNOWN); assert.ok(dup.destroy && dup.salvage.membrane === 1, 'duplicates stay useful');
  const fr = r.analyze('fan_housing', 'c');
  assert.equal(fr.outcome, OUTCOME.FRAGMENT); assert.deepEqual([fr.fragment.have, fr.fragment.need], [1, 2]);
  assert.ok(fr.lines[1].includes('1 / 2'));
  const res = r.analyze('actuator', 'd');
  assert.equal(res.outcome, OUTCOME.RESOURCES); assert.equal(res.salvage.formic_metal, 3);
  const kn = r.analyze('beetle');
  assert.equal(kn.outcome, OUTCOME.KNOWLEDGE); assert.ok(!kn.destroy, 'living things are not dismantled');
  const prot = r.analyze('generator');
  assert.ok(!prot.destroy && !Object.keys(prot.salvage).length, 'running infrastructure is protected');
  assert.equal(r.analyze('actuator', 'd').destroy, false, 'an object is dismantled once');
});

test('A3 §35–36: a fragmented blueprint needs distinct components, not the same one twice', () => {
  const r = new Research();
  r.analyze('fan_housing', 'x'); r.analyze('fan_housing', 'y');
  assert.ok(!r.blueprints.has('air_booster'));
  const done = r.analyze('pressure_regulator', 'z');
  assert.equal(done.outcome, OUTCOME.BLUEPRINT); assert.equal(done.unlocked, 'air_booster');
});

test('fabricator recipes are locked until learned; field recipes are known from the rite', () => {
  const r = new Research();
  const inv = Inventory.from({ resin: 9, formic_metal: 9, membrane: 9, chitin: 9, scrap: 9, fungus: 9 }, 99);
  assert.equal(craft(inv, 'air_pipe', { fabricator: true }, r.blueprints).reason, 'unknown blueprint');
  assert.ok(craft(inv, 'resin_patch', {}, r.blueprints).ok);
  r.analyze('pipe_segment');
  assert.ok(craft(inv, 'air_pipe', { fabricator: true }, r.blueprints).ok);
});

test('catalog integrity: every blueprint recipe is learnable on this level, all salvage items exist', () => {
  for (const [k, d] of Object.entries(CATALOG)) for (const it of Object.keys(d.salvage || {})) assert.ok(ITEMS[it], `${k}: ${it}`);
  const kinds = new Set(T.salvage.map((s) => s.kind));
  for (const rcp of RECIPES.filter((x) => x.blueprint)) {
    const sources = Object.entries(CATALOG).filter(([k, d]) => kinds.has(k) && (d.blueprint === rcp.id || d.fragment?.bp === rcp.id));
    assert.ok(sources.length, `${rcp.id} has sources`);
    const frag = sources.find(([, d]) => d.fragment);
    if (frag) for (const part of frag[1].fragment.parts) assert.ok(sources.some(([, d]) => d.fragment?.part === part), `${rcp.id}: ${part} placed`);
  }
  for (const i of T.rite.inspectables) assert.ok(CATALOG[i.id], `inspectable ${i.id} analysable`);
});

test('salvage objects are reachable on foot from the shelter; research saves', () => {
  const L = buildLevelField(T), { min, max } = T.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const nav = new NavGrid(f); nav.build();
  const g = new GroundNav(nav, f).build();
  for (const s of T.salvage.filter((x) => !x.ceiling)) { // ceiling caches are suit-only (P22)
    assert.ok(f.densityAt(...s.pos) < 0, `${s.id} not inside rock`);
    const fl = f.dropToSurface(s.pos, 4);
    assert.ok(fl, `${s.id} has a floor`);
    assert.ok(g.reachable(T.shelter.respawn, [fl[0], fl[1] + 0.3, fl[2]]), `${s.id} reachable`);
  }
  const r = new Research(); r.analyze('fan_housing', 'q'); r.analyze('pipe_segment', 'w');
  const c = new Research(JSON.parse(JSON.stringify(r.toJSON())));
  assert.ok(c.blueprints.has('air_pipe') && c.fragments.get('air_booster').has('Fan Housing') && c.salvaged.has('q'));
});
