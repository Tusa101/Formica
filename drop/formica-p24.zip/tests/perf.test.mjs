import { test } from 'node:test';
import assert from 'node:assert/strict';
import { writeAttributes } from '../src/render/buffers.js';

// Minimal geometry stand-in with the three.js API surface writeAttributes uses.
function fakeGeo() {
  return {
    attrs: {}, disposed: 0, created: 0, range: null,
    getAttribute(n) { return this.attrs[n]; },
    setAttribute(n, a) { this.attrs[n] = a; this.created++; },
    dispose() { this.disposed++; },
    setDrawRange(s, c) { this.range = [s, c]; },
  };
}
const make = (arr, itemSize) => ({ array: arr, itemSize, needsUpdate: false });

test('attributes are updated in place while capacity lasts; growing disposes once', () => {
  const g = fakeGeo();
  writeAttributes(g, { position: { data: new Float32Array(30), itemSize: 3 } }, make);
  assert.equal(g.created, 1); assert.deepEqual(g.range, [0, 10]);
  for (let i = 0; i < 100; i++) writeAttributes(g, { position: { data: new Float32Array(3 * (5 + (i % 50))), itemSize: 3 } }, make);
  assert.equal(g.created, 1, 'no new buffers for 100 updates within capacity');
  assert.equal(g.disposed, 0);
  writeAttributes(g, { position: { data: new Float32Array(3 * 500), itemSize: 3 } }, make);
  assert.equal(g.disposed, 1); assert.equal(g.created, 2); assert.deepEqual(g.range, [0, 500]);
});
