import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { carveSphere } from '../src/world/terrain-ops.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { Topology } from '../src/world/topology.js';
import { pulseCells, wallProbe, findShortcuts } from '../src/gameplay/subsurface.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';
import { CATALOG } from '../src/data/analysis.js';

test('pulse reveals space behind rock but not beyond its radius; wall thickness is measured', () => {
  const f = new DensityField(20, 0.4, [-2, -1, -1], [1, 0, 0]);
  const fn = (x, y, z) => Math.min(Math.hypot(x + 6, y, z) - 2.5, Math.hypot(x - 1, y, z) - 2.5, Math.hypot(x - 14, y, z) - 1.5);
  for (let cz = -1; cz <= 0; cz++) for (let cy = -1; cy <= 0; cy++) for (let cx = -2; cx <= 1; cx++) f.set(cx, cy, cz, generateChunk(cx, cy, cz, 20, 0.4, fn, () => 1));
  const nav = new NavGrid(f); nav.build();
  const cells = pulseCells(nav, [-6, 0, 0], 10);
  const has = (p) => cells.some((c) => Math.hypot(...nav.worldPos(c).map((v, i) => v - p[i])) < 1.2);
  assert.ok(has([1 - 2.5, 0, 0]) && has([1 + 2.5, 0, 0]), 'room behind the wall is revealed');
  assert.ok(!has([14, 0, 0]), 'beyond the radius stays hidden');
  const w = wallProbe(f, [-6, 0, 0], [1, 0, 0], 4);
  assert.ok(Math.abs(w.thickness - 2.0) < 0.4, `thickness ${w.thickness.toFixed(2)}`);
});

const L = buildLevelField(T), { min, max } = T.chunks;
const field = new DensityField(40, 0.4, min, max);
for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
  field.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
const topo = new Topology(field, T); topo.build();

test('A3 §8/§46.10: from Room A the scanner proposes a shortcut into Room B that saves a long walk', () => {
  const eye = [-10, -1.9, 0];
  const sc = findShortcuts(field, topo, eye);
  const toB = sc.find((c) => topo.graph.nodes[c.node] && L.zoneAt(...c.beyond, 1) === 'Room B');
  assert.ok(toB, JSON.stringify(sc.map((c) => [L.zoneAt(...c.beyond, 1), c.thickness.toFixed(1), c.walk])));
  assert.ok(toB.thickness <= 5 && toB.walk - toB.straight > 15, `wall ${toB.thickness.toFixed(1)} u, walk ${toB.walk.toFixed(0)} u`);
  // digging along the suggestion connects the rooms (P04 passage event)
  const n = Math.ceil(toB.thickness / 0.45) + 2;
  for (let s = 0; s <= n; s++) { const c = toB.hit.map((v, i) => v + (toB.beyond[i] - v) * (s / n)); carveSphere(field, c, 0.72, { hardness: () => 0 }); topo.onEdit(c, 0.72); }
  const ev = [...topo.tick(1), ...topo.tick(1)];
  assert.ok(ev.some((e) => e.type === 'passage'), JSON.stringify(ev));
});

test('the Sealed Chamber shows up as a sealed cavity from Room B', () => {
  const sc = findShortcuts(field, topo, [0, -1.9, 3.2]);
  assert.ok(sc.some((c) => c.sealed && L.zoneAt(...c.beyond, 1) === 'Sealed Chamber'), JSON.stringify(sc.map((c) => [L.zoneAt(...c.beyond, 1), c.sealed])));
});

test('the Geological Lens blueprint can be learned on this level', () => {
  const src = T.salvage.find((s) => CATALOG[s.kind]?.blueprint === 'scanner_lens');
  assert.ok(src, 'survey probe placed');
});
