// Save format version, migration, export/import, reset (P12.3). Owns the list of formica.* keys.
export const SAVE_FORMAT = 2;
const VERSION_KEY = 'formica.saveFormat';
const PREFIX = 'formica.';

export function saveKeys(storage) {
  const out = [];
  for (let i = 0; i < storage.length; i++) { const k = storage.key(i); if (k && k.startsWith(PREFIX)) out.push(k); }
  return out.sort();
}

/** Brings stored data up to SAVE_FORMAT. @returns {{from:number, to:number}} */
export function migrate(storage) {
  let from = Number(storage.getItem(VERSION_KEY) || 1);
  if (from > SAVE_FORMAT) return { from, to: from, newer: true };
  // v1 → v2: formats are compatible (P01–P11 data); only the version marker is added.
  storage.setItem(VERSION_KEY, String(SAVE_FORMAT));
  return { from, to: SAVE_FORMAT };
}

export function saveSize(storage) {
  let n = 0;
  for (const k of saveKeys(storage)) n += k.length + (storage.getItem(k)?.length || 0);
  return n * 2; // UTF-16 bytes
}

export function exportSave(storage) {
  const data = {};
  for (const k of saveKeys(storage)) data[k] = storage.getItem(k);
  return JSON.stringify({ formica: SAVE_FORMAT, exported: new Date().toISOString(), data });
}

export function importSave(storage, text) {
  const obj = JSON.parse(text);
  if (!obj || typeof obj.data !== 'object' || !obj.formica) throw new Error('not a FORMICA save');
  for (const k of saveKeys(storage)) if (k !== 'formica.settings') storage.removeItem(k);
  for (const [k, v] of Object.entries(obj.data)) if (k.startsWith(PREFIX)) storage.setItem(k, v);
  return migrate(storage);
}

export function resetAll(storage, keepSettings = true) {
  for (const k of saveKeys(storage)) if (!(keepSettings && k === 'formica.settings')) storage.removeItem(k);
  storage.setItem(VERSION_KEY, String(SAVE_FORMAT));
}

/**
 * Exact dig-log compaction: a carve that is fully contained in a later carve of the same hardness, with no fill in
 * between, changes nothing (min of signed distances) and is dropped.
 */
export function compactOps(ops, window = 64) {
  const keep = new Array(ops.length).fill(true);
  for (let i = 0; i < ops.length; i++) {
    const a = ops[i];
    if (a[5] === 1) continue; // fill
    for (let j = i + 1; j < ops.length && j <= i + window; j++) {
      const b = ops[j];
      if (b[5] === 1) break;
      if (b[4] !== a[4]) continue;
      if (Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]) + a[3] <= b[3] + 1e-9) { keep[i] = false; break; }
    }
  }
  return ops.filter((_, i) => keep[i]);
}
