// The Rite — mini vertical slice script (GDD §63–64, §73; ADD §2–8). Pure JS: the scene supplies a context each tick
// and executes the returned actions. Every beat fires once; state is serialisable.
import { ESCORT, RITE_KIT_BOOT, RECORDINGS } from '../data/lore.js';

export class RiteStory {
  constructor(state = null) {
    this.s = state || { phase: 'off', t: 0, done: [], stats: { deaths: 0 } };
  }
  get phase() { return this.s.phase; }
  get active() { return this.s.phase !== 'off'; }
  did(id) { return this.s.done.includes(id); }
  _once(id, out, ...actions) { if (this.did(id)) return false; this.s.done.push(id); out.push(...actions); return true; }

  start() { this.s = { phase: 'opening', t: 0, done: [], stats: { deaths: 0 } }; }

  /** Whether the shelter bearing is shown (ADD §6: direction, not a path). */
  get signal() { return this.s.phase === 'journey' && this.did('boot') && !this.did('shelter'); }

  /**
   * @param {number} dt
   * @param {{seesResin?:boolean, air?:number, spiderThreat?:boolean, inShelter?:boolean, logRead?:boolean,
   *          powerRepaired?:boolean, deepNear?:boolean, beaconRepaired?:boolean, transmitted?:boolean, distance?:number}} c
   * @returns {Array<{type:string, lines?:Array, id?:string}>}
   */
  update(dt, c = {}) {
    const out = [];
    const s = this.s;
    if (s.phase === 'off' || s.phase === 'ended') return out;
    s.t += dt;
    if (s.phase === 'opening') {
      if (s.t > 0.8) this._once('escort1', out, { type: 'say', lines: [ESCORT[0]] });
      if (s.t > 4.5) this._once('escort2', out, { type: 'say', lines: [ESCORT[1]] });
      if (s.t > 6.0) this._once('seal', out, { type: 'seal' });
      if (s.t > 8.0) this._once('boot', out, { type: 'system', lines: RITE_KIT_BOOT.map((l, i) => (i === 3 ? `${l} ~${Math.round((c.distance ?? 35) / 5) * 5} u` : l)) });
      if (s.t > 13) { this._once('rec-start', out, { type: 'say', lines: RECORDINGS.start }); s.phase = 'journey'; }
      return out;
    }
    if (c.seesResin) this._once('rec-resin', out, { type: 'say', lines: RECORDINGS.resin });
    if (c.air !== undefined && c.air < 0.6) this._once('rec-air', out, { type: 'say', lines: RECORDINGS.air });
    if (c.spiderThreat) this._once('rec-spider', out, { type: 'say', lines: RECORDINGS.spider });
    if (c.inShelter) this._once('shelter', out, { type: 'say', lines: RECORDINGS.shelter });
    // ADDENDUM 03 §40 phases 3–5
    if (c.generatorRepaired) this._once('essentials', out, { type: 'system', lines: ['ESSENTIALS ONLINE · AIR · WATER · LIGHT', 'THE SHELTER WILL KEEP THEM RUNNING'] }, { type: 'say', lines: RECORDINGS.generator });
    if (c.placeFound) this._once('place', out);
    if (c.blueprintLearned) this._once('blueprint', out);
    if (c.fabricated) this._once('fabricated', out, { type: 'system', lines: ['FABRICATION COMPLETE'] }, { type: 'say', lines: RECORDINGS.fabricated });
    if (c.logRead) this._once('rec-log', out, { type: 'say', lines: RECORDINGS.log });
    if (c.powerRepaired) this._once('lure', out, { type: 'lure' });
    if (this.did('lure') && c.deepNear) this._once('shift', out, { type: 'shift' });
    if (c.beaconRepaired) this._once('rec-beacon', out, { type: 'say', lines: RECORDINGS.beacon });
    if (c.transmitted && this._once('finale', out, { type: 'finale' })) s.phase = 'ended';
    return out;
  }

  /** Soft goal for the current stage of the first hour (A3 §40) — a purpose, never a route. */
  get goal() {
    if (this.s.phase === 'off' || this.s.phase === 'ended') return null;
    if (!this.did('boot')) return null;
    if (!this.did('shelter')) return 'Follow the shelter signal';
    if (!this.did('essentials')) return 'Restore the starter generator';
    if (!this.did('place')) return 'Follow a local signal (tap the signal plate)';
    if (!this.did('blueprint')) return 'Analyze what you find (hold SCAN) and salvage it';
    if (!this.did('fabricated')) return 'Return to the Fabricator and build what you learned';
    if (!this.did('rec-beacon')) return 'Reach and repair the long-range beacon (north rubble)';
    return 'Power the beacon (auxiliary generator) and transmit';
  }

  toJSON() { return this.s; }
}
