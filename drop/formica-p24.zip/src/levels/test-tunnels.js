// "Test Tunnels" — technical test level for P01–P05 (ADD §77, §79; GDD §65-A).
// Pure data. Units: ant metres (ant ≈ 1.0 long). Chunk grid covers x,z ∈ [-32, 32), y ∈ [-16, 16).
export const TEST_TUNNELS = {
  id: 'test-tunnels',
  seed: 1337,
  blend: 1.0,
  chunks: { min: [-2, -1, -2], max: [1, 0, 1] }, // inclusive chunk index range
  geology: {
    warp: 2.5, soilTop: 7.5, clayTop: 1.5, sandTop: -5, sandLens: 0.18,
    // loose rubble plugging the Shelter's collapsed chamber — diggable with mandibles
    overrides: [{ c: [16, -4.5, -8.6], r: 2.3, material: 2 }],
  },
  spawn: { pos: [-12.5, -1.2, 1.5], yaw: -Math.PI / 2, pitch: -0.1 },

  cavities: [
    // ADD §77: Room A | solid wall (~2.5) | Room B. The wall is dug through in P03.
    { name: 'Room A', type: 'ellipsoid', c: [-12.5, 0, 0], r: [5, 3, 5] },
    { name: 'Room B', type: 'ellipsoid', c: [-0.5, 0, 0], r: [4.5, 3.2, 4.5] },
    // Long way round A → B (south loop)
    { name: 'South Loop', type: 'tube', r: 1.1, points: [[-13, -1.6, -3.5], [-15, -1.4, -12], [-6, -0.8, -19], [4, -1.2, -13], [1, -1.6, -3.5]] },
    // Vertical shaft up from Room B to the upper gallery
    { name: 'Shaft', type: 'capsule', a: [2.2, 1.5, 2], b: [2.2, 12, 2], r: 1.3 },
    { name: 'Upper Gallery', type: 'tube', r: 1.5, points: [[2.2, 12, 2], [10, 12.5, 3], [16, 11.5, 6], [18.5, 9.5, 8.5]] },
    // P14 (ADDENDUM 03 §2, §7): ground routes — switchback ramp Room B → Upper Gallery, gentle descent into the Pit Hall
    { name: 'Gallery Ramp', type: 'tube', r: 1.1, noise: 0.25, points: [[3.2, -2.3, -2.0], [9.5, -0.2, -6.8], [13.5, 2.4, -1.5], [9.5, 5, 3.2], [4.5, 7.6, -1.2], [9.5, 10.2, -5.8], [9.8, 12.3, 2.2]] },
    // flat landings at the ramp corners (easy turning, rest spots)
    ...[[9.5, -0.2, -6.8], [13.5, 2.4, -1.5], [9.5, 5, 3.2], [4.5, 7.6, -1.2], [9.5, 10.2, -5.8]].map((c) => ({ name: 'Gallery Ramp', type: 'ellipsoid', c, r: [1.9, 1.15, 1.9], noise: 0.25 })),
    { name: 'Hall Descent', type: 'tube', r: 1.3, noise: 0.25, points: [[13, 12, 4.5], [21.5, 10.8, 1.8], [27, 9, 2.5], [28.5, 6.5, 7], [24.5, 4.5, 10.5]] },
    // Wide hall with a pit in the floor: crossing it means walking on walls / ceiling
    { name: 'Pit Hall', type: 'ellipsoid', c: [20, 7, 10], r: [6.5, 4, 6.5] },
    { name: 'The Pit', type: 'capsule', a: [20, 5, 10], b: [20, -10, 10], r: 3.2 },
    { name: 'Far Ledge', type: 'ellipsoid', c: [21, 6.5, 18.5], r: [3, 2.2, 3] },
    // Low tunnel from the pit bottom back to Room B (closes the vertical loop)
    { name: 'Pit Floor', type: 'ellipsoid', c: [20, -11.4, 10], r: [3.3, 1.4, 3.3], noise: 0.3 },
    { name: 'Deep Tunnel', type: 'tube', r: 1.15, noise: 0.45, points: [[20, -11.5, 10], [14.5, -9, 4.5], [8, -5, 4.2], [4, -2.6, 1.5], [1.2, -1.9, 0.6]] },
    // Narrow squeeze (Ø 1.2) from Room A to a hidden niche
    { name: 'Squeeze', type: 'tube', r: 0.68, noise: 0.35, points: [[-13, -0.5, 4.2], [-16.5, -0.3, 13], [-8, -0.2, 19]] },
    { name: 'Niche', type: 'ellipsoid', c: [-5.5, 0, 20], r: [2.6, 1.8, 2.6] },
    // P08: Ritual Shelter (ADD §8) — reached from the South Loop. [STORAGE]–[CENTRAL]–[AIR], FABRICATOR south,
    // POWER below it, a collapsed chamber north (the broken Beacon waits behind the rubble).
    { name: 'Shelter Passage', type: 'tube', r: 1.0, points: [[4, -1.3, -13.2], [8, -2.6, -14], [11.5, -3.6, -14]] },
    { name: 'Shelter', type: 'ellipsoid', c: [16, -4, -14], r: [3.6, 2.3, 3.6] },
    { name: 'Storage Room', type: 'ellipsoid', c: [11.5, -4, -14], r: [2.1, 1.7, 2.1] },
    { name: 'Air Room', type: 'ellipsoid', c: [21, -4, -14], r: [2.2, 1.7, 2.2] },
    { name: 'Fabricator Room', type: 'ellipsoid', c: [16, -4, -19], r: [2.2, 1.7, 2.1] },
    { name: 'Power Room', type: 'ellipsoid', c: [16, -9, -21], r: [1.9, 1.4, 1.9], noise: 0.4 },
    { name: 'Power Stairs', type: 'tube', r: 1.0, noise: 0.25, points: [[16, -4.9, -19], [12, -6.4, -18.4], [11.4, -7.8, -21.4], [13.6, -9, -22.8], [15.6, -9.6, -21.4]] },
    { name: 'Collapsed Chamber', type: 'ellipsoid', c: [16, -4.2, -6.0], r: [2.4, 1.7, 2.2] },
    // P15: the old doorway between the shelter and the collapsed chamber (plugged by a rubble gate, see `gates`)
    { name: 'North Door', type: 'tube', r: 1.0, noise: 0.3, points: [[16, -4.8, -11.4], [16, -4.6, -7.4]] },
    // P11: the ritual route the escorts came by — sealed behind the initiate at the start of the rite
    { name: 'Ritual Route', type: 'tube', r: 1.0, points: [[-16.8, -2, 0.5], [-21, -1.6, -0.5], [-26, -1.3, 0.3]] },
    // P19: the Abandoned Equipment Cache — a side chamber off the South Loop
    { name: 'Cache Passage', type: 'tube', r: 1.0, noise: 0.35, points: [[0.5, -1.2, -15.2], [1.6, -1.5, -18.6]] },
    { name: 'Equipment Cache', type: 'ellipsoid', c: [2, -1.3, -20.8], r: [2.4, 1.6, 2.2], noise: 0.4 },
    // P04: sealed cavity north of Room B (wall ~2.5). Home of the test beetle; opened only by digging.
    { name: 'Sealed Chamber', type: 'ellipsoid', c: [0, -0.8, 9.6], r: [3, 2, 2.6] },
  ],

  // P06 atmosphere: the Sealed Chamber holds stale, CO₂-rich air (ADD §78); the shaft top vents to fresh air.
  air: {
    zones: [
      { zone: 'Sealed Chamber', o2: 0.3, co2: 0.65, tox: 0.05 },
      // the shelter's air has gone stale while the processor ran degraded (GDD §63: "repair damaged Air Generator")
      ...['Shelter', 'Storage Room', 'Air Room', 'Fabricator Room', 'Power Room', 'Power Stairs'].map((zone) => ({ zone, o2: 0.85, co2: 0.1, tox: 0 })),
      { zone: 'Collapsed Chamber', o2: 0.5, co2: 0.3, tox: 0.1 },
      { zone: 'Niche', o2: 0.6, co2: 0.35, tox: 0.05 }, // P19: stale air around the unknown signal
    ],
    vents: [{ pos: [2.2, 12.5, 2], radius: 1.6 }],
    // P17 (A3 §24–25): the home is safe — no CO₂ seep; the shelter air is only stale
  },

  // P07 resources (GREYBOX props). Positions are dropped onto the floor below at load time.
  pickups: [
    { id: 'a-resin-1', item: 'resin', pos: [-15.5, -1, 2.5] },
    { id: 'a-resin-2', item: 'resin', pos: [-9.5, -1, -2.5] },
    { id: 'a-fungus', item: 'fungus', n: 2, pos: [-14, -1, -3] },
    { id: 'a-seed', item: 'seed', pos: [-11, -1, 3.2] },
    { id: 'a-scrap', item: 'scrap', pos: [-13.5, -1, 0.5] },
    { id: 'loop-fungus', item: 'fungus', n: 2, pos: [-15, -1, -12] },
    { id: 'loop-resin', item: 'resin', pos: [-6, -0.5, -19] },
    { id: 'loop-chitin', item: 'chitin', pos: [4, -1, -13] },
    { id: 'b-chitin', item: 'chitin', n: 2, pos: [-2.5, -1, -2] },
    { id: 'b-seed', item: 'seed', pos: [1.5, -1, 1] },
    { id: 'gal-seed', item: 'seed', pos: [10, 12.5, 3] },
    { id: 'gal-chitin', item: 'chitin', pos: [14, 12, 5] },
    { id: 'hall-resin-1', item: 'resin', n: 2, pos: [24.5, 6, 11] },
    { id: 'hall-fungus', item: 'fungus', n: 2, pos: [16, 6, 12] },
    { id: 'ledge-scrap', item: 'scrap', n: 2, pos: [21, 6.5, 19] },
    { id: 'deep-fungus', item: 'fungus', pos: [11.2, -6.4, 4.3] },
    { id: 'deep-scrap', item: 'scrap', pos: [15.5, -9, 5.5] },
    { id: 'niche-chitin', item: 'chitin', n: 2, pos: [-5.5, 0.5, 21] },
    { id: 'niche-scrap', item: 'scrap', pos: [-4.5, 0.5, 19.5] },
    { id: 'sealed-fungus', item: 'fungus', n: 3, pos: [1, -1, 9.6] },
    { id: 'sealed-resin', item: 'resin', n: 2, pos: [-1.5, -1, 10] },
  ],
  // Condensate drips: infinite water with a cooldown.
  waterSources: [
    { id: 'drip-b', pos: [-3, -1, 2.5] },
    { id: 'drip-hall', pos: [14.8, 6, 10] },
    { id: 'drip-loop', pos: [-14.5, -1, -8] },
    { id: 'drip-station', pos: [10.4, -6.4, 4.8] }, // P19: the Old Water Station still drips
  ],

  // P18 salvage objects for the Analysis Scanner (ADDENDUM 03 §32–36). kind → src/data/analysis.js
  salvage: [
    { id: 'sal-actuator', kind: 'actuator', pos: [-11, -2, -2] },
    { id: 'sal-pipe-1', kind: 'pipe_segment', pos: [-9, -1.4, -17.4] },
    { id: 'sal-pipe-2', kind: 'pipe_segment', pos: [7, -2.2, -14] },
    { id: 'sal-harness', kind: 'harness_scrap', pos: [11.8, -4.6, -13] },
    { id: 'sal-cell', kind: 'cell_casing', pos: [17.2, -4.6, -20] },
    { id: 'sal-fan', kind: 'fan_housing', pos: [13.5, -4.6, -15.5] },
    { id: 'sal-regulator', kind: 'pressure_regulator', pos: [10.5, 11.8, 3.8] },
    { id: 'sal-camp-frame', kind: 'camp_frame', pos: [20.5, 6.2, 18] },
    { id: 'sal-battery', kind: 'field_battery', pos: [12, -6.6, 4.4] },
    // P19 point-of-interest objects
    { id: 'sal-coil', kind: 'receiver_coil', pos: [2.8, -1.8, -21.6] },
    { id: 'sal-probe', kind: 'survey_probe', pos: [10.2, -6.2, 3.6] },
    // P22 Adhesion Suit components (three POIs) and a ceiling cache only a rig can reach
    { id: 'sal-actuator-rig', kind: 'suit_actuator', pos: [9.4, 11.8, 2.2] },
    { id: 'sal-pads', kind: 'grip_pads', pos: [20.2, 6.2, 19.4] },
    { id: 'sal-control', kind: 'suit_control', pos: [-6.2, -0.4, 19.4] },
    { id: 'sal-ceiling', kind: 'ceiling_cache', pos: [18.5, 9.5, 12.5], ceiling: true },
    { id: 'sal-crate-1', kind: 'cache_crate', pos: [0.9, -1.8, -21] },
    { id: 'sal-crate-2', kind: 'cache_crate', pos: [2.2, -1.8, -19.6] },
    { id: 'sal-foreign', kind: 'foreign_tool', pos: [-5, -0.5, 20.8] },
    { id: 'poi-core', kind: 'ritual_core', pos: [11.2, 11.8, 2.2] },
    { id: 'poi-pack', kind: 'initiate_pack', pos: [21.6, 6.2, 19.2] },
  ],

  // P19 points of interest: discovery radius, dressing (GREYBOX), archive entry
  pois: [
    { id: 'cache', name: 'ABANDONED EQUIPMENT CACHE', center: [2, -1.5, -20.8], r: 3.2, beacon: 'cache',
      dressing: [['crate', [0.4, -1.8, -21.9]], ['crate', [3.4, -1.8, -20]], ['shelf', [2, -1.8, -22.6]]],
      desc: 'Supplies stacked for initiates who never came to collect them. Cycle stamps stop at 402.' },
    { id: 'water-station', name: 'OLD WATER STATION', center: [11.2, -6.6, 4.3], r: 3.2, beacon: 'water-station',
      dressing: [['tank', [12.2, -7, 3.2]], ['pipes', [10.4, -6.5, 5.2]]],
      desc: 'A condensation station that fed the old ritual route. The pump is dead; the drip is not.' },
    { id: 'ritual-beacon', name: 'DAMAGED RITUAL BEACON', center: [10.5, 11.6, 3.2], r: 3, beacon: 'ritual-beacon',
      dressing: [['broken-mast', [9.6, 11.2, 3.8]], ['dead-lamp', [8.4, 11.2, 2.4]], ['dead-lamp', [12.4, 11.2, 3.6]]],
      desc: 'A relay beacon of the ritual network. Roots have cracked its housing.' },
    { id: 'emergency', name: 'EMERGENCY BEACON', center: [21, 6, 18.8], r: 3, beacon: 'emergency',
      dressing: [['bedroll', [20.4, 5.6, 19.8]]], desc: 'Someone pitched a camp on this ledge and switched on the emergency band.' },
    { id: 'unknown', name: 'UNKNOWN SIGNAL', center: [-5.5, 0, 20], r: 3, beacon: 'unknown',
      dressing: [['foreign-mark', [-6.6, -0.6, 21.6]], ['foreign-mark', [-4, -0.4, 21.4]]],
      desc: 'Markings of another colony. Their transmitter is still warm.' },
  ],

  // P16 beacons (ADDENDUM 03 §15–23). range = base detection range (×2.5 once the shelter receiver is powered).
  beacons: [
    { id: 'shelter', name: 'RITUAL SHELTER', type: 'RITUAL', pos: [16, -4.8, -14], power: 1, range: 60, known: true },
    { id: 'unknown', name: 'UNKNOWN SIGNAL', type: 'UNKNOWN', pos: [-5.5, 0, 20], power: 0.6, range: 24, intermittent: true },
    { id: 'ritual-beacon', name: 'DAMAGED RITUAL BEACON', type: 'RITUAL', pos: [10.5, 11.2, 3.2], power: 0.5, range: 15 },
    { id: 'emergency', name: 'EMERGENCY BEACON', type: 'EMERGENCY', pos: [21, 5.6, 19], power: 0.7, range: 16 },
    { id: 'water-station', name: 'OLD WATER STATION', type: 'DEAD', pos: [11.2, -6.6, 4.3], power: 0.35, range: 16 },
    { id: 'cache', name: 'EQUIPMENT CACHE', type: 'EMERGENCY', pos: [2, -1.6, -20.8], power: 0.5, range: 14 },
    // P19: weak anomaly at the bottom of the Pit — only an amplified receiver hears it from the shelter
    { id: 'anomaly', name: 'ANOMALY', type: 'UNKNOWN', pos: [20, -12, 10], power: 0.3, range: 9 },
  ],

  // P15 gates (ADDENDUM 03 §7): visible, understandable blockers inside real passages — dig through or wait for the shift.
  gates: [
    { id: 'north-rubble', label: 'LOOSE RUBBLE', a: [16, -4.7, -10.0], b: [16, -4.7, -8.7], r: 1.25, material: 2, opensTo: 'Collapsed Chamber',
      debris: [16, -5.3, -10.9] },
  ],

  // P11 Root Forest: giant roots through the Upper Gallery and over the Pit — solid, climbable (GDD §9).
  roots: [
    { r: 0.38, points: [[6, 15.6, 1.0], [6.6, 12.5, 1.6], [7.2, 9.5, 2.2]] },
    { r: 0.42, points: [[12, 15.6, 3.3], [11.6, 12.6, 2.4], [12.2, 10, 1.1]] },
    { r: 0.45, points: [[17, 11.4, 12.6], [18.6, 5, 11.8], [19, -2, 11], [19.5, -7, 10.5]] },
    // hanging root tips
    { r: 0.3, points: [[15, 10.8, 12], [14.8, 8.2, 12.4]] },
    { r: 0.28, points: [[-2, 3.6, -1.5], [-1.6, 1.4, -1.2]] },
  ],

  // P11 story: spawn in the Ritual Route, what is sealed, the old partial collapse in the South Loop, inspectables.
  rite: {
    spawn: { pos: [-21.2, -1.6, -0.4], yaw: -Math.PI / 2 },
    seal: [{ c: [-24.2, -1.4, -0.1], r: 1.6 }, { c: [-25.8, -1.3, 0.3], r: 1.5 }],
    loopRubble: [{ c: [-15, -4.6, -12], r: 2.6 }], // P15: a low, walkable mound (A3 §7: damaged, not blocked)
    signal: [16, -5.2, -14],
    // P13: old ritual lamps along the initiates' way to the shelter (ADD §6 "remnants of old ritual infrastructure")
    lampPath: [[-21.2, -1.6, -0.4], [-17, -1.8, 0.3], [-14, -1.5, -1], [-13, -1.6, -3.5], [-15, -1.4, -12], [-6, -0.8, -19],
      [4, -1.2, -13], [8, -2.6, -14], [11.5, -3.6, -14], [14, -4, -14], [16.5, -4.4, -14.5]],
    shift: { carve: [[16, -4.9, -10.5], [16, -4.8, -9.4], [16, -4.7, -8.3]], r: 0.95, rubble: { c: [15.2, -5.8, -11.8], r: 0.7 }, lure: [16, -9, -14] },
    inspectables: [
      { id: 'sign', pos: [-13.6, -2.3, -3.2], title: 'OLD RITUAL MARK', text: 'A pheromone glyph cut into the wall, hundreds of cycles old: RETURN ↑ WEST. The way west is the way you came — and it is rubble now.' },
      { id: 'foil', pos: [-10.5, -2.4, 2.6], title: 'SILVER HILL', text: 'Aluminium foil, crumpled into a hill of silver. Human debris. It still smells faintly of sugar.' },
      { id: 'canister', pos: [-15.2, -1.4, -9.4], title: 'EMPTY CANISTER', text: 'An emergency air canister of formic make. The valve is open. Whoever carried it needed air badly.' },
      { id: 'mark', pos: [-6, -0.8, -18.6], title: 'FOREIGN MARKING', text: 'A faint pheromone marking, cycles old. Your NAV-CARAPACE cannot decode the dialect. Not from home.' },
      { id: 'comb', pos: [3, -1.2, -12.2], title: 'CARVED COMB', text: 'A small chitin comb. A name is scratched on it: TAVI, 391. Initiates were never meant to lose their things.' },
      { id: 'hair', pos: [1.6, -2.3, -2.2], title: 'MAMMAL HAIR', text: 'A single hair, thick as a root. Something enormous once walked the world above.' },
      { id: 'names', pos: [14.6, -4.3, -10.9], title: 'NAMES ON THE WALL', text: 'Names scratched into the shelter wall, each with a cycle: ORU 377 · MENNA 383 · TAVI 391 · KESS 396 · ILAN 402. Nobody after 402.' },
    ],
  },

  // P08: Ritual Shelter modules (ADD §8 initial states). Positions are dropped onto the floor at load time.
  shelter: {
    zone: 'Shelter',
    zones: ['Shelter', 'Storage Room', 'Air Room', 'Fabricator Room', 'Power Room', 'Power Stairs', 'Shelter Passage', 'Collapsed Chamber'],
    respawn: [16, -5.2, -14],
    // P17: starting food reserves in the shelter storage (A3 §25)
    stash: { fungus: 4, food_ration: 2 },
    modules: [
      { id: 'storage', type: 'storage', pos: [11.3, -4, -14.8], state: 'working' },
      { id: 'lights', type: 'lighting', pos: [16, -2, -14], state: 'working' },
      { id: 'condenser', type: 'condenser', pos: [13.6, -4, -12.2], state: 'working' },
      { id: 'terminal', type: 'terminal', pos: [17.6, -4, -12.4], state: 'working' },
      { id: 'generator', type: 'generator', pos: [18.6, -4.6, -16.2], state: 'degraded' },
      { id: 'power', type: 'power', pos: [16.4, -9, -20.8], state: 'damaged', fuel: 0 },
      { id: 'air', type: 'air', pos: [21.4, -4, -14], state: 'degraded' },
      { id: 'fabricator', type: 'fabricator', pos: [17.6, -4, -18.4], state: 'damaged' },
      { id: 'beacon', type: 'beacon', pos: [16.4, -4.2, -5.6], state: 'broken' },
    ],
  },

  // P04 creatures (GREYBOX)
  creatures: [
    { kind: 'beetle', pos: [0, -1.5, 9.6] },
    // P10: territorial spider on the Pit Hall rim (the course passes it — avoidable)
    { kind: 'spider', pos: [23.5, 5, 13] },
  ],
  // P10: foreign scout — leaves the Niche after ~90 s and patrols the hubs until it smells the ant
  scout: { home: [-5.5, -0.5, 20], delay: 90, respawn: 300,
    patrol: [[-12.5, -2, 0], [-6, -0.8, -19], [-0.5, -2, 0], [4, -1.2, -13], [12, -3, -14], [-13, -0.5, 4.2]] },
  // P10: something huge, far below (never above y = −6)
  deep: { loop: [[18, -13, 6], [8, -14, -4], [-6, -13.5, -10], [-14, -13, 4], [2, -14, 14]] },

  // P02 traversal course (ROADMAP 2.6). Gates must sit in empty space (checked by tests).
  course: {
    id: 'test-tunnels-traverse',
    gates: [
      { name: 'South Loop', pos: [-6, -0.8, -19], r: 2 },
      { name: 'Room B', pos: [-0.5, -1, 0], r: 2.2 },
      { name: 'Upper Gallery', pos: [10, 12.5, 3], r: 2 },
      { name: 'Far Ledge', pos: [21, 6.5, 18.5], r: 2 },
      { name: 'Deep Tunnel', pos: [11.2, -6.6, 4.3], r: 2 },
      { name: 'Niche', pos: [-5.5, 0, 20], r: 2 },
    ],
  },

  // Landmarks. Every light has a physical source (AB §10). Props are GREYBOX until PIPE §43 assets exist.
  lights: [
    { kind: 'ritual-lamp', pos: [-15.5, -2.4, -1.5], color: 0xe0a64a, intensity: 5, distance: 11 },
    { kind: 'fungus', pos: [1.5, -2.6, -2.5], color: 0x5fd0b0, intensity: 5, distance: 9 },
    { kind: 'fungus', pos: [21, 4.6, 19], color: 0x5fd0b0, intensity: 6, distance: 10 },
    { kind: 'fungus', pos: [-5.2, -1.4, 21], color: 0x7fd07a, intensity: 4, distance: 7 },
  ],
};
