import { TEST_TUNNELS } from './test-tunnels.js';
export const LEVELS = { [TEST_TUNNELS.id]: TEST_TUNNELS };
