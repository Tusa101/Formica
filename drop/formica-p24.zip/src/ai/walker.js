// Shared locomotion for surface creatures: the player's AntMotor + NavGrid planning + waypoint following. Pure JS.
import { AntMotor } from '../player/ant-motor.js';
import * as V from '../core/vec3.js';

export const WALKER_PARAMS = {
  adhesion: true, // creatures still crawl walls and ceilings
  hover: 0.24, walkSpeed: 1.5, runMultiplier: 1, jumpSpeed: 0, detachTime: 0.18, snapRange: 0.55, upRate: 12, climbRate: 8,
  airUprightRate: 2.5, gravity: 9, airControl: 0, maxAirSpeed: 9, hardLanding: 99, pitchLimit: 1, projectIterations: 3,
  gradientStep: 0.2, minGradient: 0.35,
};

export class Walker {
  constructor(field, topology, pos, seed = 7, params = {}) {
    this.topo = topology;
    this.motor = new AntMotor(field, { ...WALKER_PARAMS, ...params });
    this.motor.place(pos, 0);
    this.home = pos.slice();
    this.path = null; this.wi = 0; this.goal = null; this.goalName = null;
    this.best = Infinity; this.sinceProgress = 0;
    let s = seed >>> 0; this.rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
    this.state = 'idle';
    this.speedMul = 1;
  }

  get pos() { return this.motor.pos; }
  distTo(p) { return Math.hypot(p[0] - this.pos[0], p[1] - this.pos[1], p[2] - this.pos[2]); }

  /** Plans a path to a world point. Returns true if reachable. */
  goTo(p, name = null, state = 'walk') {
    const pts = this.topo.pathPoints(this.motor.pos, p);
    if (!pts) { this.path = null; return false; }
    this.path = pts; this.wi = 0; this.goal = p.slice(); this.goalName = name;
    this.best = Infinity; this.sinceProgress = 0; this.state = state;
    return true;
  }

  /** Waypoints without planning (e.g. a scent trail that is already a walkable line). */
  follow(points, state) { this.path = points; this.wi = 0; this.best = Infinity; this.sinceProgress = 0; this.state = state; }

  /** Turns toward a point on the current surface and walks one fixed step. */
  steerTo(p, dt, speed = 1) {
    const m = this.motor;
    const d3 = V.sub([0, 0, 0], p, m.pos);
    const dist = V.len(d3);
    if (dist > 1e-3) {
      V.scale(d3, d3, 1 / dist);
      const along = V.dot(d3, m.up);
      const proj = [d3[0] - m.up[0] * along, d3[1] - m.up[1] * along, d3[2] - m.up[2] * along];
      if (V.len(proj) > 0.15) {
        V.normalize(proj, proj);
        const c = V.cross([0, 0, 0], m.heading, proj);
        const ang = Math.acos(Math.max(-1, Math.min(1, V.dot(m.heading, proj))));
        m.look((V.dot(c, m.up) >= 0 ? -1 : 1) * Math.min(ang, 0.09 * Math.max(1, speed)), 0);
      }
    }
    m.step(dt, { moveX: 0, moveY: Math.min(1, speed), yaw: 0, pitch: 0, jump: false, fast: speed > 1 });
    return dist;
  }

  /** Advances along `path`. @returns {'walking'|'arrived'|'none'} */
  followPath(dt, speed = 1) {
    if (!this.path) { this.motor.step(dt, null); return 'none'; }
    const wp = this.path[this.wi];
    const dist = this.distTo(wp);
    const reach = this.wi === this.path.length - 1 ? 1.0 : 1.3;
    if (dist < reach) {
      this.wi++; this.best = Infinity; this.sinceProgress = 0;
      this.motor.step(dt, null);
      if (this.wi >= this.path.length) { this.path = null; return 'arrived'; }
      return 'walking';
    }
    if (dist < this.best - 0.05) { this.best = dist; this.sinceProgress = 0; } else this.sinceProgress += dt;
    if (this.sinceProgress > 4) {
      if (this.wi < this.path.length - 1) { this.wi++; this.best = Infinity; this.sinceProgress = 0; } else { this.path = null; return 'arrived'; }
    }
    this.steerTo(wp, dt, speed);
    return 'walking';
  }

  /** A random reachable region node in this walker's cavity, between minD and maxD away. */
  randomNode(minD = 4, maxD = 30) {
    const g = this.topo.graph, nav = this.topo.nav;
    const here = nav.nearestOpen(this.pos, 4);
    if (here < 0) return null;
    const lab = nav.label[here];
    const cands = g.nodes.filter((n) => n.label === lab && n.cells > 6);
    for (let t = 0; t < 10 && cands.length; t++) {
      const n = cands[Math.floor(this.rnd() * cands.length)];
      const d = this.distTo(n.pos);
      if (d > minD && d < maxD) return n.pos;
    }
    return null;
  }

  /** Reachable node farthest from `from` within `range` of the walker. */
  awayFrom(from, range = 18) {
    const g = this.topo.graph, nav = this.topo.nav;
    const here = nav.nearestOpen(this.pos, 4);
    if (here < 0) return null;
    const lab = nav.label[here];
    const cur = Math.hypot(...this.pos.map((v, i) => v - from[i]));
    const c = g.nodes.filter((n) => n.label === lab && n.cells > 6 && this.distTo(n.pos) < range)
      .map((n) => ({ p: n.pos, away: Math.hypot(...n.pos.map((v, i) => v - from[i])) }))
      .filter((x) => x.away > cur + 2).sort((a, b) => b.away - a.away);
    return c.length ? c[Math.floor(this.rnd() * Math.min(3, c.length))].p : null;
  }
}
