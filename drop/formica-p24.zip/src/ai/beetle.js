// Passive fauna (GDD §37; ADD §2): wanders its cavity, investigates new openings, flees vibration and a close ant.
import { Walker } from './walker.js';

export class Beetle extends Walker {
  constructor(field, topology, pos, seed = 7) {
    super(field, topology, pos, seed, { hover: 0.24, walkSpeed: 1.5 });
    this.kind = 'beetle';
    this.idle = 1;
    this.seenVersion = topology.version;
    this.interest = null;
    this.fleeing = 0;
  }

  /** Topology event: new space worth a look (explore the zone on the far side of the opening). */
  notice(ev) {
    if (ev.type !== 'connected' && ev.type !== 'passage') return;
    const zp = (n) => this.topo.zones.find((z) => z.name === n)?.p;
    const a = zp(ev.a), b = zp(ev.b);
    const far = !a ? b : !b ? a : this.distTo(a) > this.distTo(b) ? a : b;
    this.interest = (far || ev.at).slice();
  }

  flee(from) {
    const p = this.awayFrom(from);
    if (p && this.goTo(p, 'flee')) { this.fleeing = 4; return true; }
    return false;
  }

  /** Vibration stimulus. */
  feel(ev) { if (ev && ev.received >= 0.25 && this.fleeing <= 0) this.flee(ev.pos); }

  /** Proximity stimulus (the ant is close and visible). */
  see(p) { if (p && this.fleeing <= 0 && this.distTo(p) < 2.5) this.flee(p); }

  step(dt) {
    if (this.fleeing > 0) this.fleeing -= dt;
    if (this.topo.version !== this.seenVersion) {
      this.seenVersion = this.topo.version;
      if (this.interest && this.goTo(this.interest, 'opening')) this.interest = null;
      else if (this.path && this.goal) this.goTo(this.goal, this.goalName);
    }
    if (this.state !== 'walk' || !this.path) {
      this.state = 'idle';
      this.idle -= dt;
      if (this.idle <= 0) { this.idle = 1 + this.rnd() * 2; const n = this.randomNode(); if (n) this.goTo(n); }
      this.motor.step(dt, null);
      return;
    }
    if (this.followPath(dt, this.fleeing > 0 ? 1 : 0.8) === 'arrived') { this.state = 'idle'; this.idle = 1.5 + this.rnd() * 2; }
  }
}
