// Foreign-colony scout (GDD §20–21, §23, §73): patrols, picks up the ant's scent, follows the trail from old to new
// crumbs, and — if it finds the ant — goes home to report. It knows only what it smells and sees.
import { Walker } from './walker.js';
import { canSee, crumbIndex } from './perception.js';

export const SCOUT = Object.freeze({ speed: 1.9, smell: 0.02, lookAhead: 60, shortcut: 2.2, searchTime: 15, see: 3 });

export class Scout extends Walker {
  constructor(field, topology, home, patrol, seed = 13) {
    super(field, topology, home, seed, { hover: 0.26, walkSpeed: SCOUT.speed });
    this.kind = 'scout';
    this.field = field;
    this.patrol = patrol; this.pi = 0;
    this.state = 'patrol';
    this.trackT = 0;
    this.searchT = 0;
    this.sniffT = 0;
    this.reported = false;
    this.events = [];
    this.stuckT = 0; this.lastD = Infinity;
    this.deadT = -Infinity;
  }

  _sniff(air) {
    const crumbs = air.crumbs.get('player') || [];
    if (air.scentAt('player', this.pos) <= SCOUT.smell || !crumbs.length) return false;
    // lock onto the freshest smellable crumb close to where we stand
    let best = -1;
    for (let i = crumbs.length - 1; i >= 0 && i >= crumbs.length - 1500; i--) {
      if (crumbs[i].t <= this.deadT) break; // a trail end we already lost
      if (this.distTo(crumbs[i].p) < 2.5 && air.scentAt('player', crumbs[i].p) > SCOUT.smell) { best = i; break; }
    }
    if (best < 0) return false;
    this.trackT = crumbs[best].t;
    this.state = 'track'; this.path = null; this.stuckT = 0; this.lastD = Infinity;
    this.events.push({ type: 'trail' });
    return true;
  }

  /** @param {{air, player:number[]|null}} s  player: position if it is the ant (used only through canSee) */
  step(dt, { air, player }) {
    if (this.state === 'gone') return;
    if (player && this.state !== 'report' && canSee(this.field, this.pos, player, SCOUT.see)) {
      this.state = 'report'; this.reported = true;
      this.events.push({ type: 'found' });
      this.goTo(this.home, 'home', 'report');
    }
    switch (this.state) {
      case 'patrol': {
        this.sniffT -= dt;
        if (this.sniffT <= 0) { this.sniffT = 0.3; if (this._sniff(air)) break; }
        if (!this.path) { const p = this.patrol[this.pi++ % this.patrol.length]; if (!this.goTo(p, 'patrol', 'patrol')) this.pi++; }
        this.followPath(dt, 0.8);
        break;
      }
      case 'track': this._track(dt, air); break;
      case 'search': {
        this.searchT -= dt;
        this.sniffT -= dt;
        if (this.sniffT <= 0) { this.sniffT = 0.3; if (this._sniff(air)) break; }
        if (this.searchT <= 0) { this.goTo(this.home, 'home', 'return'); break; }
        if (!this.path) { const n = this.randomNode(2, 8); if (n) this.goTo(n, null, 'search'); }
        this.followPath(dt, 0.9);
        break;
      }
      case 'return': case 'report':
        if (this.followPath(dt, 1) !== 'walking') { this.state = 'gone'; this.events.push({ type: this.reported ? 'reported' : 'gave-up' }); }
        break;
      default: this.motor.step(dt, null);
    }
  }

  _lose() { this.deadT = this.trackT; this.state = 'search'; this.searchT = SCOUT.searchTime; this.path = null; this.events.push({ type: 'lost' }); }

  _track(dt, air) {
    const crumbs = air.crumbs.get('player') || [];
    let i = crumbIndex(crumbs, this.trackT);
    if (i >= crumbs.length) { this._lose(); return; }
    // shortcut loops: jump to the newest nearby crumb that still smells
    for (let j = Math.min(crumbs.length - 1, i + SCOUT.lookAhead); j > i; j--) {
      if (this.distTo(crumbs[j].p) < SCOUT.shortcut && air.scentAt('player', crumbs[j].p) > SCOUT.smell) { i = j; this.trackT = crumbs[j].t; break; }
    }
    const target = crumbs[i].p;
    const d = this.distTo(target);
    if (d < 0.9) {
      const next = crumbs[i + 1];
      if (!next) { this._lose(); return; }                       // end of the trail: the ant is somewhere near
      if (air.scentAt('player', next.p) <= SCOUT.smell) { this._lose(); return; } // trail faded or masked
      this.trackT = next.t; this.stuckT = 0; this.lastD = Infinity;
      this.motor.step(dt, null);
      return;
    }
    if (d < this.lastD - 0.02) { this.lastD = d; this.stuckT = 0; } else this.stuckT += dt;
    if (this.stuckT > 4) { // the trail crosses something we cannot follow directly — plan around once
      this.stuckT = 0; this.lastD = Infinity;
      if (!this.goTo(target, 'trail', 'track')) { this._lose(); return; }
    }
    if (this.path) { if (this.followPath(dt, 1) !== 'walking') this.path = null; } else this.steerTo(target, dt, 1);
  }
}
