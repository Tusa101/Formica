// Territorial creature (ADD §2: the first one can be avoided; GDD §36: combat is not mandatory).
import { Walker } from './walker.js';

export const SPIDER = Object.freeze({ territory: 7, chaseLimit: 10, threatTime: 2.5, close: 4, speed: 3.0, bite: 12, hp: 3, scaredFor: 60 });

export class Spider extends Walker {
  constructor(field, topology, lair, seed = 21) {
    super(field, topology, lair, seed, { hover: 0.3, walkSpeed: SPIDER.speed });
    this.kind = 'spider';
    this.lair = this.pos.slice();
    this.state = 'rest';
    this.hp = SPIDER.hp;
    this.threatT = 0; this.drumT = 0; this.replanT = 0; this.cool = 0; this.scared = 0;
    this.events = [];
  }

  hurt() {
    if (this.state === 'flee') return;
    this.hp--;
    this.events.push({ type: 'hurt' });
    if (this.hp <= 0) { this.state = 'flee'; this.scared = SPIDER.scaredFor; const p = this.awayFrom(this.pos, 20); if (p) this.goTo(p, null, 'flee'); this.events.push({ type: 'scared' }); }
    else { this.state = 'retreat'; this.cool = 1.5; this.goTo(this.lair, 'lair', 'retreat'); }
  }

  /** @param {{player:number[]|null}} s  player = perceived position (in territory and sensed), else null */
  step(dt, { player }) {
    const fromLair = (p) => Math.hypot(p[0] - this.lair[0], p[1] - this.lair[1], p[2] - this.lair[2]);
    if (this.cool > 0) this.cool -= dt;
    this.drum = false;
    switch (this.state) {
      case 'rest':
        if (player && fromLair(player) < SPIDER.territory) { this.state = 'threat'; this.threatT = 0; this.events.push({ type: 'threat' }); }
        else if (this.distTo(this.lair) > 1.5 && !this.path) this.goTo(this.lair, 'lair', 'rest');
        if (this.path) this.followPath(dt, 0.4); else this.motor.step(dt, null);
        break;
      case 'threat': {
        if (!player || fromLair(player) > SPIDER.territory + 1) { this.state = 'rest'; break; }
        this.steerTo(player, dt, 0.001); // turn to face, barely move
        this.drumT -= dt;
        if (this.drumT <= 0) { this.drumT = 0.6; this.drum = true; }
        if (this.distTo(player) < SPIDER.close) this.threatT += dt; else this.threatT = Math.max(0, this.threatT - dt * 0.5);
        if (this.threatT > SPIDER.threatTime) { this.state = 'charge'; this.replanT = 0; this.events.push({ type: 'charge' }); }
        break;
      }
      case 'charge':
        if (!player || fromLair(this.pos) > SPIDER.chaseLimit) { this.state = 'retreat'; this.goTo(this.lair, 'lair', 'retreat'); break; }
        if (this.distTo(player) < 1.1 && this.cool <= 0) {
          this.events.push({ type: 'hit', damage: SPIDER.bite, from: this.pos.slice() });
          this.cool = 1.5; this.state = 'retreat'; this.goTo(this.lair, 'lair', 'retreat');
          break;
        }
        this.replanT -= dt;
        if (this.distTo(player) < 2.5) { this.path = null; this.steerTo(player, dt, 1); }
        else { if (this.replanT <= 0 || !this.path) { this.replanT = 0.5; this.goTo(player, 'prey', 'charge'); } this.followPath(dt, 1); }
        break;
      case 'retreat':
        if (this.followPath(dt, 0.7) !== 'walking') { this.state = 'rest'; this.threatT = 0; }
        break;
      case 'flee':
        this.scared -= dt;
        if (this.path) this.followPath(dt, 1); else this.motor.step(dt, null);
        if (this.scared <= 0) { this.hp = SPIDER.hp; this.state = 'retreat'; this.goTo(this.lair, 'lair', 'retreat'); }
        break;
      default: this.motor.step(dt, null);
    }
  }
}
