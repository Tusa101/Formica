// Stimuli available to creatures (GDD §72.9; §68.11 — no magic knowledge). Pure JS.

/** Line of sight through open space, within `range` (the underground is dark: sight is short). */
export function canSee(field, from, to, range = 3) {
  const d = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]);
  if (d > range) return false;
  const n = Math.max(1, Math.ceil(d / 0.3));
  for (let i = 1; i < n; i++) {
    const k = i / n;
    if (field.densityAt(from[0] + (to[0] - from[0]) * k, from[1] + (to[1] - from[1]) * k, from[2] + (to[2] - from[2]) * k) > 0) return false;
  }
  return true;
}

/** Index of the first crumb with time ≥ t (crumbs are time-ordered). */
export function crumbIndex(crumbs, t) {
  let lo = 0, hi = crumbs.length;
  while (lo < hi) { const m = (lo + hi) >> 1; if (crumbs[m].t < t) lo = m + 1; else hi = m; }
  return lo;
}
