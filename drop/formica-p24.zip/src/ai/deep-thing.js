// "Something huge" (GDD §68.8, §73; foreshadows the mole, GDD §34 Stage I): moves through rock far below, felt as a
// deep periodic vibration. Loud activity draws it closer — but it never rises above `ceiling`. Pure JS.
export const DEEP = Object.freeze({ speed: 0.35, hunt: 0.7, pulse: 1.6, strength: 5, hear: 25, loud: 1, ceiling: -6, forget: 12 });

export class DeepThing {
  constructor(loop) {
    this.loop = loop; this.li = 0;
    this.pos = loop[0].slice();
    this.target = null; this.forgetT = 0; this.pulseT = 0;
    this.kind = 'deep';
  }

  /** @param {Array<{pos:number[], strength:number}>} loud  vibration events heard this step */
  step(dt, loud = []) {
    for (const e of loud) {
      if (e.strength < DEEP.loud) continue;
      if (Math.hypot(e.pos[0] - this.pos[0], e.pos[1] - this.pos[1], e.pos[2] - this.pos[2]) > DEEP.hear) continue;
      this.target = [e.pos[0], Math.min(e.pos[1] - 2.5, DEEP.ceiling), e.pos[2]];
      this.forgetT = DEEP.forget;
    }
    let goal = this.target;
    if (goal) { this.forgetT -= dt; if (this.forgetT <= 0) this.target = null; }
    if (!goal) goal = this.loop[this.li];
    const d = [goal[0] - this.pos[0], goal[1] - this.pos[1], goal[2] - this.pos[2]];
    const len = Math.hypot(...d);
    const sp = (this.target ? DEEP.hunt : DEEP.speed) * dt;
    if (len < 0.5) { if (!this.target) this.li = (this.li + 1) % this.loop.length; }
    else for (let a = 0; a < 3; a++) this.pos[a] += (d[a] / len) * Math.min(sp, len);
    this.pos[1] = Math.min(this.pos[1], DEEP.ceiling);
    this.pulseT -= dt;
    if (this.pulseT <= 0) { this.pulseT = DEEP.pulse; return { pos: this.pos.slice(), strength: DEEP.strength }; }
    return null;
  }
}
