// Pure camera-basis math for the three accessibility modes (GDD §10). Tested in Node.
import * as V from '../core/vec3.js';

const WORLD_UP = [0, 1, 0];

/** Target camera up for a mode, given the ant's body up. */
export function modeUp(out, bodyUp, mode, reducedBlend) {
  if (mode === 'horizon') return V.copy(out, WORLD_UP);
  if (mode === 'reduced') {
    out[0] = WORLD_UP[0] + (bodyUp[0] - WORLD_UP[0]) * reducedBlend;
    out[1] = WORLD_UP[1] + (bodyUp[1] - WORLD_UP[1]) * reducedBlend;
    out[2] = WORLD_UP[2] + (bodyUp[2] - WORLD_UP[2]) * reducedBlend;
    return V.normalize(out, out, WORLD_UP);
  }
  return V.copy(out, bodyUp);
}

/** View direction: heading pitched around the body's right axis. */
export function viewDirection(out, heading, bodyUp, pitch) {
  const c = Math.cos(pitch), s = Math.sin(pitch);
  out[0] = heading[0] * c + bodyUp[0] * s;
  out[1] = heading[1] * c + bodyUp[1] * s;
  out[2] = heading[2] * c + bodyUp[2] * s;
  return V.normalize(out, out, heading);
}

/**
 * Orthonormal camera basis (right, up, back=−view) from view dir and desired up.
 * `prevRight` keeps the basis stable when view ∥ up.
 */
export function cameraBasis(view, desiredUp, prevRight) {
  const back = V.scale([0, 0, 0], view, -1);
  let right = V.cross([0, 0, 0], desiredUp, back);
  if (V.len(right) < 1e-3) right = V.projectOnPlane([0, 0, 0], prevRight, back, [1, 0, 0]);
  else V.normalize(right, right);
  const up = V.cross([0, 0, 0], back, right);
  V.normalize(up, up);
  return { right, up, back };
}
