// Free-flying debug camera (kept as a debug tool after P02 introduces the ant controller).
import * as THREE from 'three';
import { CONFIG } from '../config.js';

export class NoclipController {
  constructor(camera, input, { pos, yaw = 0, pitch = 0 }) {
    this.camera = camera; this.input = input;
    this.pos = new THREE.Vector3(...pos);
    this.yaw = yaw; this.pitch = pitch;
    this._fwd = new THREE.Vector3(); this._right = new THREE.Vector3();
    this._apply();
  }

  fixedUpdate(dt) {
    const i = this.input, n = CONFIG.noclip;
    const speed = n.speed * (i.isDown('fast') ? n.fastMultiplier : 1);
    const cp = Math.cos(this.pitch);
    this._fwd.set(-Math.sin(this.yaw) * cp, Math.sin(this.pitch), -Math.cos(this.yaw) * cp);
    this._right.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    this.pos.addScaledVector(this._fwd, i.move.y * speed * dt);
    this.pos.addScaledVector(this._right, i.move.x * speed * dt);
    const up = (i.isDown('up') || i.isDown('jump') ? 1 : 0) - (i.isDown('down') || i.isDown('dig') ? 1 : 0);
    this.pos.y += up * n.verticalSpeed * dt;
  }

  update() {
    const l = this.input.consumeLook();
    this.yaw -= l.dx;
    this.pitch = THREE.MathUtils.clamp(this.pitch - l.dy, -CONFIG.noclip.pitchLimit, CONFIG.noclip.pitchLimit);
    this._apply();
  }

  _apply() {
    this.camera.position.copy(this.pos);
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
  }
}
