// Ant locomotion on an arbitrary density field (GDD §10). Pure JS — no Three.js — tested in Node.
// The ant hovers `hover` units above the nearest surface; floors, walls and ceilings are handled
// by the same projection, so dug tunnels (P03) work without extra code.
import * as V from '../core/vec3.js';

const WORLD_UP = [0, 1, 0];
const _fb = [0, 0, 0];
/** A unit vector perpendicular to `n` (used when a heading degenerates). */
function perp(n) {
  const a = Math.abs(n[0]) < 0.9 ? [1, 0, 0] : [0, 0, 1];
  return V.projectOnPlane(_fb, a, n, [0, 0, 1]);
}

export class AntMotor {
  /**
   * @param {{densityAt(x,y,z):number, gradientAt(x,y,z,h,out):number[]}} field
   * @param {object} p  CONFIG.ant
   */
  constructor(field, p) {
    this.field = field; this.p = p;
    this.pos = V.v3(); this.up = V.v3(0, 1, 0); this.heading = V.v3(0, 0, -1);
    this.vel = V.v3(); this.pitch = 0;
    this.mode = 'air';
    this.detachTimer = 0;
    this.surfaceDist = Infinity;
    this.speed = 0;
    this.airTime = 0;
    this.events = [];
    // scratch
    this._g = V.v3(); this._n = V.v3(); this._t = V.v3(); this._r = V.v3(); this._m = V.v3(); this._prev = V.v3(); this._pu = V.v3();
  }

  /** Signed distance to the surface (positive in empty space) and unit normal toward empty space. */
  probe(p, nOut) {
    const f = this.field;
    const d = f.densityAt(p[0], p[1], p[2]);
    const g = f.gradientAt(p[0], p[1], p[2], this.p.gradientStep, this._g);
    const gl = V.len(g);
    if (gl < 1e-6) { V.set(nOut, 0, 1, 0); return -d; }
    V.scale(nOut, g, -1 / gl);
    return -d / Math.max(gl, this.p.minGradient);
  }

  /** Places the ant on the surface below `pos`, facing `yaw` (radians, 0 = −Z). */
  place(pos, yaw = 0) {
    V.copy(this.pos, pos);
    V.set(this.heading, -Math.sin(yaw), 0, -Math.cos(yaw));
    V.set(this.up, 0, 1, 0);
    V.set(this.vel, 0, 0, 0);
    this.mode = 'air';
    this.detachTimer = 0;
    for (let i = 0; i < 400 && this.mode === 'air'; i++) this.step(1 / 60, null); // settle
    this.events.length = 0;
  }

  /** Applies look input immediately (rotation is not simulated). */
  look(dyaw, dpitch) {
    if (dyaw) V.rotateAxis(this.heading, this.heading, this.up, -dyaw);
    this.pitch = Math.max(-this.p.pitchLimit, Math.min(this.p.pitchLimit, this.pitch - dpitch));
  }

  /**
   * @param {number} dt
   * @param {{moveX:number, moveY:number, yaw:number, pitch:number, jump:boolean, fast:boolean, digging?:boolean}|null} input
   */
  step(dt, input) {
    const p = this.p;
    const inp = input || { moveX: 0, moveY: 0, yaw: 0, pitch: 0, jump: false, fast: false };
    if (inp.yaw) V.rotateAxis(this.heading, this.heading, this.up, -inp.yaw);
    this.pitch = Math.max(-p.pitchLimit, Math.min(p.pitchLimit, this.pitch - (inp.pitch || 0)));
    V.copy(this._prev, this.pos);
    if (this.mode === 'surface') { if (this.p.adhesion === false) this._groundStep(dt, inp); else this._surfaceStep(dt, inp); } else this._airStep(dt, inp);
    this.speed = V.len(V.sub(this._t, this.pos, this._prev)) / dt;
  }

  _moveDir(out, inp) {
    V.cross(this._r, this.heading, this.up); // right
    V.scale(out, this.heading, inp.moveY);
    return V.addScaled(out, out, this._r, inp.moveX);
  }

  _surfaceStep(dt, inp) {
    const p = this.p, n = this._n;
    const spd = p.walkSpeed * (inp.fast ? p.runMultiplier : 1);
    const m = this._moveDir(this._m, inp);

    if (inp.jump) {
      V.scale(this.vel, this.up, p.jumpSpeed);
      V.addScaled(this.vel, this.vel, m, spd);
      V.addScaled(this.pos, this.pos, this.up, 0.02);
      this.mode = 'air'; this.detachTimer = p.detachTime; this.airTime = 0;
      this.events.push({ type: 'jump' });
      return;
    }

    V.addScaled(this.pos, this.pos, m, spd * dt);

    let dist = 0;
    for (let i = 0; i < p.projectIterations; i++) {
      dist = this.probe(this.pos, n);
      if (dist > p.hover + p.snapRange) { // surface vanished → fall
        this.mode = 'air'; this.detachTimer = 0; this.airTime = 0;
        V.scale(this.vel, m, spd);
        this.events.push({ type: 'detach' });
        this.surfaceDist = dist;
        return;
      }
      V.addScaled(this.pos, this.pos, n, p.hover - dist);
      if (Math.abs(dist - p.hover) < 0.004) break;
    }
    this.surfaceDist = this.probe(this.pos, n);

    V.copy(this._pu, this.up);
    const k = 1 - Math.exp(-p.upRate * dt);
    V.nlerp(this.up, this.up, n, k, n);
    // Wall ahead (e.g. the apex of a sharp crease or the end of a dug pocket): turn up toward the obstacle
    // so the ant climbs it instead of pushing into it forever.
    const ml = V.len(m);
    if (ml > 0.1 && !inp.digging) {
      const ahead = this._t;
      V.addScaled(ahead, this.pos, m, (p.hover * 1.1) / ml);
      const na = this._g2 || (this._g2 = V.v3());
      const dA = this.probe(ahead, na);
      if (dA < p.hover * 0.6 && V.dot(na, m) < -0.5 * ml) {
        V.nlerp(this.up, this.up, na, 1 - Math.exp(-p.climbRate * dt), na);
      }
    }
    // Degenerate case (walked straight into a wall): the old up becomes the new heading — the ant starts climbing.
    V.projectOnPlane(this.heading, this.heading, this.up, V.dot(this._pu, this.up) < 0.999 ? this._pu : perp(this.up));
    V.scale(this.vel, V.sub(this._t, this.pos, this._prev), 1 / dt);
  }

  /**
   * ADDENDUM 03 §2 ground-first locomotion: walk floors and slopes up to `minUp`; steeper faces are obstacles
   * (slide along them), convex edges are ledges (step down or fall). Never climbs walls or ceilings.
   */
  _groundStep(dt, inp) {
    const p = this.p, n = this._n, minUp = p.minUp ?? 0.643;
    const spd = p.walkSpeed * (inp.fast ? p.runMultiplier : 1);
    const m = this._moveDir(this._m, inp);
    const mh = this._mh || (this._mh = V.v3());
    const ml = V.len(m);
    V.set(mh, m[0], 0, m[2]);
    const hl = V.len(mh);
    if (hl > 1e-6) V.scale(mh, mh, ml / hl);
    if (inp.jump) {
      V.set(this.vel, mh[0] * spd, p.jumpSpeed * 0.8, mh[2] * spd);
      V.addScaled(this.pos, this.pos, WORLD_UP, 0.02);
      this.mode = 'air'; this.detachTimer = p.detachTime; this.airTime = 0;
      this.events.push({ type: 'jump' });
      return;
    }
    const prev = this._prev;
    const np = this._np || (this._np = V.v3());
    this.probe(prev, np);
    // standing on a too-steep patch (e.g. the curved side of a tube): gravity pulls the ant down it
    if (np[1] < minUp) {
      const dh = Math.hypot(np[0], np[2]) || 1;
      mh[0] += (np[0] / dh) * 0.6; mh[2] += (np[2] / dh) * 0.6;
    }
    const tryMove = (dir) => {
      V.addScaled(this.pos, prev, dir, spd * dt);
      let dist = 0;
      for (let i = 0; i < p.projectIterations; i++) {
        dist = this.probe(this.pos, n);
        if (dist > p.hover + p.snapRange) return 'fall';
        V.addScaled(this.pos, this.pos, n, p.hover - dist);
        if (Math.abs(dist - p.hover) < 0.004) break;
      }
      this.surfaceDist = this.probe(this.pos, n);
      if (n[1] >= minUp) return 'ok';
      // not getting steeper and not climbing: allowed (walking along / down a steep patch)
      if (n[1] >= np[1] - 0.005 && this.pos[1] <= prev[1] + 0.01) return 'ok';
      // the surface faces the way we walk → a convex edge (ledge); otherwise a wall in front of us
      const facing = n[0] * dir[0] + n[2] * dir[2];
      return facing > 0 || this.pos[1] < prev[1] - 0.04 ? 'ledge' : 'wall';
    };
    let res = tryMove(mh);
    if (res === 'wall') {
      // slide along the obstacle: drop the component of motion that goes into it
      // slide along the contour of the obstacle (horizontal, perpendicular to its normal) with a little downhill bias
      const nh = [n[0], 0, n[2]]; const nl = Math.hypot(nh[0], nh[2]) || 1; nh[0] /= nl; nh[2] /= nl;
      const c = [-nh[2], 0, nh[0]];
      const along = V.dot(c, mh);
      const slide = [c[0] * along + nh[0] * 0.35 * ml, 0, c[2] * along + nh[2] * 0.35 * ml];
      res = V.len(slide) > 0.05 ? tryMove(slide) : 'wall';
      if (res !== 'ok') res = tryMove([nh[0] * 0.6 * ml, 0, nh[2] * 0.6 * ml]); // back off downhill, away from the face
      if (res !== 'ok') { res = tryMove([0, 0, 0]); if (res !== 'ok') { V.copy(this.pos, prev); res = 'stuck'; } }
    }
    if (res === 'ledge' || res === 'fall') {
      V.addScaled(this.pos, prev, mh, spd * dt);
      this.mode = 'air'; this.detachTimer = 0; this.airTime = 0;
      V.scale(this.vel, mh, spd);
      this.events.push({ type: 'detach' });
      return;
    }
    // body leans with the floor a little (never more than ~25°); the camera keeps world up anyway
    V.copy(this._pu, this.up);
    const target = n[1] >= 0.906 ? n : V.nlerp(this._t, WORLD_UP, n, 0.45, WORLD_UP);
    V.nlerp(this.up, this.up, target, 1 - Math.exp(-p.upRate * dt), WORLD_UP);
    V.projectOnPlane(this.heading, this.heading, this.up, V.dot(this._pu, this.up) < 0.999 ? this._pu : perp(this.up));
    V.scale(this.vel, V.sub(this._t, this.pos, prev), 1 / dt);
  }

  _airStep(dt, inp) {
    const p = this.p, n = this._n;
    this.airTime += dt;
    this.vel[1] -= p.gravity * dt;
    // weak air control in the horizontal plane
    const m = this._moveDir(this._m, inp);
    m[1] = 0;
    V.addScaled(this.vel, this.vel, m, p.airControl * dt);
    const sp = V.len(this.vel);
    if (sp > p.maxAirSpeed) V.scale(this.vel, this.vel, p.maxAirSpeed / sp);
    V.addScaled(this.pos, this.pos, this.vel, dt);

    // body slowly rights itself toward world up while falling
    V.nlerp(this.up, this.up, WORLD_UP, 1 - Math.exp(-p.airUprightRate * dt), WORLD_UP);
    V.projectOnPlane(this.heading, this.heading, this.up, perp(this.up));

    this.detachTimer -= dt;
    const dist = this.probe(this.pos, n);
    this.surfaceDist = dist;
    if (this.detachTimer <= 0 && dist < p.hover && p.adhesion === false && n[1] < (p.minUp ?? 0.643)) {
      // too steep to stand on: push out and slide down it
      V.addScaled(this.pos, this.pos, n, p.hover - dist);
      const into = V.dot(this.vel, n);
      if (into < 0) V.addScaled(this.vel, this.vel, n, -into);
    } else if (this.detachTimer <= 0 && dist < p.hover) {
      V.addScaled(this.pos, this.pos, n, p.hover - dist);
      const impact = -V.dot(this.vel, n);
      V.nlerp(this.up, this.up, n, 0.5, n);
      V.projectOnPlane(this.heading, this.heading, this.up, perp(this.up));
      this.mode = 'surface';
      this.events.push({ type: 'land', impact, hard: impact > p.hardLanding });
      V.set(this.vel, 0, 0, 0);
    }
  }
}
