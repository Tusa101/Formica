// Glue: input → AntMotor (fixed step) → camera (per frame, smoothed, 3 accessibility modes).
import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { AntMotor } from './ant-motor.js';
import { modeUp, viewDirection, cameraBasis } from './camera-math.js';
import { AntBody } from './ant-body.js';

const STORAGE_KEY = 'formica.cameraMode';

export class AntController {
  constructor(camera, input, field) {
    this.camera = camera; this.input = input;
    this.motor = new AntMotor(field, { ...CONFIG.ant }); // mutable copy: the Adhesion Suit toggles adhesion (P22)
    this.suitOwned = false;
    this.body = new AntBody(camera);
    let saved = null;
    try { saved = localStorage.getItem(STORAGE_KEY); } catch { /* private mode */ }
    this.cameraMode = CONFIG.camera.modes.includes(saved) ? saved : 'horizon'; // STABILIZED by default (A3 §5)
    this.jumpLatch = false;
    this.digging = false;
    this.kickT = 0;
    this.camPos = new THREE.Vector3();
    this.camUp = [0, 1, 0];
    this.prevRight = [1, 0, 0];
    this.bobT = 0;
    this._m = new THREE.Matrix4();
    this._x = new THREE.Vector3(); this._y = new THREE.Vector3(); this._z = new THREE.Vector3();
    this.onEvent = null;
  }

  place(pos, yaw) {
    this.motor.place(pos, yaw);
    this._snapCamera();
  }

  /** Ground locomotion always keeps the world horizon (ADDENDUM 03 §2); modes matter only with adhesion. */
  get effectiveCameraMode() { return this.motor.p.adhesion === false ? 'horizon' : this.cameraMode; }

  cycleCameraMode() {
    if (!this.suitOwned) return 'horizon';
    const m = CONFIG.camera.modes;
    this.cameraMode = m[(m.indexOf(this.cameraMode) + 1) % m.length];
    try { localStorage.setItem(STORAGE_KEY, this.cameraMode); } catch { /* ignore */ }
    return this.cameraMode;
  }

  preUpdate() { if (this.input.wasPressed('jump')) this.jumpLatch = true; }

  fixedUpdate(dt) {
    const i = this.input;
    this.motor.step(dt, { moveX: i.move.x, moveY: i.move.y, yaw: 0, pitch: 0, jump: this.jumpLatch, fast: i.isDown('fast'), digging: this.digging });
    this.jumpLatch = false;
    if (this.motor.events.length) {
      for (const e of this.motor.events) this.onEvent?.(e);
      this.motor.events.length = 0;
    }
  }

  update(dt) {
    const l = this.input.consumeLook();
    this.motor.look(l.dx, l.dy);
    const m = this.motor, C = CONFIG.camera;

    // eye position with gentle bob while walking on a surface
    const walking = m.mode === 'surface' ? Math.min(m.speed / CONFIG.ant.walkSpeed, 1.5) : 0;
    this.bobT += dt * C.bobFrequency * walking;
    const bob = Math.sin(this.bobT) * C.bobAmplitude * walking;
    const target = new THREE.Vector3(...m.pos).addScaledVector(new THREE.Vector3(...m.up), C.eyeOffset + bob);
    this.camPos.lerp(target, 1 - Math.exp(-C.posSmoothing * dt));
    this.kickT *= Math.exp(-18 * dt);

    // camera up by accessibility mode, smoothed
    const want = modeUp([0, 0, 0], m.up, this.effectiveCameraMode, C.reducedBlend);
    const k = 1 - Math.exp(-C.upSmoothing * dt);
    const u = this.camUp;
    for (let a = 0; a < 3; a++) u[a] += (want[a] - u[a]) * k;
    const ul = Math.hypot(...u) || 1; u[0] /= ul; u[1] /= ul; u[2] /= ul;

    this._applyOrientation();
    this.body.update(dt, m.speed, this.input.isDown('dig'));
  }

  _applyOrientation() {
    const m = this.motor;
    const view = viewDirection([0, 0, 0], m.heading, m.up, m.pitch);
    const b = cameraBasis(view, this.camUp, this.prevRight);
    this.prevRight = b.right;
    this._m.makeBasis(this._x.set(...b.right), this._y.set(...b.up), this._z.set(...b.back));
    this.camera.quaternion.setFromRotationMatrix(this._m);
    this.camera.position.copy(this.camPos);
    if (this.kickT > 0.001) this.camera.position.addScaledVector(this._z, CONFIG.dig.kick * this.kickT);
  }

  /** Eye position and view direction (pure arrays) for aiming tools. */
  aim() {
    const m = this.motor, e = CONFIG.camera.eyeOffset;
    return { eye: [m.pos[0] + m.up[0] * e, m.pos[1] + m.up[1] * e, m.pos[2] + m.up[2] * e], dir: viewDirection([0, 0, 0], m.heading, m.up, m.pitch) };
  }

  bite() { this.kickT = 1; this.body.chomp(); }

  _snapCamera() {
    const m = this.motor;
    this.camPos.set(...m.pos).addScaledVector(new THREE.Vector3(...m.up), CONFIG.camera.eyeOffset);
    this.camUp = modeUp([0, 0, 0], m.up, this.effectiveCameraMode, CONFIG.camera.reducedBlend);
    this._applyOrientation();
  }

  /** Yaw of the current view projected on the horizontal plane (for handing over to noclip). */
  viewYaw() { const h = this.motor.heading; return Math.atan2(-h[0], -h[2]); }
}
