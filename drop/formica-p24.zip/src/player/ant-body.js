// GREYBOX first-person ant body: mandibles rise into the bottom of the view, antennae reach into the top.
// Every part starts BEHIND the camera and only its outer part enters the frustum, so no cut ends are ever visible.
// Replaced by the evolved-ant model from the Blender pipeline (PIPE §43, AB §26).
import * as THREE from 'three';
import { MANDIBLE, ANTENNA } from './body-shape.js';

/** Tube along a curve that tapers from rBase to rTip (TubeGeometry rings are rescaled around the curve). */
function taperedStrand(points, rBase, rTip, mat, segments = 24) {
  const curve = new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(...p)), false, 'centripetal');
  const radial = 8;
  const geo = new THREE.TubeGeometry(curve, segments, 1, radial, false);
  const pos = geo.attributes.position, c = new THREE.Vector3(), v = new THREE.Vector3();
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    curve.getPointAt(t, c);
    const r = rBase + (rTip - rBase) * Math.pow(t, 0.8);
    for (let j = 0; j <= radial; j++) {
      const k = i * (radial + 1) + j;
      v.fromBufferAttribute(pos, k).sub(c).multiplyScalar(r).add(c);
      pos.setXYZ(k, v.x, v.y, v.z);
    }
  }
  geo.computeVertexNormals();
  return new THREE.Mesh(geo, mat);
}


export class AntBody {
  constructor(camera) {
    // a touch of emissive keeps the dark chitin readable outside the lamp cone (AB §11 chitin = controlled semi-gloss)
    const chitin = new THREE.MeshStandardMaterial({ color: 0x3a2a1d, roughness: 0.42, metalness: 0.08, emissive: 0x140d08 });
    this.group = new THREE.Group();
    this.group.name = 'ant-body (GREYBOX)';
    const side = (pts, s) => pts.map(([x, y, z]) => [x * s, y, z]);
    this.mandibles = [-1, 1].map((s) => {
      const pivot = new THREE.Group();
      const base = MANDIBLE[0];
      pivot.position.set(base[0] * s, base[1], base[2]);
      const local = side(MANDIBLE, s).map(([x, y, z]) => [x - base[0] * s, y - base[1], z - base[2]]);
      pivot.add(taperedStrand(local, 0.022, 0.004, chitin));
      this.group.add(pivot);
      return pivot;
    });
    this.antennae = [-1, 1].map((s) => {
      const pivot = new THREE.Group();
      const base = ANTENNA[0];
      pivot.position.set(base[0] * s, base[1], base[2]);
      const local = side(ANTENNA, s).map(([x, y, z]) => [x - base[0] * s, y - base[1], z - base[2]]);
      pivot.add(taperedStrand(local, 0.008, 0.0025, chitin));
      this.group.add(pivot);
      return pivot;
    });
    camera.add(this.group);
    this.t = 0;
    this.open = 0;
  }

  setVisible(v) { this.group.visible = v; }
  chomp() { this.open = -0.15; }

  update(dt, speed, digHeld) {
    this.t += dt * (1 + speed * 3);
    this.open += ((digHeld ? 1 : 0) - this.open) * Math.min(1, dt * 12);
    const sway = Math.sin(this.t * 2.2) * 0.03;
    // mandibles open outward around their (off-screen) base
    this.mandibles.forEach((m, i) => { const s = i ? 1 : -1; m.rotation.y = s * (this.open * 0.28) + sway * 0.3; });
    this.antennae.forEach((a, i) => { a.rotation.x = Math.sin(this.t * 1.7 + i) * 0.06; a.rotation.y = Math.sin(this.t * 1.1 + i * 2) * 0.05; });
  }
}
