// First-person body geometry in camera space (x right, y up, −z forward). Pure data so it can be tested.
// Bases sit behind the camera / outside the frustum; only the outer part of each strand enters the view.
export const MANDIBLE = [[0.15, -0.16, 0.04], [0.12, -0.12, -0.08], [0.07, -0.085, -0.17], [0.022, -0.07, -0.215]];
export const ANTENNA = [[0.05, 0.12, 0.05], [0.09, 0.15, -0.1], [0.16, 0.16, -0.3], [0.24, 0.13, -0.5]];
