// Base modules (GDD §16–17, ADD §8). draw/supply in power units; repair = materials to reach 'working'.
export const MODULE_TYPES = Object.freeze({
  storage:    { name: 'STORAGE', draw: 0, desc: 'Sealed chitin lockers. Items left here are safe.' },
  // ADDENDUM 03 §26: essential loads 0.45 + 0.25 + 0.10 + 0.10 + 0.20 = 1.10 against a 1.20 starter generator
  lighting:   { name: 'EMERGENCY LIGHTING', draw: 0.1, desc: 'Resin-glass lamps.' },
  condenser:  { name: 'WATER CONDENSER', draw: 0.25, desc: 'Pulls water from the damp air.' },
  terminal:   { name: 'MAINTENANCE TERMINAL', draw: 0.1, desc: 'Shelter log and controls.' },
  generator:  { name: 'STARTER GENERATOR', infinite: true, supply: { working: 1.2, degraded: 0.6 },
    desc: 'Old, slow, dependable. Needs no fuel — it only ever covers the basics.', repair: { degraded: { resin: 2 } } },
  power:      { name: 'AUXILIARY GENERATOR', supply: { working: 1.5, degraded: 0.8 },
    desc: 'Burns chemical cells — only for load above the starter generator.', repair: { damaged: { resin: 2, scrap: 1 }, degraded: { resin: 1, scrap: 1 } } },
  air:        { name: 'AIR PROCESSOR', draw: 0.45, airRadius: { working: 4.5, degraded: 1.6 }, desc: 'Scrubs CO₂, releases oxygen.',
    repair: { degraded: { resin: 2, chitin: 1, scrap: 1 } } },
  fabricator: { name: 'FABRICATOR', draw: 0.2, desc: 'Builds infrastructure from field materials.',
    repair: { damaged: { resin: 3, scrap: 2, chitin: 1 } } },
  beacon:     { name: 'LONG RANGE BEACON', draw: 0.8, desc: 'Ritual beacon. Silent for years.',
    repair: { broken: { scrap: 4, chitin: 2, resin: 2 } } },
  pipe:       { name: 'AIR PIPE', draw: 0, link: 6, airRadius: { working: 1.8 }, desc: 'Carries processed air.' },
  booster:    { name: 'AIR BOOSTER', draw: 0.5, link: 12, airRadius: { working: 2.8 }, desc: 'Pushes air down long pipe runs.' },
  camp:       { name: 'FORWARD CAMP', draw: 0, airRadius: { working: 2.6 }, battery: 100, drain: 100 / 600, desc: 'Minimal camp: air bubble, light, a place to wake up.' },
});

export const STATE_LABEL = Object.freeze({ working: 'WORKING', degraded: 'DEGRADED', damaged: 'DAMAGED', broken: 'BROKEN', offline: 'NO POWER' });
