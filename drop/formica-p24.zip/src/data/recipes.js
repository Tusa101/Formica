// Field crafting (no Fabricator needed). Advanced recipes arrive with the Fabricator in P08.
export const RECIPES = Object.freeze([
  { id: 'resin_patch', out: 'resin_patch', n: 1, needs: { resin: 1 } },
  { id: 'resin_support', out: 'resin_support', n: 1, needs: { resin: 2, chitin: 1 } },
  { id: 'spiracle_filter', out: 'spiracle_filter', n: 1, needs: { fungus: 1, chitin: 1 } },
  { id: 'food_ration', out: 'food_ration', n: 1, needs: { fungus: 2, seed: 1 } },
  { id: 'chemical_cell', out: 'chemical_cell', n: 1, needs: { scrap: 2, fungus: 1 } },
  { id: 'air_capsule', out: 'air_capsule', n: 1, needs: { resin: 1, scrap: 1 } },
  { id: 'resin_lamp', out: 'resin_lamp', n: 2, needs: { resin: 1, fungus: 1 } },
  { id: 'player_beacon', out: 'player_beacon', n: 1, needs: { resin: 1, scrap: 1 } },
  { id: 'scent_mask', out: 'scent_mask', n: 1, needs: { fungus: 1, resin: 1 } },
  // Fabricator only — each needs its blueprint (P18, ADDENDUM 03 §30–36); built from salvaged components
  { id: 'air_pipe', out: 'air_pipe', n: 2, needs: { resin: 1, formic_metal: 1 }, station: 'fabricator', blueprint: true },
  { id: 'air_booster', out: 'air_booster', n: 1, needs: { formic_metal: 2, membrane: 1, resin: 1 }, station: 'fabricator', blueprint: true },
  { id: 'camp_kit', out: 'camp_kit', n: 1, needs: { resin_composite: 1, formic_metal: 1, resin: 2, chemical_cell: 1 }, station: 'fabricator', blueprint: true },
  { id: 'cargo_harness', out: 'cargo_harness', n: 1, needs: { chitin: 2, membrane: 1 }, station: 'fabricator', blueprint: true },
  { id: 'scanner_lens', out: 'scanner_lens', n: 1, needs: { filter_medium: 1, membrane: 1, formic_metal: 1 }, station: 'fabricator', blueprint: true },
  { id: 'adhesion_suit', out: 'adhesion_suit', n: 1, needs: { formic_metal: 2, membrane: 2, resin_composite: 1, chemical_cell: 1 }, station: 'fabricator', blueprint: true },
  { id: 'receiver_amp', out: 'receiver_amp', n: 1, needs: { formic_metal: 1, membrane: 1, filter_medium: 1 }, station: 'fabricator', blueprint: true },
  { id: 'cell_fab', out: 'chemical_cell', n: 2, needs: { formic_metal: 1, filter_medium: 1, fungus: 1 }, station: 'fabricator', blueprint: true },
]);
