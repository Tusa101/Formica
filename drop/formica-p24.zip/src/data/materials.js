// Canonical geology (AB §6, GDD §11). Index = material id = slot in the terrain vec4 weights.
// Gameplay values are placeholders until P03 (digging) and P05 (stability) tune them.
export const MATERIALS = Object.freeze([
  { id: 0, key: 'soil',      name: 'Soil',      color: 0x5e4533, color2: 0x3f2d21, roughness: 0.96, hardness: 0.2, stability: 0.45, strata: 0.0, debris: 0x4a3526, vibration: 0.93 },
  { id: 1, key: 'clay',      name: 'Clay',      color: 0x7c5541, color2: 0x5a3c2d, roughness: 0.82, hardness: 0.5, stability: 0.7,  strata: 0.35, debris: 0x6a4533, vibration: 0.96 },
  { id: 2, key: 'sand',      name: 'Sand',      color: 0x9a8662, color2: 0x74634a, roughness: 0.99, hardness: 0.1, stability: 0.2,  strata: 0.1, debris: 0x8f7c5a, vibration: 0.88 },
  { id: 3, key: 'limestone', name: 'Limestone', color: 0xa39d8e, color2: 0x7d776a, roughness: 0.74, hardness: 0.8, stability: 0.9,  strata: 0.6, debris: 0x8e897c, vibration: 0.985 },
  // P11 Root Forest: giant roots are solid, climbable and (PROTO) not diggable — their visual tube would not follow edits.
  { id: 4, key: 'root', name: 'Root', color: 0x4a3a2a, color2: 0x33271c, roughness: 0.9, hardness: 1.0, stability: 1.0, strata: 0, debris: 0x3a2a1e, vibration: 0.97 },
]);
// vibration = fraction of a vibration that survives each unit of travel through the material (ADD §69)
export const AIR_VIBRATION = 0.6;
export const MAT = Object.freeze({ SOIL: 0, CLAY: 1, SAND: 2, LIMESTONE: 3, ROOT: 4 });
