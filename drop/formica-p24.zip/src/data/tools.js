// Excavation tools (GDD §11 tool chain; ADD §52 scale niches). Energy/heat/wear arrive with P07 / Milestone 5.
// The bite radius is fixed per tool so dug tunnels are always ant-sized; harder ground only makes bites slower.
export const TOOLS = Object.freeze([
  { id: 'mandibles', name: 'MANDIBLES', reach: 1.5, radius: 0.72, interval: 1 / 4, maxHardness: 0.55, power: 1.0 },
  { id: 'vibropick', name: 'VIBRO PICK', reach: 1.7, radius: 0.85, interval: 1 / 5, maxHardness: 0.85, power: 1.5 },
]);

/** Seconds between bites in a material of given hardness: soft ground is fast, clay slower, rock slowest. */
export function biteInterval(tool, hardness) {
  return tool.interval * (0.6 + hardness * 1.6) / tool.power;
}
