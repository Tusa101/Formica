// Survival tuning (GDD §13, §69: no hunger micromanagement). Rates per second unless noted.
export const SURVIVAL = Object.freeze({
  energyDecay: 100 / (95 * 60),    // idle metabolism: ~95 min from full to empty
  runCost: 0.05,                   // extra per second of running
  biteCost: { mandibles: 0.25, vibropick: 0.05 }, // body energy per bite
  toolChargePerBite: 1.5,          // Vibro Pick charge per bite
  hydrationDecay: 100 / (65 * 60), // ~65 min
  breathBadAir: 0.5,               // air quality below this drains breath
  breathDrain: 12,                 // per second at AQ = 0
  breathRefill: 25,
  filterBonus: 0.3,                // filter adds this to effective air quality
  suffocateDamage: 6,
  starveDamage: 0.4,               // at 0 energy or 0 hydration
  regen: 0.3,                      // health regen when fed and watered (> 40)
  hardLandingDamage: 8,
  carryLimit: 20,
  waterSourceCooldown: 20,         // s
  waterSourceAmount: 30,
});
