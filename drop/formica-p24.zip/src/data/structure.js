// Structural stability tuning (ADD §55–60). Values are prototype placeholders tuned by the A–D scenario tests.
export const STRUCTURE = Object.freeze({
  spanBase: 3.0,          // unsupported span limit = spanBase + spanPerStrength × material.stability (units)
  spanPerStrength: 9.0,
  maxRay: 20,             // units scanned sideways for the span
  thinLayer: 2.5,         // rock thinner than this with a cavity above is a "thin layer"
  thinWeight: 0.75,
  stressed: 0.6,          // S ≥ stressed → visible stress, never collapses by itself
  failure: 1.0,           // S ≥ failure → failure timer runs
  failTime: 14,           // seconds to collapse at S = 1 (faster when S is higher: t = failTime / S²)
  recover: 0.5,           // timer recovery rate when S drops below failure (fraction of failTime per second)
  fatiguePerSecond: 0.15, // walking on a roof cell (×2 when running)
  fatigueMax: 0.8,
  fatigueDecay: 0.003,
  damagePerBite: 0.04,    // excavation damage to roof cells near a bite
  damageMax: 0.3,
  damageDecay: 0.01,
  supportRadius: 3.0,
  supportRelief: 0.85,
  evalPerFrame: 200,
  evalRadius: 28,
});
