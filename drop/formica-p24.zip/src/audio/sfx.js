// Minimal procedural sound for structural warnings (ADD §56: audible stress). Full audio pass is P12.
export class Sfx {
  constructor() { this.ctx = null; this.noise = null; this.master = null; this.volume = 0.8; }

  setVolume(v) { this.volume = v; if (this.master) this.master.gain.value = v; }

  unlock() {
    if (this.ctx) { this.ctx.resume?.(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    const len = this.ctx.sampleRate * 2;
    this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noise.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.master = this.ctx.createGain(); this.master.gain.value = this.volume; this.master.connect(this.ctx.destination);
    this._ambient();
  }

  /** Cave bed (GDD §59): very low filtered noise with a slow breathing swell — silence that is not empty. */
  _ambient() {
    const c = this.ctx;
    const src = c.createBufferSource(); src.buffer = this.noise; src.loop = true;
    const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 120; f.Q.value = 0.4;
    const g = c.createGain(); g.gain.value = 0.05;
    const lfo = c.createOscillator(); lfo.frequency.value = 0.07;
    const lg = c.createGain(); lg.gain.value = 0.025;
    lfo.connect(lg).connect(g.gain);
    src.connect(f).connect(g).connect(this.master);
    src.start(); lfo.start();
  }

  _burst({ dur, freq, q = 1, gain, type = 'lowpass', attack = 0.005, rate = 1 }) {
    const c = this.ctx; if (!c || c.state !== 'running') return;
    const src = c.createBufferSource(); src.buffer = this.noise; src.playbackRate.value = rate;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain(); const t = c.currentTime;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(gain, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t, Math.random()); src.stop(t + dur + 0.05);
  }

  /** Footstep; hardness 0..1 of the material underfoot. */
  step(hardness = 0.4, run = false) { this._burst({ dur: 0.05, freq: 700 + hardness * 2200, q: 1.5, gain: (run ? 0.05 : 0.03), type: 'bandpass', rate: 1.4 }); }
  /** Spider drumming — low thumps. */
  drum(dist) { const v = Math.max(0, 1 - dist / 16); if (v > 0.02) this._burst({ dur: 0.18, freq: 90, q: 1, gain: v * 0.6, attack: 0.004, rate: 0.4 }); }
  /** Distant light footsteps (scout). */
  tick(dist) { const v = Math.max(0, 1 - dist / 12); if (v > 0.02) this._burst({ dur: 0.03, freq: 2600, q: 3, gain: v * 0.08, type: 'bandpass', rate: 1.6 }); }
  click() { this._burst({ dur: 0.03, freq: 3000, q: 4, gain: 0.05, type: 'bandpass' }); }

  /** Short dry crack of stressed rock; `level` 0..1, `dist` in units. */
  creak(level, dist) {
    const v = Math.max(0, 1 - dist / 14) * (0.25 + level * 0.5);
    if (v > 0.02) this._burst({ dur: 0.12 + Math.random() * 0.2, freq: 900 + Math.random() * 1600, q: 6, gain: v * 0.5, type: 'bandpass', rate: 0.6 });
  }

  /** Collapse: low rumble + debris rattle. */
  rumble(dist) {
    const v = Math.max(0.15, 1 - dist / 30);
    this._burst({ dur: 2.2, freq: 140, q: 0.7, gain: v * 0.9, attack: 0.08, rate: 0.5 });
    this._burst({ dur: 1.2, freq: 1800, q: 1.5, gain: v * 0.25, type: 'bandpass', attack: 0.2 });
  }

  bite(materialHardness) { this._burst({ dur: 0.07, freq: 500 + materialHardness * 1500, q: 2, gain: 0.12, type: 'bandpass', rate: 1.2 }); }
}
