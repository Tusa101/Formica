// Player vitals (GDD §13). Pure JS; the scene feeds it air quality, effort and events.
import { SURVIVAL as S } from '../data/survival.js';
import { ITEMS } from '../data/items.js';

const clamp = (v) => Math.max(0, Math.min(100, v));

export class Survival {
  constructor(state = {}) {
    this.health = state.health ?? 100;
    this.energy = state.energy ?? 100;
    this.hydration = state.hydration ?? 100;
    this.breath = state.breath ?? 100;
    this.toolCharge = state.toolCharge ?? 0;
    this.filter = state.filter ?? 0;       // seconds of spiracle filter left
    this.airBuffer = state.airBuffer ?? 0; // seconds of capsule air left
    this.scentMask = state.scentMask ?? 0; // seconds of no scent trail
    this.dead = false;
    this.cause = null;
  }

  /** Effective air quality after equipment. */
  effectiveAir(aq) { return this.airBuffer > 0 ? 1 : Math.min(1, aq + (this.filter > 0 ? S.filterBonus : 0)); }

  /**
   * @param {number} dt
   * @param {{air:number, running:boolean}} ctx
   */
  update(dt, { air = 1, running = false } = {}) {
    if (this.dead) return;
    this.energy = clamp(this.energy - dt * (S.energyDecay + (running ? S.runCost : 0)));
    this.hydration = clamp(this.hydration - dt * S.hydrationDecay);
    if (air < 0.6 && this.filter > 0) this.filter = Math.max(0, this.filter - dt);
    if (this.airBuffer > 0) this.airBuffer = Math.max(0, this.airBuffer - dt);
    if (this.scentMask > 0) this.scentMask = Math.max(0, this.scentMask - dt);
    const aq = this.effectiveAir(air);
    if (aq < S.breathBadAir) this.breath = clamp(this.breath - dt * S.breathDrain * (1 - aq / S.breathBadAir));
    else this.breath = clamp(this.breath + dt * S.breathRefill);
    if (this.breath <= 0) this._hurt(S.suffocateDamage * dt, 'suffocation');
    if (this.energy <= 0) this._hurt(S.starveDamage * dt, 'exhaustion');
    if (this.hydration <= 0) this._hurt(S.starveDamage * dt, 'dehydration');
    if (this.energy > 40 && this.hydration > 40 && this.breath > 50) this.health = clamp(this.health + S.regen * dt);
  }

  _hurt(v, cause) {
    this.health = clamp(this.health - v);
    if (this.health <= 0 && !this.dead) { this.dead = true; this.cause = cause; }
  }
  damage(v, cause) { this._hurt(v, cause); }

  /** Effort of one excavation bite with a tool. Returns false if the tool cannot bite (no charge). */
  bite(toolId) {
    if (toolId === 'vibropick') {
      if (this.toolCharge < S.toolChargePerBite) return false;
      this.toolCharge -= S.toolChargePerBite;
    }
    this.energy = clamp(this.energy - (S.biteCost[toolId] ?? 0.2));
    return true;
  }
  canBite(toolId) { return toolId !== 'vibropick' || this.toolCharge >= S.toolChargePerBite; }

  /** Applies an item's effect (item must be removed from the inventory by the caller). */
  use(itemId) {
    const u = ITEMS[itemId]?.use;
    if (!u) return false;
    if (u.energy) this.energy = clamp(this.energy + u.energy);
    if (u.hydration) this.hydration = clamp(this.hydration + u.hydration);
    if (u.health) this.health = clamp(this.health + u.health);
    if (u.breath) this.breath = clamp(this.breath + u.breath);
    if (u.airBuffer) this.airBuffer = Math.max(this.airBuffer, u.airBuffer);
    if (u.filter) this.filter = Math.max(this.filter, u.filter);
    if (u.scentMask) this.scentMask = Math.max(this.scentMask, u.scentMask);
    if (u.toolCharge) this.toolCharge = Math.min(100, this.toolCharge + u.toolCharge);
    return true;
  }

  drink(amount) { this.hydration = clamp(this.hydration + amount); }

  respawn() {
    this.health = 50; this.energy = Math.max(this.energy, 50); this.hydration = Math.max(this.hydration, 50);
    this.breath = 100; this.airBuffer = 0; this.dead = false; this.cause = null;
  }

  toJSON() {
    const { health, energy, hydration, breath, toolCharge, filter, airBuffer, scentMask } = this;
    return { health, energy, hydration, breath, toolCharge, filter, airBuffer, scentMask };
  }
}
