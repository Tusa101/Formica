// Resin Support placement (GDD §12, ADD §57): a column from the aimed surface straight across the cavity to the
// opposite surface. Pure JS.
export const SUPPORT_MIN = 0.8, SUPPORT_MAX = 6;

/** @returns {{a:number[], b:number[], length:number}|null} */
export function planSupport(field, aim) {
  if (!aim || !aim.hit) return null;
  const n = aim.normal, h = aim.hit;
  // columns are vertical-ish: use the surface normal but never more than ~35° off world vertical
  let dir = [n[0], n[1], n[2]];
  if (Math.abs(dir[1]) < 0.8) return null; // aimed at a wall — supports go floor ↔ ceiling
  dir = [dir[0] * 0.3, Math.sign(dir[1]), dir[2] * 0.3];
  const l = Math.hypot(...dir); dir = dir.map((v) => v / l);
  const step = 0.1;
  for (let t = 0.2; t <= SUPPORT_MAX; t += step) {
    const p = [h[0] + dir[0] * t, h[1] + dir[1] * t, h[2] + dir[2] * t];
    if (field.densityAt(p[0], p[1], p[2]) > 0) {
      if (t < SUPPORT_MIN) return null;
      const a = dir[1] > 0 ? h.slice() : p, b = dir[1] > 0 ? p : h.slice();
      return { a, b, length: t }; // a = bottom, b = top
    }
  }
  return null;
}
