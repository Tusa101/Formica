// Weight-limited stack inventory (GDD §15). Pure JS.
import { ITEMS } from '../data/items.js';
import { SURVIVAL } from '../data/survival.js';

export class Inventory {
  constructor(limit = SURVIVAL.carryLimit) { this.items = new Map(); this.limit = limit; }
  count(id) { return this.items.get(id) || 0; }
  get weight() { let w = 0; for (const [id, n] of this.items) w += (ITEMS[id]?.weight ?? 1) * n; return Math.round(w * 100) / 100; }
  canAdd(id, n = 1) { return this.weight + (ITEMS[id]?.weight ?? 1) * n <= this.limit + 1e-9; }
  add(id, n = 1) {
    if (!ITEMS[id]) throw new Error('unknown item ' + id);
    if (!this.canAdd(id, n)) return false;
    this.items.set(id, this.count(id) + n);
    return true;
  }
  remove(id, n = 1) {
    if (this.count(id) < n) return false;
    const left = this.count(id) - n;
    if (left) this.items.set(id, left); else this.items.delete(id);
    return true;
  }
  has(needs) { return Object.entries(needs).every(([id, n]) => this.count(id) >= n); }
  list() { return [...this.items.entries()].map(([id, n]) => ({ id, n, ...ITEMS[id] })); }
  toJSON() { return Object.fromEntries(this.items); }
  static from(obj, limit) { const inv = new Inventory(limit); for (const [id, n] of Object.entries(obj || {})) if (ITEMS[id] && n > 0) inv.items.set(id, n); return inv; }
}
