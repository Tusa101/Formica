// Signal Receiver (ADDENDUM 03 §11, §15–23): where is something worth travelling toward? Direction and strength only —
// never a route. Pure JS.
export const STAGES = ['NONE', 'DETECTED', 'TRANSMISSION', 'STRENGTH', 'DIRECTION', 'IDENTIFIED'];
const STAGE_TIME = [0, 1.5, 1.5, 1.5, 2.5]; // seconds in range before advancing from stage i to i+1
export const IDENTIFY_MIN = 0.2;

export class Receiver {
  constructor(beacons, saved = null) {
    this.beacons = beacons.map((b) => ({ ...b }));
    this.rangeMul = 1;
    this.s = new Map(); // id → {stage, t, visited}
    for (const b of this.beacons) this.s.set(b.id, { stage: b.known ? 5 : 0, t: 0, visited: false, strength: 0 });
    this.tracked = this.beacons.find((b) => b.known)?.id ?? null;
    this.clock = 0;
    this.playerBeacons = 0;
    if (saved) this.load(saved);
  }

  get(id) { return this.beacons.find((b) => b.id === id); }
  state(id) { return this.s.get(id); }

  /** 0..1 received strength of a beacon at p (0 = not receivable right now). */
  strength(b, p) {
    if (b.intermittent && Math.sin(this.clock * 0.9 + b.pos[0]) < -0.35) return 0; // fades in and out
    const d = Math.hypot(b.pos[0] - p[0], b.pos[1] - p[1], b.pos[2] - p[2]);
    const r = b.range * this.rangeMul;
    if (d >= r) return 0;
    return Math.min(1, b.power * Math.pow(1 - d / r, 0.7) * 1.4);
  }

  /** @returns {Array<{id, stage, text}>} stage changes this step (for the Rite Kit channel) */
  update(dt, p) {
    this.clock += dt;
    const out = [];
    for (const b of this.beacons) {
      const st = this.s.get(b.id);
      const k = this.strength(b, p);
      st.strength = k;
      if (Math.hypot(b.pos[0] - p[0], b.pos[1] - p[1], b.pos[2] - p[2]) < 3 && !st.visited) { st.visited = true; out.push({ id: b.id, stage: st.stage, reached: true, text: `BEACON REACHED · ${this.label(b)}` }); }
      if (st.stage >= 5 || k <= 0) continue;
      if (st.stage === 0) { st.stage = 1; st.t = 0; out.push({ id: b.id, stage: 1, text: 'WEAK SIGNAL DETECTED' }); continue; }
      st.t += dt;
      if (st.t < STAGE_TIME[st.stage]) continue;
      if (st.stage === 4 && k < IDENTIFY_MIN) continue; // too weak to identify — get closer
      st.stage++; st.t = 0;
      const text = st.stage === 2 ? (b.type === 'UNKNOWN' ? 'UNKNOWN TRANSMISSION' : 'FORMIC TRANSMISSION')
        : st.stage === 3 ? `SIGNAL STRENGTH: ${Math.round(k * 100)}%`
          : st.stage === 4 ? 'SOURCE DIRECTION ESTIMATED' : `BEACON IDENTIFIED · ${b.name}`;
      out.push({ id: b.id, stage: st.stage, text });
      if (st.stage === 4 && (!this.tracked || !this.canTrack(this.tracked))) this.tracked = b.id;
    }
    return out;
  }

  label(b) { return this.s.get(b.id).stage >= 5 ? b.name : b.type === 'UNKNOWN' ? 'UNKNOWN SIGNAL' : 'SIGNAL'; }

  /** A signal can be followed once its direction is estimated (or its coordinates are known). */
  canTrack(id) { const b = this.get(id); return !!b && (b.known || this.s.get(id).stage >= 4); }
  trackable() { return this.beacons.filter((b) => this.canTrack(b.id)); }

  cycle() {
    const list = this.trackable();
    if (!list.length) return null;
    const i = list.findIndex((b) => b.id === this.tracked);
    this.tracked = list[(i + 1) % list.length].id;
    return this.tracked;
  }

  /** Tracker read-out: direction target, strength, distance only if the coordinates are known (§17). */
  readout(p) {
    const b = this.get(this.tracked);
    if (!b || !this.canTrack(b.id)) return null;
    const st = this.s.get(b.id);
    const d = Math.hypot(b.pos[0] - p[0], b.pos[1] - p[1], b.pos[2] - p[2]);
    const hasDir = b.known || st.strength > 0 || st.stage >= 4;
    return { id: b.id, name: this.label(b), type: b.type, target: b.pos, strength: st.strength, dist: b.known || st.stage >= 5 ? d : null, direction: hasDir, visited: st.visited };
  }

  /** Signal Horizon (§22): a stronger receiver; returns how many signals just became receivable. */
  upgrade(mul, p) {
    const before = this.beacons.filter((b) => this.strength(b, p) > 0).length;
    this.rangeMul = mul;
    return this.beacons.filter((b) => this.strength(b, p) > 0).length - before;
  }

  addPlayerBeacon(pos) {
    const id = `player-${++this.playerBeacons}`;
    const b = { id, name: `YOUR BEACON ${this.playerBeacons}`, type: 'PLAYER', pos: pos.slice(), power: 1, range: 40, known: true };
    this.beacons.push(b);
    this.s.set(id, { stage: 5, t: 0, visited: true, strength: 0 });
    return b;
  }

  toJSON() {
    return { rangeMul: this.rangeMul, tracked: this.tracked, playerBeacons: this.playerBeacons,
      player: this.beacons.filter((b) => b.type === 'PLAYER').map((b) => b.pos),
      s: Object.fromEntries([...this.s].map(([id, v]) => [id, { stage: v.stage, visited: v.visited }])) };
  }
  load(d) {
    for (const pos of d.player || []) this.addPlayerBeacon(pos);
    this.playerBeacons = d.playerBeacons ?? this.playerBeacons;
    this.rangeMul = d.rangeMul ?? 1;
    for (const [id, v] of Object.entries(d.s || {})) if (this.s.has(id)) Object.assign(this.s.get(id), v);
    if (d.tracked && this.s.has(d.tracked)) this.tracked = d.tracked;
  }
}
