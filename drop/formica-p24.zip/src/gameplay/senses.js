// Vibration sense (GDD §45): what the ant feels through its legs, as directions relative to where it looks. Pure JS.
export const SECTORS = 16;

export class VibrationSense {
  constructor(decay = 0.5) { this.s = new Float32Array(SECTORS); this.up = 0; this.down = 0; this.decay = decay; }

  /**
   * @param {{pos:number[], received:number}} ev
   * @param {number[]} eye  @param {number[]} fwd view direction  @param {number[]} up camera up
   */
  feel(ev, eye, fwd, up) {
    const v = [ev.pos[0] - eye[0], ev.pos[1] - eye[1], ev.pos[2] - eye[2]];
    const len = Math.hypot(...v) || 1;
    const vu = (v[0] * up[0] + v[1] * up[1] + v[2] * up[2]) / len;
    const right = [fwd[1] * up[2] - fwd[2] * up[1], fwd[2] * up[0] - fwd[0] * up[2], fwd[0] * up[1] - fwd[1] * up[0]];
    const x = v[0] * right[0] + v[1] * right[1] + v[2] * right[2];
    const z = v[0] * fwd[0] + v[1] * fwd[1] + v[2] * fwd[2];
    const k = Math.min(1, ev.received * 2.5);
    if (vu > 0.8) this.up = Math.max(this.up, k);
    else if (vu < -0.8) this.down = Math.max(this.down, k);
    const a = Math.atan2(x, z); // 0 = ahead, +π/2 = right
    const idx = ((Math.round(a / (2 * Math.PI / SECTORS)) % SECTORS) + SECTORS) % SECTORS;
    this.s[idx] = Math.max(this.s[idx], k);
    // soft spread to neighbours
    this.s[(idx + 1) % SECTORS] = Math.max(this.s[(idx + 1) % SECTORS], k * 0.4);
    this.s[(idx + SECTORS - 1) % SECTORS] = Math.max(this.s[(idx + SECTORS - 1) % SECTORS], k * 0.4);
    return idx;
  }

  update(dt) {
    const f = Math.exp(-dt / this.decay);
    for (let i = 0; i < SECTORS; i++) this.s[i] *= f;
    this.up *= f; this.down *= f;
  }
}
