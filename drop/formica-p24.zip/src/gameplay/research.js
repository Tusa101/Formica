// Research state (ADDENDUM 03 §31–38): blueprints, fragments, knowledge; analysis of one object → outcome + salvage.
import { CATALOG } from '../data/analysis.js';

export const OUTCOME = Object.freeze({ BLUEPRINT: 'COMPLETE BLUEPRINT', FRAGMENT: 'BLUEPRINT FRAGMENT', KNOWLEDGE: 'KNOWLEDGE ENTRY', KNOWN: 'TECHNOLOGY ALREADY KNOWN', RESOURCES: 'NO RECOVERABLE TECHNOLOGY' });

export class Research {
  constructor(saved = null) {
    this.blueprints = new Set(saved?.blueprints || []);
    this.fragments = new Map(Object.entries(saved?.fragments || {}).map(([k, v]) => [k, new Set(v)]));
    this.knowledge = new Set(saved?.knowledge || []);
    this.salvaged = new Set(saved?.salvaged || []); // object ids already dismantled
  }

  /**
   * Analyzes one object of catalog `kind`. Salvageable objects are dismantled (caller removes them) and yield resources.
   * @returns {{kind, name, outcome, lines:string[], salvage:Object, destroy:boolean, unlocked?:string, fragment?:{have,need}}}
   */
  analyze(kind, objectId = null) {
    const d = CATALOG[kind];
    if (!d) throw new Error('not in catalog: ' + kind);
    const firstLook = !this.knowledge.has(kind);
    this.knowledge.add(kind);
    const res = { kind, name: d.name, salvage: {}, destroy: false, lines: [d.name] };
    if (d.blueprint) {
      if (this.blueprints.has(d.blueprint)) res.outcome = OUTCOME.KNOWN;
      else { this.blueprints.add(d.blueprint); res.outcome = OUTCOME.BLUEPRINT; res.unlocked = d.blueprint; }
    } else if (d.fragment) {
      const f = d.fragment;
      if (this.blueprints.has(f.bp)) res.outcome = OUTCOME.KNOWN;
      else {
        const have = this.fragments.get(f.bp) || new Set();
        const isNew = !have.has(f.part);
        have.add(f.part); this.fragments.set(f.bp, have);
        res.fragment = { have: have.size, need: f.parts.length, parts: f.parts.map((p) => ({ p, ok: have.has(p) })) };
        if (have.size >= f.parts.length) { this.blueprints.add(f.bp); res.outcome = OUTCOME.BLUEPRINT; res.unlocked = f.bp; }
        else res.outcome = isNew ? OUTCOME.FRAGMENT : OUTCOME.KNOWN;
      }
    } else if (d.salvageable) res.outcome = OUTCOME.RESOURCES;
    else res.outcome = firstLook ? OUTCOME.KNOWLEDGE : 'ALREADY IN THE ARCHIVE';
    if (d.salvageable && !d.protected && (!objectId || !this.salvaged.has(objectId))) {
      res.salvage = { ...d.salvage }; res.destroy = true;
      if (objectId) this.salvaged.add(objectId);
    }
    // readable lines (A3 §33)
    if (res.outcome === OUTCOME.BLUEPRINT) res.lines.push(res.fragment ? `BLUEPRINT COMPLETE · ${res.unlocked.replace('_', ' ').toUpperCase()}` : `NEW TECHNOLOGY · BLUEPRINT: ${res.unlocked.replace('_', ' ').toUpperCase()}`);
    else if (res.outcome === OUTCOME.FRAGMENT) res.lines.push(`NEW TECHNOLOGY ANALYZED · BLUEPRINT FRAGMENT ${res.fragment.have} / ${res.fragment.need}`);
    else res.lines.push(res.outcome);
    const sal = Object.entries(res.salvage);
    if (sal.length) res.lines.push('SALVAGED ' + sal.map(([k, n]) => `+${n} ${k.replace('_', ' ')}`).join(' '));
    return res;
  }

  toJSON() {
    return { blueprints: [...this.blueprints], knowledge: [...this.knowledge], salvaged: [...this.salvaged],
      fragments: Object.fromEntries([...this.fragments].map(([k, v]) => [k, [...v]])) };
  }
}
