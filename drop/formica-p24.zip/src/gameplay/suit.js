// Adhesion Suit (ADDENDUM 03 §3–4): switchable wall/ceiling grip powered by energy cells. Pure JS.
export const SUIT = Object.freeze({ drainPerSecond: 100 / 90, minUp: 0.643 });

export class Suit {
  constructor(saved = null) {
    this.owned = !!saved?.owned; this.grip = !!saved?.grip; this.charge = saved?.charge ?? 0;
  }
  /** Whether the motor may use adhesion right now. */
  get adhesion() { return this.owned && this.grip && this.charge > 0; }
  equip() { this.owned = true; this.grip = false; }
  toggle() { if (!this.owned) return false; this.grip = !this.grip; return this.grip; }

  /**
   * @param {number} dt  @param {number} upY  body up·Y (steep when below minUp)
   * @param {{count(id):number, remove(id):boolean}} inv  cells are swapped in automatically
   * @returns {null|'swapped'|'empty'} event
   */
  update(dt, upY, inv) {
    if (!this.owned || !this.grip) return null;
    if (this.charge <= 0) {
      if (inv?.count('chemical_cell') && inv.remove('chemical_cell')) { this.charge = 100; return 'swapped'; }
      this.grip = false; return 'empty';
    }
    if (upY < SUIT.minUp) {
      this.charge = Math.max(0, this.charge - SUIT.drainPerSecond * dt);
      if (this.charge === 0) {
        if (inv?.count('chemical_cell') && inv.remove('chemical_cell')) { this.charge = 100; return 'swapped'; }
        this.grip = false; return 'empty';
      }
    }
    return null;
  }
  toJSON() { return { owned: this.owned, grip: this.grip, charge: this.charge }; }
}
