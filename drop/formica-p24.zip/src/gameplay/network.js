// The player's infrastructure (ADDENDUM 03 §10): lamps and dug tunnels on top of the natural network. Pure JS.
export class Network {
  constructor(saved = null) {
    this.lamps = (saved?.lamps || []).map((p) => p.slice());
    this.dug = new Set(saved?.dug || []); // grid keys of the player's bites
    this.version = 0;
  }
  addLamp(pos) { this.lamps.push(pos.map((v) => +v.toFixed(2))); this.version++; return this.lamps.length - 1; }
  /** Nearest own lamp within r of p (index) or −1. */
  lampNear(p, r = 1.6) {
    let best = -1, bd = r;
    this.lamps.forEach((l, i) => { const d = Math.hypot(l[0] - p[0], l[1] - p[1], l[2] - p[2]); if (d < bd) { bd = d; best = i; } });
    return best;
  }
  removeLamp(i) { if (i < 0 || i >= this.lamps.length) return null; this.version++; return this.lamps.splice(i, 1)[0]; }
  /** A bite of the player's excavation at `center` (0.4 u grid, deduplicated). Collapses are not recorded. */
  markBite(center) {
    const k = center.map((v) => Math.round(v / 0.4)).join(',');
    if (this.dug.has(k)) return false;
    this.dug.add(k); this.version++;
    return true;
  }
  /** World positions of the dug grid points. */
  dugPoints() { return [...this.dug].map((k) => k.split(',').map((v) => Number(v) * 0.4)); }
  toJSON() { return { lamps: this.lamps, dug: [...this.dug] }; }
}
