// Ritual Shelter + expedition infrastructure (GDD §5 civilisation pulled through the tunnels, §16–17; ADD §8):
// modules with states, a power budget burning chemical cells, an air network of pipes/boosters and forward camps.
// Pure JS — line of sight is injected so it can be tested without a world.
import { MODULE_TYPES as T } from '../data/modules.js';

// ADDENDUM 03 §29: air → water → lighting → controls → fabricator → optional machinery
const PRIORITY = ['air', 'condenser', 'lighting', 'terminal', 'fabricator', 'booster', 'beacon'];
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

export class BaseNetwork {
  /** @param {Array} defs level.shelter.modules  @param {{los?:(a,b)=>boolean}} env */
  constructor(defs, env = {}) {
    this.los = env.los || (() => true);
    this.modules = defs.map((d) => ({ ...d, pos: d.pos.slice(), fuel: d.fuel ?? (d.type === 'power' ? 0 : undefined), powered: false }));
    this.supply = 0; this.demand = 0; this.used = 0;
    this.placedCount = 0;
    this.linked = new Set();
    this.recompute();
  }

  get(id) { return this.modules.find((m) => m.id === id); }
  ofType(t) { return this.modules.filter((m) => m.type === t); }

  /** Repair to 'working'; consumes materials from the inventory. */
  repair(id, inv) {
    const m = this.get(id);
    const need = T[m?.type]?.repair?.[m.state];
    if (!need) return { ok: false, reason: 'nothing to repair' };
    if (!inv.has(need)) return { ok: false, reason: 'missing materials', need };
    for (const [k, n] of Object.entries(need)) inv.remove(k, n);
    m.state = 'working';
    this.recompute();
    return { ok: true };
  }

  /** Power node: +100 fuel per chemical cell (max 200). Camp: battery to full. */
  refuel(id, inv) {
    const m = this.get(id);
    if (!m || !inv.count('chemical_cell')) return { ok: false, reason: 'no chemical cell' };
    if (m.type === 'power') { if (m.fuel >= 200) return { ok: false, reason: 'full' }; m.fuel = Math.min(200, m.fuel + 100); }
    else if (m.type === 'camp') { if (m.battery >= 100) return { ok: false, reason: 'full' }; m.battery = 100; }
    else return { ok: false, reason: 'cannot refuel' };
    inv.remove('chemical_cell');
    this.recompute();
    return { ok: true };
  }

  /** Places infrastructure (pipe, booster, camp) at a floor point. */
  place(type, pos) {
    const id = `${type}-${++this.placedCount}-${Math.round(pos[0] * 10)}`;
    const m = { id, type, pos: pos.slice(), state: 'working', placed: true, powered: false };
    if (type === 'camp') m.battery = T.camp.battery;
    this.modules.push(m);
    this.recompute();
    return m;
  }

  /** Power budget: supply from power nodes with fuel; consumers served greedily by priority. */
  recompute() {
    let starter = 0, aux = 0;
    for (const g of this.ofType('generator')) starter += T.generator.supply[g.state] || 0;
    for (const p of this.ofType('power')) aux += p.fuel > 0 ? T.power.supply[p.state] || 0 : 0;
    const supply = starter + aux;
    this.starter = starter; this.aux = aux;
    let left = supply, demand = 0;
    const consumers = this.modules.filter((m) => (T[m.type].draw || 0) > 0)
      .sort((a, b) => PRIORITY.indexOf(a.type) - PRIORITY.indexOf(b.type));
    for (const m of this.modules) m.powered = !(T[m.type].draw > 0) && (m.state === 'working' || (T[m.type].supply && m.state === 'degraded'));
    for (const m of consumers) {
      const d = T[m.type].draw;
      const usable = m.enabled !== false && (m.state === 'working' || (m.type === 'air' && m.state === 'degraded'));
      if (!usable) continue;
      demand += d;
      if (d <= left + 1e-9) { m.powered = true; left -= d; }
    }
    for (const c of this.ofType('camp')) c.powered = c.battery > 0;
    this.supply = supply; this.demand = demand; this.used = supply - left;
    this.insufficient = demand > supply + 1e-9;
    this._linkAir();
  }

  /** Air network: BFS from powered processors along pipes/boosters in range with line of sight. */
  _linkAir() {
    this.linked = new Set();
    this.parent = new Map();
    const roots = this.ofType('air').filter((m) => m.powered);
    const nodes = this.modules.filter((m) => m.type === 'pipe' || (m.type === 'booster' && m.powered));
    const queue = roots.map((r) => ({ m: r, range: 6 }));
    for (const r of roots) this.linked.add(r.id);
    while (queue.length) {
      const { m, range } = queue.shift();
      for (const n of nodes) {
        if (this.linked.has(n.id)) continue;
        const reach = Math.max(range, T[n.type].link);
        if (dist(m.pos, n.pos) <= reach && this.los(m.pos, n.pos)) { this.linked.add(n.id); this.parent.set(n.id, m.id); queue.push({ m: n, range: T[n.type].link }); }
      }
    }
  }

  /** Fresh-air sources for the atmosphere (ADD §66 stationary network). */
  airSources() {
    const out = [];
    for (const m of this.modules) {
      const r = T[m.type].airRadius;
      if (!r) continue;
      if (m.type === 'air' && m.powered) out.push({ pos: m.pos, radius: r[m.state] || 0 });
      else if ((m.type === 'pipe' || m.type === 'booster') && this.linked.has(m.id)) out.push({ pos: m.pos, radius: r.working });
      else if (m.type === 'camp' && m.battery > 0) out.push({ pos: m.pos, radius: r.working });
    }
    return out.filter((s) => s.radius > 0);
  }

  update(dt) {
    // fuel burns in proportion to the power actually used
    // the starter generator covers what it can for free; cells burn only for the excess (A3 §26–28)
    const nodes = this.ofType('power').filter((p) => p.fuel > 0 && T.power.supply[p.state]);
    const auxUsed = Math.max(0, this.used - (this.starter || 0));
    if (nodes.length && auxUsed > 0) for (const p of nodes) p.fuel = Math.max(0, p.fuel - (dt * auxUsed) / 15 / nodes.length);
    let changed = nodes.some((p) => p.fuel === 0);
    for (const c of this.ofType('camp')) if (c.battery > 0) { c.battery = Math.max(0, c.battery - T.camp.drain * dt); if (c.battery === 0) changed = true; }
    if (changed) this.recompute();
  }

  /** Switches a consumer on/off (the player decides what the power budget feeds). */
  toggle(id) {
    const m = this.get(id);
    if (!m || !(T[m.type].draw > 0)) return false;
    m.enabled = m.enabled === false;
    this.recompute();
    return m.enabled;
  }

  isPowered(id) { return !!this.get(id)?.powered; }

  toJSON() {
    return { placedCount: this.placedCount, modules: this.modules.map(({ id, type, pos, state, fuel, battery, placed, enabled }) => ({ id, type, pos, state, fuel, battery, placed, enabled })) };
  }
  /** Restores saved states on top of the level definition (placed modules re-added). */
  load(saved) {
    if (!saved?.modules) return;
    this.placedCount = saved.placedCount || 0;
    for (const s of saved.modules) {
      const m = this.get(s.id);
      if (m) Object.assign(m, { state: s.state, fuel: s.fuel, battery: s.battery, enabled: s.enabled });
      else if (s.placed) this.modules.push({ ...s, powered: false });
    }
    this.recompute();
  }
}
