// Field crafting. Pure JS.
import { RECIPES } from '../data/recipes.js';
import { ITEMS } from '../data/items.js';

/** @returns {{ok:boolean, reason?:string}} */
export function canCraft(inv, recipe, stations = {}, known = null) {
  if (recipe.blueprint && known && !known.has(recipe.id)) return { ok: false, reason: 'unknown blueprint' };
  if (recipe.station && !stations[recipe.station]) return { ok: false, reason: 'needs ' + recipe.station };
  if (!inv.has(recipe.needs)) return { ok: false, reason: 'missing materials' };
  // weight after crafting: ingredients leave, product arrives
  let delta = (ITEMS[recipe.out].weight ?? 1) * recipe.n;
  for (const [id, n] of Object.entries(recipe.needs)) delta -= (ITEMS[id].weight ?? 1) * n;
  if (inv.weight + delta > inv.limit + 1e-9) return { ok: false, reason: 'too heavy' };
  return { ok: true };
}

export function craft(inv, recipeId, stations = {}, known = null) {
  const r = RECIPES.find((x) => x.id === recipeId);
  if (!r) return { ok: false, reason: 'unknown recipe' };
  const c = canCraft(inv, r, stations, known);
  if (!c.ok) return c;
  for (const [id, n] of Object.entries(r.needs)) inv.remove(id, n);
  inv.items.set(r.out, inv.count(r.out) + r.n);
  return { ok: true, item: r.out };
}
