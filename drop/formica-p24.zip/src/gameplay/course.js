// Traversal course: ordered gates, timer, best time. Pure logic (tested) — markers live in render code.
export class Course {
  constructor(def, storage = null) {
    this.def = def;
    this.storage = storage;
    this.bestKey = `formica.best.${def.id}`;
    this.best = null;
    try { const v = storage?.getItem(this.bestKey); this.best = v ? Number(v) : null; } catch { /* ignore */ }
    this.reset();
  }

  reset() { this.index = 0; this.time = 0; this.running = false; this.finished = false; this.lastSplit = null; }

  get next() { return this.def.gates[this.index] || null; }

  /** @returns {null | {type:'gate', gate, index} | {type:'finish', time, best, record}} */
  update(dt, pos, moving) {
    if (this.finished) return null;
    if (!this.running && moving) this.running = true;
    if (this.running) this.time += dt;
    const g = this.next;
    const d = Math.hypot(pos[0] - g.pos[0], pos[1] - g.pos[1], pos[2] - g.pos[2]);
    if (d > g.r) return null;
    this.index++;
    this.lastSplit = this.time;
    if (this.index < this.def.gates.length) return { type: 'gate', gate: g, index: this.index };
    this.finished = true;
    const record = this.best === null || this.time < this.best;
    if (record) { this.best = this.time; try { this.storage?.setItem(this.bestKey, String(this.time)); } catch { /* ignore */ } }
    return { type: 'finish', time: this.time, best: this.best, record };
  }
}

export function formatTime(t) {
  if (t === null || t === undefined) return '--:--.-';
  const m = Math.floor(t / 60), s = t - m * 60;
  return `${m}:${s < 10 ? '0' : ''}${s.toFixed(1)}`;
}
