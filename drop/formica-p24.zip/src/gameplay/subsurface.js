// Subsurface Scanner (ADDENDUM 03 §12–14): a limited geological "wall hack". Pure JS.
import { MATERIALS } from '../data/materials.js';

/** Boundary cells of open space within `radius` — through rock, no line of sight needed. */
export function pulseCells(nav, pos, radius) {
  const out = [];
  const [X, Y, Z] = nav.dims;
  const c0 = nav.cellAt(pos); if (c0 < 0) return out;
  const [i0, j0, k0] = nav.coords(c0);
  const R = Math.ceil(radius / nav.cell), R2 = R * R;
  for (let k = Math.max(0, k0 - R); k <= Math.min(Z - 1, k0 + R); k++) for (let j = Math.max(0, j0 - R); j <= Math.min(Y - 1, j0 + R); j++)
    for (let i = Math.max(0, i0 - R); i <= Math.min(X - 1, i0 + R); i++) {
      if ((i - i0) ** 2 + (j - j0) ** 2 + (k - k0) ** 2 > R2) continue;
      const idx = nav.index(i, j, k);
      if (!nav.open[idx]) continue;
      const border = (i > 0 && !nav.open[idx - 1]) || (i + 1 < X && !nav.open[idx + 1]) || (j > 0 && !nav.open[idx - X]) ||
        (j + 1 < Y && !nav.open[idx + X]) || (k > 0 && !nav.open[idx - X * Y]) || (k + 1 < Z && !nav.open[idx + X * Y]);
      if (border) out.push(idx);
    }
  return out;
}

/** From an eye point along dir: first rock hit within `reach`, then rock thickness until open space (≤ maxThick). */
export function wallProbe(field, eye, dir, reach = 3, maxThick = 8, step = 0.1) {
  let t = 0, hit = null;
  for (; t <= reach; t += step) if (field.densityAt(eye[0] + dir[0] * t, eye[1] + dir[1] * t, eye[2] + dir[2] * t) > 0) { hit = t; break; }
  if (hit === null) return null;
  const at = (s) => [eye[0] + dir[0] * s, eye[1] + dir[1] * s, eye[2] + dir[2] * s];
  const inRock = at(hit + 0.15);
  const mat = MATERIALS[field.materialAt(...inRock)] || null;
  for (let s = hit; s <= hit + maxThick; s += step) {
    const p = at(s);
    if (field.densityAt(...p) < 0) return { hit: at(hit), dist: hit, thickness: s - hit, beyond: at(s + 0.4), material: mat };
  }
  return { hit: at(hit), dist: hit, thickness: Infinity, beyond: null, material: mat };
}

/**
 * Thin walls with scanned space behind them whose walk-around is long (or impossible): shortcut candidates.
 * @param {{graph, nav}} topo  region graph for path lengths
 */
export function findShortcuts(field, topo, eye, { dirs = 16, maxThick = 5, minGain = 15, reach = 6 } = {}) {
  const g = topo.graph;
  const here = g.nodeAt(eye, 3);
  const dist = here >= 0 ? g.distancesFrom(here) : null;
  const out = [];
  for (let k = 0; k < dirs; k++) {
    const a = (k / dirs) * Math.PI * 2;
    for (const tilt of [0, 0.2, -0.25]) {
      const d = [Math.cos(a) * Math.cos(tilt), Math.sin(tilt), Math.sin(a) * Math.cos(tilt)];
      const w = wallProbe(field, eye, d, reach, maxThick + 0.5);
      if (!w || !w.beyond || w.thickness > maxThick) continue;
      const there = g.nodeAt(w.beyond, 2);
      if (there < 0 || there === here) continue;
      const walk = dist ? dist[there] : Infinity;
      const straight = w.dist + w.thickness;
      if (walk !== Infinity && walk - straight < minGain) continue;
      out.push({ hit: w.hit, beyond: w.beyond, thickness: w.thickness, material: w.material, walk, straight, sealed: walk === Infinity, node: there });
      break;
    }
  }
  // one candidate per target region: keep the thinnest wall
  const best = new Map();
  for (const c of out) if (!best.has(c.node) || c.thickness < best.get(c.node).thickness) best.set(c.node, c);
  return [...best.values()].sort((x, y) => (y.walk === Infinity ? 1e9 : y.walk - y.straight) - (x.walk === Infinity ? 1e9 : x.walk - x.straight));
}
