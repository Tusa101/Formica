// Points of interest (ADDENDUM 03 §20–21): places discovered by walking into them. Pure JS.
export class Places {
  constructor(pois, saved = []) { this.pois = pois || []; this.discovered = new Set(saved); }
  /** @returns {Array<{id, name}>} places discovered this step */
  update(p) {
    const out = [];
    for (const q of this.pois) {
      if (this.discovered.has(q.id)) continue;
      if (Math.hypot(q.center[0] - p[0], q.center[1] - p[1], q.center[2] - p[2]) <= q.r) { this.discovered.add(q.id); out.push(q); }
    }
    return out;
  }
  toJSON() { return [...this.discovered]; }
}
