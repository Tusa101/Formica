// In-game layout self-test. Pure checks are exported for Node tests;
// runLayoutSelfTest() gathers rectangles from the DOM.

export function rectsOverlap(a, b, tol = 0.5) {
  return a.left < b.right - tol && b.left < a.right - tol && a.top < b.bottom - tol && b.top < a.bottom - tol;
}

/**
 * @param {Array<{id:string, rect:{left,top,right,bottom,width,height}, interactive:boolean, group?:string}>} items
 * @param {{width:number,height:number, safe:{top,right,bottom,left}}} viewport
 * @param {number} minTarget
 * @returns {string[]} problems (empty = OK)
 */
export function checkLayout(items, viewport, minTarget) {
  const problems = [];
  const s = viewport.safe;
  const box = { left: s.left, top: s.top, right: viewport.width - s.right, bottom: viewport.height - s.bottom };
  for (const it of items) {
    const r = it.rect;
    if (r.width === 0 || r.height === 0) continue;
    if (r.left < box.left - 0.5 || r.top < box.top - 0.5 || r.right > box.right + 0.5 || r.bottom > box.bottom + 0.5) {
      problems.push(`${it.id}: outside safe area`);
    }
    if (it.interactive && (r.width < minTarget || r.height < minTarget)) {
      problems.push(`${it.id}: touch target ${Math.round(r.width)}×${Math.round(r.height)} < ${minTarget}`);
    }
  }
  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      const a = items[i], b = items[j];
      if (a.group && a.group === b.group) continue;
      if (!a.rect.width || !b.rect.width) continue;
      if (rectsOverlap(a.rect, b.rect)) problems.push(`${a.id} overlaps ${b.id}`);
    }
  }
  return problems;
}

function readSafeArea() {
  const probe = document.createElement('div');
  probe.style.cssText = 'position:fixed;visibility:hidden;pointer-events:none;' +
    'padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)';
  document.body.appendChild(probe);
  const cs = getComputedStyle(probe);
  const safe = {
    top: parseFloat(cs.paddingTop) || 0, right: parseFloat(cs.paddingRight) || 0,
    bottom: parseFloat(cs.paddingBottom) || 0, left: parseFloat(cs.paddingLeft) || 0,
  };
  probe.remove();
  return safe;
}

function isVisible(el) {
  if (!el.isConnected) return false;
  const cs = getComputedStyle(el);
  return cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity) > 0;
}

export function runLayoutSelfTest(minTarget) {
  const items = [];
  for (const el of document.querySelectorAll('[data-hud]')) {
    if (!isVisible(el) || el.closest('[hidden]')) continue;
    const rc = el.getBoundingClientRect();
    // Skip elements fully covered by a modal (e.g. the rotate hint): check what the player can actually see.
    const top = document.elementFromPoint(rc.left + rc.width / 2, rc.top + rc.height / 2);
    const cover = top && top.closest('.overlay');
    if (cover && !cover.contains(el)) continue;
    items.push({
      id: el.dataset.hud,
      rect: rc,
      interactive: el.matches('button, [data-touch-target]'),
      group: el.dataset.hudGroup,
    });
  }
  const viewport = { width: innerWidth, height: innerHeight, safe: readSafeArea() };
  return { problems: checkLayout(items, viewport, minTarget), checked: items.length };
}
