// Settings (P12.2) + save management (P12.3). Minimal formic UI; every control ≥ 44 px.
import { settings, LIMITS } from '../settings.js';

export class SettingsPanel {
  constructor(root, cb) {
    this.cb = cb; // { onChange(key, value), onCamera(), onExport(), onImport(text), onReset(), onClose(), cameraLabel(), saveInfo() }
    this.el = document.createElement('div');
    this.el.id = 'settings'; this.el.className = 'overlay'; this.el.hidden = true;
    this.el.innerHTML = `<div class="panel carapace settings">
      <div class="cara-head"><div class="title small">SETTINGS</div>
        <button class="pbtn cara-close" data-hud="set-close" data-hud-group="set">CLOSE</button></div>
      <div class="set-body"></div>
      <input type="file" accept="application/json,.json" hidden></div>`;
    root.appendChild(this.el);
    this.el.querySelector('.cara-close').addEventListener('click', () => cb.onClose());
    this.file = this.el.querySelector('input[type=file]');
    this.file.addEventListener('change', async () => {
      const f = this.file.files?.[0]; if (!f) return;
      cb.onImport(await f.text()); this.file.value = '';
    });
    this.el.addEventListener('input', (e) => {
      const r = e.target.closest('input[type=range]'); if (!r) return;
      cb.onChange(r.dataset.key, Number(r.value));
    });
    this.el.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-act]'); if (!b) return;
      const { act, arg } = b.dataset;
      if (act === 'toggle') cb.onChange(arg, !settings[arg]);
      if (act === 'quality') cb.onChange('quality', arg);
      if (act === 'camera') cb.onCamera();
      if (act === 'export') cb.onExport();
      if (act === 'import') this.file.click();
      if (act === 'reset' && confirm('Delete ALL progress (world, kit, base, map, story)? Settings are kept.')) cb.onReset();
      this.render();
    });
  }
  get open() { return !this.el.hidden; }
  show() { this.el.hidden = false; this.render(); }
  hide() { this.el.hidden = true; }

  render() {
    const touch = document.body.classList.contains('is-touch');
    const slider = (key, label) => {
      const [lo, hi] = LIMITS[key];
      return `<div class="set-row"><span>${label}</span><input type="range" data-key="${key}" min="${lo}" max="${hi}" step="${(hi - lo) / 40}" value="${settings[key]}"></div>`;
    };
    const tog = (key, label) => `<div class="set-row"><span>${label}</span><button class="cbtn ${settings[key] ? '' : 'ghost'}" data-act="toggle" data-arg="${key}">${settings[key] ? 'ON' : 'OFF'}</button></div>`;
    const q = ['low', 'medium', 'high', 'auto'].map((x) => `<button class="cbtn ${settings.quality === x ? '' : 'ghost'}" data-act="quality" data-arg="${x}">${x.toUpperCase()}</button>`).join('');
    const info = this.cb.saveInfo();
    this.el.querySelector('.set-body').innerHTML = `
      ${touch ? slider('lookTouch', 'LOOK SPEED') : slider('lookMouse', 'MOUSE SPEED')}
      ${tog('invertY', 'INVERT LOOK Y')}
      <div class="set-row"><span>CAMERA</span><button class="cbtn ghost" data-act="camera">${this.cb.cameraLabel()}</button></div>
      <div class="set-row"><span>QUALITY</span><div class="set-seg">${q}</div></div>
      ${slider('volume', 'VOLUME')}
      ${tog('voice', 'RECORDING VOICE')}
      ${tog('hints', 'CONTROL TIPS')}
      ${tog('vignette', 'CLIMB VIGNETTE (suit)')}
      ${tog('showCourse', 'SANDBOX COURSE')}
      <div class="set-row"><span>SAVE · ${info}</span><div class="set-seg">
        <button class="cbtn ghost" data-act="export">EXPORT</button><button class="cbtn ghost" data-act="import">IMPORT</button>
        <button class="cbtn ghost danger" data-act="reset">RESET ALL</button></div></div>`;
  }
}
