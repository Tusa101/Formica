// GDD §64 ending of the vertical slice: the transmission, then stats.
import { TRANSMISSION } from '../data/lore.js';

export class Finale {
  constructor(root, { onContinue, onNewRite }) {
    this.el = document.createElement('div');
    this.el.id = 'finale'; this.el.className = 'overlay'; this.el.hidden = true;
    this.el.innerHTML = `<div class="panel finale"><div class="fin-lines"></div><div class="fin-end" hidden>
      <div class="title">END OF VERTICAL SLICE</div><div class="fin-stats"></div>
      <div class="btns"><button class="pbtn primary" data-hud="fin-continue" data-hud-group="fin">CONTINUE EXPLORING</button>
      <button class="pbtn" data-hud="fin-new" data-hud-group="fin">NEW RITE</button></div></div></div>`;
    root.appendChild(this.el);
    this.el.querySelector('[data-hud="fin-continue"]').addEventListener('click', onContinue);
    this.el.querySelector('[data-hud="fin-new"]').addEventListener('click', onNewRite);
  }
  get open() { return !this.el.hidden; }
  hide() { this.el.hidden = true; }
  async play(stats, speak) {
    this.el.hidden = false;
    const box = this.el.querySelector('.fin-lines'); box.innerHTML = '';
    this.el.querySelector('.fin-end').hidden = true;
    for (const l of TRANSMISSION) {
      const p = document.createElement('p'); p.textContent = l.text; p.className = l.text.startsWith('[') || l.text.startsWith('…') ? 'noise' : '';
      box.appendChild(p);
      if (!p.className) speak?.(l.text);
      await new Promise((r) => setTimeout(r, l.pause * 1000));
    }
    const m = Math.floor(stats.time / 60), s = Math.floor(stats.time % 60);
    this.el.querySelector('.fin-stats').innerHTML = `
      <p>Time underground · ${m} min ${s} s</p><p>Rock excavated · ${stats.dug.toFixed(1)} u³</p>
      <p>Collapses · ${stats.collapses}</p><p>Times you blacked out · ${stats.deaths}</p>
      <p>Foreign scouts that saw you · ${stats.alerts}</p><p class="q">What happened to you down there?</p>`;
    this.el.querySelector('.fin-end').hidden = false;
  }
}
