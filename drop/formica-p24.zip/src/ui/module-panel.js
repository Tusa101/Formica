// Module interaction panel (USE on a shelter module / camp): state, power, repair, refuel, storage, log.
export class ModulePanel {
  constructor(root, { onAction, onClose }) {
    this.cb = { onAction, onClose };
    this.el = document.createElement('div');
    this.el.id = 'module-panel'; this.el.className = 'overlay'; this.el.hidden = true;
    this.el.innerHTML = `<div class="panel carapace module">
      <div class="cara-head"><div class="title small mp-title"></div><div class="mp-state"></div>
        <button class="pbtn cara-close" data-hud="mod-close" data-hud-group="mod">CLOSE</button></div>
      <div class="mp-body"></div></div>`;
    root.appendChild(this.el);
    this.el.querySelector('.cara-close').addEventListener('click', () => this.cb.onClose());
    this.el.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-act]');
      if (b && !b.disabled) this.cb.onAction(b.dataset.act, b.dataset.arg);
    });
  }
  get open() { return !this.el.hidden; }
  hide() { this.el.hidden = true; }
  /** @param {{title, state, stateClass, lines:string[], actions:Array<{act,arg?,label,enabled,note?}>, lists?:Array<{title,rows:Array<{label,act,arg,btn}>}>, log?:string[]}} vm */
  show(vm) {
    this.el.hidden = false;
    this.el.querySelector('.mp-title').textContent = vm.title;
    const st = this.el.querySelector('.mp-state'); st.textContent = vm.state; st.className = 'mp-state ' + (vm.stateClass || '');
    const actions = vm.actions.map((a) => `<div class="cara-row"><div class="cr-name">${a.label}<small>${a.note || ''}</small></div>
      <button class="cbtn" data-act="${a.act}" data-arg="${a.arg ?? ''}" ${a.enabled ? '' : 'disabled'}>${a.btn || 'DO'}</button></div>`).join('');
    const lists = (vm.lists || []).map((l) => `<div class="cara-col"><div class="cara-sub">${l.title}</div><div class="cara-list">${
      l.rows.map((r) => `<div class="cara-row"><div class="cr-name">${r.label}</div><button class="cbtn ghost" data-act="${r.act}" data-arg="${r.arg}">${r.btn}</button></div>`).join('') || '<div class="cara-empty">empty</div>'}</div></div>`).join('');
    const log = vm.log ? `<div class="mp-log">${vm.log.map((l) => `<p>${l}</p>`).join('')}</div>` : '';
    this.el.querySelector('.mp-body').innerHTML =
      `<div class="mp-lines">${vm.lines.map((l) => `<p>${l}</p>`).join('')}</div>${actions}${lists ? `<div class="cara-cols">${lists}</div>` : ''}${log}`;
  }
}
