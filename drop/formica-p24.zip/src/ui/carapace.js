// NAV-CARAPACE panel (GDD §58): vitals, inventory with actions, field crafting. Minimal formic UI (AB §35).
import { ITEMS } from '../data/items.js';
import { RECIPES } from '../data/recipes.js';
import { canCraft } from '../gameplay/crafting.js';

export class Carapace {
  constructor(root, { onUse, onDrop, onCraft, onClose, onArchive }) {
    this.cb = { onUse, onDrop, onCraft, onClose, onArchive };
    this.el = document.createElement('div');
    this.el.id = 'carapace'; this.el.className = 'overlay'; this.el.hidden = true;
    this.el.innerHTML = `
      <div class="panel carapace">
        <div class="cara-head">
          <div class="title small">NAV-CARAPACE</div>
          <div class="cara-vitals"></div>
          <button class="pbtn cara-arch" data-hud="kit-archive" data-hud-group="kit">ARCHIVE</button>
          <button class="pbtn cara-close" data-hud="kit-close" data-hud-group="kit">CLOSE</button>
        </div>
        <div class="cara-cols">
          <div class="cara-col"><div class="cara-sub">KIT <span class="cara-weight"></span></div><div class="cara-list inv"></div></div>
          <div class="cara-col"><div class="cara-sub">FIELD CRAFT</div><div class="cara-list craft"></div></div>
        </div>
      </div>`;
    root.appendChild(this.el);
    this.el.querySelector('.cara-close').addEventListener('click', () => this.cb.onClose());
    this.el.querySelector('.cara-arch').addEventListener('click', () => this.cb.onArchive?.());
    this.el.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-act]');
      if (!b || b.disabled) return;
      const { act, id } = b.dataset;
      if (act === 'use') this.cb.onUse(id);
      if (act === 'drop') this.cb.onDrop(id);
      if (act === 'craft') this.cb.onCraft(id);
    });
  }

  get open() { return !this.el.hidden; }
  show(state) { this.el.hidden = false; this.render(state); }
  hide() { this.el.hidden = true; }

  render({ survival: s, inventory: inv, stations = {}, research = null }) {
    const known = research?.blueprints || null;
    if (this.el.hidden) return;
    const bar = (label, v, warn = 40) => `<div class="cv ${v < warn * 0.5 ? 'danger' : v < warn ? 'caution' : ''}"><span>${label}</span><b style="width:${Math.round(v)}%"></b><em>${Math.round(v)}</em></div>`;
    this.el.querySelector('.cara-vitals').innerHTML =
      bar('HP', s.health) + bar('EN', s.energy) + bar('WATER', s.hydration) + bar('BREATH', s.breath, 60) + bar('CELL', s.toolCharge, 20) +
      (s.filter > 0 ? `<div class="cv-note">FILTER ${Math.ceil(s.filter)}s</div>` : '');
    this.el.querySelector('.cara-weight').textContent = `${inv.weight.toFixed(1)} / ${inv.limit}`;
    this.el.querySelector('.inv').innerHTML = inv.list().map((it) => `
      <div class="cara-row"><div class="cr-name">${it.name}<span>×${it.n}</span><small>${it.desc || ''}</small></div>
        ${it.verb ? `<button class="cbtn" data-act="use" data-id="${it.id}">${it.verb}</button>` : ''}
        ${it.key ? '' : `<button class="cbtn ghost" data-act="drop" data-id="${it.id}">DROP</button>`}</div>`).join('') || '<div class="cara-empty">empty</div>';
    this.el.querySelector('.cara-col:last-child .cara-sub').textContent = stations.fabricator ? 'FABRICATOR' : 'FIELD CRAFT';
    this.el.querySelector('.craft').innerHTML = RECIPES.map((r) => {
      const c = canCraft(inv, r, stations, known);
      if (r.blueprint && known && !known.has(r.id)) {
        const fr = research.fragments.get(r.id);
        return `<div class="cara-row"><div class="cr-name">${ITEMS[r.out].name}<small>unknown blueprint${fr ? ` · fragments ${fr.size}` : ''} — analyze salvage to learn it</small></div><button class="cbtn" disabled>?</button></div>`;
      }
      if (r.station && !stations[r.station]) return `<div class="cara-row"><div class="cr-name">${ITEMS[r.out].name}<small>needs a working FABRICATOR</small></div><button class="cbtn" disabled>FAB</button></div>`;
      const needs = Object.entries(r.needs).map(([id, n]) => `<i class="${inv.count(id) >= n ? 'ok' : 'miss'}">${ITEMS[id].name} ${inv.count(id)}/${n}</i>`).join(' ');
      return `<div class="cara-row"><div class="cr-name">${ITEMS[r.out].name}${r.n > 1 ? ` ×${r.n}` : ''}<small>${needs}</small></div>
        <button class="cbtn" data-act="craft" data-id="${r.id}" ${c.ok ? '' : 'disabled'}>${c.ok ? 'CRAFT' : c.reason === 'too heavy' ? 'HEAVY' : '—'}</button></div>`;
    }).join('');
  }
}
