// Quality presets + dynamic resolution (P12.1). Pure logic; the app applies the numbers.
export const PRESETS = Object.freeze({
  low: { ratio: 0.75, fog: 0.75, terrainLow: true },
  medium: { ratio: 1.0, fog: 0.9, terrainLow: false },
  high: { ratio: 1.5, fog: 1.0, terrainLow: false },
});

/** Dynamic resolution: nudges the pixel ratio to keep fps inside [lo, hi]. */
export class DynamicResolution {
  constructor({ min = 0.6, max = 1.5, lo = 45, hi = 58, every = 2, step = 0.1 } = {}) {
    Object.assign(this, { min, max, lo, hi, every, step });
    this.ratio = max; this.t = 0; this.samples = [];
  }
  /** @returns {number|null} a new ratio when it changes */
  update(dt, fps) {
    this.samples.push(fps); this.t += dt;
    if (this.t < this.every) return null;
    const avg = this.samples.reduce((a, b) => a + b, 0) / this.samples.length;
    this.t = 0; this.samples = [];
    let r = this.ratio;
    if (avg < this.lo) r = Math.max(this.min, r - (avg < this.lo - 12 ? this.step * 2 : this.step));
    else if (avg > this.hi) r = Math.min(this.max, r + this.step / 2);
    r = Math.round(r * 100) / 100;
    if (r === this.ratio) return null;
    this.ratio = r;
    return r;
  }
}
