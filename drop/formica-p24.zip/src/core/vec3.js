// Tiny array-based vec3 helpers for pure (Three-free) simulation code.
export const v3 = (x = 0, y = 0, z = 0) => [x, y, z];
export const copy = (o, a) => { o[0] = a[0]; o[1] = a[1]; o[2] = a[2]; return o; };
export const set = (o, x, y, z) => { o[0] = x; o[1] = y; o[2] = z; return o; };
export const add = (o, a, b) => { o[0] = a[0] + b[0]; o[1] = a[1] + b[1]; o[2] = a[2] + b[2]; return o; };
export const sub = (o, a, b) => { o[0] = a[0] - b[0]; o[1] = a[1] - b[1]; o[2] = a[2] - b[2]; return o; };
export const scale = (o, a, s) => { o[0] = a[0] * s; o[1] = a[1] * s; o[2] = a[2] * s; return o; };
export const addScaled = (o, a, b, s) => { o[0] = a[0] + b[0] * s; o[1] = a[1] + b[1] * s; o[2] = a[2] + b[2] * s; return o; };
export const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
export const len = (a) => Math.hypot(a[0], a[1], a[2]);
export const cross = (o, a, b) => {
  const x = a[1] * b[2] - a[2] * b[1], y = a[2] * b[0] - a[0] * b[2], z = a[0] * b[1] - a[1] * b[0];
  o[0] = x; o[1] = y; o[2] = z; return o;
};
export const normalize = (o, a, fallback) => {
  const l = len(a);
  if (l < 1e-8) return fallback ? copy(o, fallback) : set(o, 0, 1, 0);
  return scale(o, a, 1 / l);
};
/** Removes the component of `a` along unit `n` and normalises (tangent projection). */
export const projectOnPlane = (o, a, n, fallback) => { const d = dot(a, n); o[0] = a[0] - n[0] * d; o[1] = a[1] - n[1] * d; o[2] = a[2] - n[2] * d; return normalize(o, o, fallback); };
/** Rotates `a` around unit axis `k` by angle (Rodrigues). */
export const rotateAxis = (o, a, k, ang) => {
  const c = Math.cos(ang), s = Math.sin(ang), d = dot(k, a) * (1 - c);
  const cx = k[1] * a[2] - k[2] * a[1], cy = k[2] * a[0] - k[0] * a[2], cz = k[0] * a[1] - k[1] * a[0];
  o[0] = a[0] * c + cx * s + k[0] * d; o[1] = a[1] * c + cy * s + k[1] * d; o[2] = a[2] * c + cz * s + k[2] * d;
  return o;
};
/** Moves unit vector `a` toward unit `b` by fraction t and renormalises (nlerp). */
export const nlerp = (o, a, b, t, fallback) => { o[0] = a[0] + (b[0] - a[0]) * t; o[1] = a[1] + (b[1] - a[1]) * t; o[2] = a[2] + (b[2] - a[2]) * t; return normalize(o, o, fallback); };
