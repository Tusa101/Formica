// Pure virtual-stick math. No DOM, no Three.js — unit-tested in Node.

/**
 * Converts a finger offset (CSS px) from the stick origin into a move vector.
 * @returns {{x:number, y:number, mag:number}} x right, y forward (screen-up), mag 0..1
 */
export function stickVector(dx, dy, radius, deadzone, exponent) {
  const len = Math.hypot(dx, dy);
  if (radius <= 0 || len === 0) return { x: 0, y: 0, mag: 0 };
  const raw = Math.min(len / radius, 1);
  if (raw <= deadzone) return { x: 0, y: 0, mag: 0 };
  const t = (raw - deadzone) / (1 - deadzone);
  const mag = Math.pow(t, exponent);
  return { x: (dx / len) * mag, y: (-dy / len) * mag, mag };
}

/** Clamps the knob position to the stick ring. */
export function clampKnob(dx, dy, radius) {
  const len = Math.hypot(dx, dy);
  if (len <= radius || len === 0) return { x: dx, y: dy };
  return { x: (dx / len) * radius, y: (dy / len) * radius };
}

/** Normalises a keyboard direction so diagonals are not faster. */
export function keyVector(left, right, back, fwd) {
  const x = (right ? 1 : 0) - (left ? 1 : 0);
  const y = (fwd ? 1 : 0) - (back ? 1 : 0);
  const len = Math.hypot(x, y);
  if (len === 0) return { x: 0, y: 0, mag: 0 };
  return { x: x / len, y: y / len, mag: 1 };
}
