// GREYBOX landmark props. Placeholders with a clear source for every light (AB §10);
// replaced by Blender assets (PIPE §43) through the level's `kind` without touching logic.
import * as THREE from 'three';

function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }

export function fungusCluster(seed, glowColor) {
  const r = rng(seed);
  const g = new THREE.Group();
  const capMat = new THREE.MeshStandardMaterial({ color: 0x9fb8a0, emissive: glowColor, emissiveIntensity: 0.9, roughness: 0.7 });
  const stemMat = new THREE.MeshStandardMaterial({ color: 0xcfc6b0, roughness: 0.9 });
  for (let i = 0; i < 6; i++) {
    const h = 0.3 + r() * 0.7;
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.07, h, 7), stemMat);
    stem.position.set((r() - 0.5) * 1.0, h / 2, (r() - 0.5) * 1.0);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.14 + r() * 0.14, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), capMat);
    cap.position.set(stem.position.x, h, stem.position.z);
    g.add(stem, cap);
  }
  return g;
}

export function ritualLamp() {
  const g = new THREE.Group();
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, 1.2, 8), new THREE.MeshStandardMaterial({ color: 0x3b3128, roughness: 0.6 }));
  post.position.y = 0.6;
  const glass = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 8),
    new THREE.MeshStandardMaterial({ color: 0xe0a64a, emissive: 0xe0a64a, emissiveIntensity: 1.4, roughness: 0.3 }));
  glass.position.y = 1.3;
  g.add(post, glass);
  return g;
}

/** Old ritual path lamp (P13): short chitin post with an amber resin bulb. Returns {group, bulb}. */
export function pathLamp() {
  const g = new THREE.Group();
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.06, 0.55, 7), new THREE.MeshStandardMaterial({ color: 0x3b3128, roughness: 0.6 }));
  post.position.y = 0.27;
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffc27a }));
  bulb.position.y = 0.6;
  const cap = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.08, 8), new THREE.MeshStandardMaterial({ color: 0x3b3128, roughness: 0.6 }));
  cap.position.y = 0.7;
  g.add(post, bulb, cap);
  return { group: g, bulb };
}

/** GREYBOX rubble heap in front of a gate (P15): loose stones that read as "dig here". */
export function rubbleHeap(seed = 5) {
  const r = rng(seed), g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x8f7c5a, roughness: 0.95, flatShading: true });
  for (let i = 0; i < 9; i++) {
    const s = 0.12 + r() * 0.22;
    const m = new THREE.Mesh(new THREE.DodecahedronGeometry(s, 0), mat);
    m.position.set((r() - 0.5) * 1.4, s * 0.6, (r() - 0.5) * 0.7);
    m.rotation.set(r() * 3, r() * 3, r() * 3);
    g.add(m);
  }
  return g;
}

/** GREYBOX field transmitter (P16): thin mast with a light that blinks (dead ones stay dark). */
export function beaconMast(color = 0x5fd0c0) {
  const g = new THREE.Group();
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.06, 0.9, 6), new THREE.MeshStandardMaterial({ color: 0x3b3128, roughness: 0.6 }));
  mast.position.y = 0.45;
  const light = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), new THREE.MeshBasicMaterial({ color }));
  light.position.y = 0.95;
  g.add(mast, light);
  return { group: g, light };
}

export const PROP_BUILDERS = { fungus: (i, l) => fungusCluster(17 + i * 31, l.color), 'ritual-lamp': () => ritualLamp() };
