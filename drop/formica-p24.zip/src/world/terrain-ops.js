// Terrain API (ADD §35): every excavation tool — mandibles now; drills, Burrower, mole later — and
// collapses (P05) edit the density field through these operations. Pure JS.
import { sampleIndex, chunkKey } from './field.js';

const EDGE_MARGIN = 2; // samples next to the world boundary stay solid (no holes into the void)

/**
 * Carves a sphere of empty space. Samples harder than `maxHardness` are left untouched.
 * @returns {{chunks:Set<object>, removed:Object<number,number>}} touched chunks, removed volume per material id
 */
export function carveSphere(field, c, r, { maxHardness = Infinity, hardness = () => 0, now = 0 } = {}) {
  const { N, voxel } = field;
  const touched = new Set();
  const removed = {};
  const cellVol = voxel * voxel * voxel;
  const pad = 0.9; // freshly exposed rock within r + pad gets a cut timestamp
  const g0 = [0, 1, 2].map((a) => Math.floor((c[a] - r - pad) / voxel));
  const g1 = [0, 1, 2].map((a) => Math.ceil((c[a] + r + pad) / voxel));
  // a chunk holds samples c*N-1 … c*N+N (halo included); visit every chunk that may overlap, filter below
  const cMin = g0.map((g) => Math.floor(g / N) - 1), cMax = g1.map((g) => Math.floor(g / N) + 1);
  for (let cz = cMin[2]; cz <= cMax[2]; cz++) for (let cy = cMin[1]; cy <= cMax[1]; cy++) for (let cx = cMin[0]; cx <= cMax[0]; cx++) {
    const ch = field.chunks.get(chunkKey(cx, cy, cz));
    if (!ch) continue;
    const ox = cx * N, oy = cy * N, oz = cz * N;
    // local sample range (halo included) intersecting the op bounds
    const lo = [Math.max(-1, g0[0] - ox), Math.max(-1, g0[1] - oy), Math.max(-1, g0[2] - oz)];
    const hi = [Math.min(N, g1[0] - ox), Math.min(N, g1[1] - oy), Math.min(N, g1[2] - oz)];
    if (lo[0] > hi[0] || lo[1] > hi[1] || lo[2] > hi[2]) continue;
    let changed = false;
    for (let k = lo[2]; k <= hi[2]; k++) for (let j = lo[1]; j <= hi[1]; j++) for (let i = lo[0]; i <= hi[0]; i++) {
      const gx = ox + i, gy = oy + j, gz = oz + k;
      if (field.gMin && (gx < field.gMin[0] + EDGE_MARGIN || gy < field.gMin[1] + EDGE_MARGIN || gz < field.gMin[2] + EDGE_MARGIN ||
        gx > field.gMax[0] - EDGE_MARGIN || gy > field.gMax[1] - EDGE_MARGIN || gz > field.gMax[2] - EDGE_MARGIN)) continue;
      const x = gx * voxel, y = gy * voxel, z = gz * voxel;
      const dist = Math.hypot(x - c[0], y - c[1], z - c[2]);
      const idx = sampleIndex(N, i, j, k);
      const d = ch.density[idx];
      if (d > 0 && hardness(ch.material[idx]) > maxHardness) continue;
      const sd = dist - r;
      if (sd < d) {
        if (d > 0 && sd <= 0 && i >= 0 && j >= 0 && k >= 0 && i < N && j < N && k < N) {
          const m = ch.material[idx];
          removed[m] = (removed[m] || 0) + cellVol; // owned samples only → no double count across halos
        }
        ch.density[idx] = sd;
        changed = true;
      }
      if (ch.density[idx] > 0 && dist < r + pad && now > 0) {
        if (!ch.cutTime) ch.cutTime = new Float32Array(ch.density.length);
        ch.cutTime[idx] = now;
        changed = true;
      }
    }
    if (changed) { ch.version++; touched.add(ch); }
  }
  return { chunks: touched, removed };
}

/**
 * Fills a sphere with solid material (collapse rubble, ADD §64). Mirror of carveSphere.
 * @returns {{chunks:Set<object>}}
 */
export function fillSphere(field, c, r, material) {
  const { N, voxel } = field;
  const touched = new Set();
  const g0 = [0, 1, 2].map((a) => Math.floor((c[a] - r - 1) / voxel));
  const g1 = [0, 1, 2].map((a) => Math.ceil((c[a] + r + 1) / voxel));
  const cMin = g0.map((g) => Math.floor(g / N) - 1), cMax = g1.map((g) => Math.floor(g / N) + 1);
  for (let cz = cMin[2]; cz <= cMax[2]; cz++) for (let cy = cMin[1]; cy <= cMax[1]; cy++) for (let cx = cMin[0]; cx <= cMax[0]; cx++) {
    const ch = field.chunks.get(chunkKey(cx, cy, cz));
    if (!ch) continue;
    const ox = cx * N, oy = cy * N, oz = cz * N;
    const lo = [Math.max(-1, g0[0] - ox), Math.max(-1, g0[1] - oy), Math.max(-1, g0[2] - oz)];
    const hi = [Math.min(N, g1[0] - ox), Math.min(N, g1[1] - oy), Math.min(N, g1[2] - oz)];
    if (lo[0] > hi[0] || lo[1] > hi[1] || lo[2] > hi[2]) continue;
    let changed = false;
    for (let k = lo[2]; k <= hi[2]; k++) for (let j = lo[1]; j <= hi[1]; j++) for (let i = lo[0]; i <= hi[0]; i++) {
      const x = (ox + i) * voxel, y = (oy + j) * voxel, z = (oz + k) * voxel;
      const inside = r - Math.hypot(x - c[0], y - c[1], z - c[2]); // positive inside the sphere
      const idx = sampleIndex(N, i, j, k);
      if (inside > ch.density[idx]) {
        if (ch.density[idx] <= 0 && inside > 0) ch.material[idx] = material;
        ch.density[idx] = inside;
        if (ch.cutTime) ch.cutTime[idx] = 0;
        changed = true;
      }
    }
    if (changed) { ch.version++; touched.add(ch); }
  }
  return { chunks: touched };
}
