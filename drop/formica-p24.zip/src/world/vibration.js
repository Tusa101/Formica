// Vibration propagation (ADD §69): strength falls with distance and with what lies between source and listener —
// dense rock carries it, sand damps it, air gaps damp it strongly. Pure JS.
import { MATERIALS, AIR_VIBRATION } from '../data/materials.js';

export const VIBRATION = Object.freeze({
  bite: { mandibles: 0.6, vibropick: 2.0 }, collapse: 8, step: 0.1, run: 0.2,
  falloff: 4,        // geometric falloff distance scale (units)
  sample: 0.5,       // path sampling step (units)
  sense: 0.08,       // weakest vibration a listener notices
});

/** Received strength at `to` from a source of `strength` at `from`. */
export function receivedVibration(field, from, to, strength) {
  const d = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]);
  if (d < 1e-3) return strength;
  const geom = 1 / Math.pow(1 + d / VIBRATION.falloff, 1.5);
  const steps = Math.max(1, Math.ceil(d / VIBRATION.sample)), ds = d / steps;
  let t = 1;
  for (let s = 1; s < steps; s++) {
    const k = s / steps;
    const x = from[0] + (to[0] - from[0]) * k, y = from[1] + (to[1] - from[1]) * k, z = from[2] + (to[2] - from[2]) * k;
    const dens = field.densityAt(x, y, z);
    const f = dens > 0 ? (MATERIALS[field.materialAt(x, y, z)]?.vibration ?? 0.95) : AIR_VIBRATION;
    t *= Math.pow(f, ds);
    if (t < 1e-4) return 0;
  }
  return strength * geom * t;
}

/** Collects vibration events each frame and lets listeners query what reached them. */
export class VibrationBus {
  constructor(field) { this.field = field; this.events = []; }
  emit(pos, strength, source = 'world', freq = 1) { this.events.push({ pos: pos.slice(), strength, source, freq }); }
  /** Strongest event felt at `p` this frame (optionally ignoring a source), with direction. */
  feel(p, ignore = null) {
    let best = null;
    for (const e of this.events) {
      if (ignore && e.source === ignore) continue;
      const r = receivedVibration(this.field, e.pos, p, e.strength);
      if (r >= VIBRATION.sense && (!best || r > best.received)) best = { ...e, received: r };
    }
    return best;
  }
  /** Every event felt at `p` this frame (optionally ignoring a source). */
  feelAll(p, ignore = null) {
    const out = [];
    for (const e of this.events) {
      if (ignore && e.source === ignore) continue;
      const r = receivedVibration(this.field, e.pos, p, e.strength);
      if (r >= VIBRATION.sense) out.push({ ...e, received: r });
    }
    return out;
  }
  clear() { this.events.length = 0; }
}
