// Small promise-based worker pool.
export class WorkerPool {
  constructor(url, size) {
    this.workers = [];
    this.idle = [];
    this.queue = [];
    this.pending = new Map();
    this.nextId = 1;
    for (let i = 0; i < size; i++) {
      const w = new Worker(url, { type: 'module' });
      w.onmessage = (e) => this._done(w, e.data);
      w.onerror = (e) => { const msg = `Worker error: ${e.message || 'failed to start'}`; e.preventDefault?.(); this._failAll(msg); };
      this.workers.push(w); this.idle.push(w);
    }
  }

  run(job, transfer = []) {
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      this.pending.set(id, { resolve, reject });
      this.queue.push({ msg: { ...job, id }, transfer });
      this._pump();
    });
  }

  _pump() {
    while (this.idle.length && this.queue.length) {
      const w = this.idle.pop(); const j = this.queue.shift();
      w.postMessage(j.msg, j.transfer);
    }
  }

  _done(w, data) {
    const p = this.pending.get(data.id);
    this.pending.delete(data.id);
    this.idle.push(w);
    this._pump();
    if (!p) return;
    if (data.ok) p.resolve(data); else p.reject(new Error(data.error));
  }

  _failAll(msg) {
    for (const p of this.pending.values()) p.reject(new Error(msg));
    this.pending.clear(); this.queue.length = 0;
  }

  dispose() { for (const w of this.workers) w.terminate(); }
}
