// Region graph (ADD §43–44): the NavGrid split into blocks; a node is a connected piece of open cells inside one block.
// Coarse enough for maps, zone distances and hierarchical navigation. Pure JS.
import { MinHeap } from './navgrid.js';

const N6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

export class RegionGraph {
  constructor(nav, block = 4) {
    this.nav = nav; this.block = block;
    this.nodeOf = new Int32Array(nav.count).fill(-1);
    this.nodes = [];
    this.adj = [];
    this.version = 0;
  }

  build() {
    const nav = this.nav, B = this.block, [X, Y, Z] = nav.dims;
    this.nodeOf.fill(-1); this.nodes = []; this.adj = [];
    const blockOf = (i, j, k) => `${Math.floor(i / B)},${Math.floor(j / B)},${Math.floor(k / B)}`;
    for (let idx = 0; idx < nav.count; idx++) {
      if (!nav.open[idx] || this.nodeOf[idx] >= 0) continue;
      const id = this.nodes.length;
      const [i0, j0, k0] = nav.coords(idx);
      const bi = Math.floor(i0 / B), bj = Math.floor(j0 / B), bk = Math.floor(k0 / B);
      const stack = [idx]; this.nodeOf[idx] = id;
      let n = 0; const sum = [0, 0, 0];
      while (stack.length) {
        const c = stack.pop(); n++;
        const p = nav.worldPos(c); sum[0] += p[0]; sum[1] += p[1]; sum[2] += p[2];
        const i = c % X, j = Math.floor(c / X) % Y, k = Math.floor(c / (X * Y));
        for (const [dx, dy, dz] of N6) {
          const a = i + dx, b = j + dy, cc = k + dz;
          if (a < 0 || b < 0 || cc < 0 || a >= X || b >= Y || cc >= Z) continue;
          if (Math.floor(a / B) !== bi || Math.floor(b / B) !== bj || Math.floor(cc / B) !== bk) continue;
          const nb = a + X * (b + Y * cc);
          if (nav.open[nb] && this.nodeOf[nb] < 0) { this.nodeOf[nb] = id; stack.push(nb); }
        }
      }
      this.nodes.push({ id, label: nav.label[idx], cells: n, pos: [sum[0] / n, sum[1] / n, sum[2] / n], block: blockOf(i0, j0, k0) });
      this.adj.push(new Map());
    }
    for (let idx = 0; idx < nav.count; idx++) {
      const u = this.nodeOf[idx];
      if (u < 0) continue;
      const i = idx % X, j = Math.floor(idx / X) % Y, k = Math.floor(idx / (X * Y));
      for (const [dx, dy, dz] of [[1, 0, 0], [0, 1, 0], [0, 0, 1]]) {
        const a = i + dx, b = j + dy, c = k + dz;
        if (a >= X || b >= Y || c >= Z) continue;
        const v = this.nodeOf[a + X * (b + Y * c)];
        if (v < 0 || v === u || this.adj[u].has(v)) continue;
        const w = Math.hypot(...[0, 1, 2].map((q) => this.nodes[u].pos[q] - this.nodes[v].pos[q]));
        this.adj[u].set(v, w); this.adj[v].set(u, w);
      }
    }
    this.version++;
    return this;
  }

  get edgeCount() { let e = 0; for (const m of this.adj) e += m.size; return e / 2; }

  nodeAt(p, radius = 4) {
    const c = this.nav.nearestOpen(p, radius);
    return c < 0 ? -1 : this.nodeOf[c];
  }

  /** Dijkstra from one node; returns a Float64Array of path lengths (Infinity = unreachable). */
  distancesFrom(src) {
    const n = this.nodes.length, dist = new Float64Array(n).fill(Infinity);
    if (src < 0) return dist;
    dist[src] = 0;
    const done = new Uint8Array(n);
    const heap = new MinHeap();
    heap.push(src, 0);
    while (heap.size) {
      const u = heap.pop();
      if (done[u]) continue;
      done[u] = 1;
      for (const [v, w] of this.adj[u]) {
        const nd = dist[u] + w;
        if (nd < dist[v]) { dist[v] = nd; heap.push(v, nd); }
      }
    }
    return dist;
  }
}
