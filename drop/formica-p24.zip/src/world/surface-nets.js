// Naive Surface Nets mesher for one chunk (ADD §39 — simple first mesher; Dual Contouring later for concrete).
// Input: (N+2)^3 samples with a 1-sample halo (see field.js). Output: indexed world-space buffers.
// A chunk owns every sign-changing edge whose start sample lies in [0, N)^3 → seamless borders.
import { sampleIndex } from './field.js';

const CORNER = [[0,0,0],[1,0,0],[0,1,0],[1,1,0],[0,0,1],[1,0,1],[0,1,1],[1,1,1]];
const EDGES = [[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]];
// For an edge along axis a starting at sample `base`, the 4 cells around it: base - u - v, base - v, base, base - u.
const QUAD = [
  [[0,-1,-1],[0,0,-1],[0,0,0],[0,-1,0]], // x edges (u = y, v = z)
  [[-1,0,-1],[-1,0,0],[0,0,0],[0,0,-1]], // y edges (u = z, v = x)
  [[-1,-1,0],[0,-1,0],[0,0,0],[-1,0,0]], // z edges (u = x, v = y)
];

export function meshChunk(density, material, N, voxel, cx, cy, cz, nMaterials = 4, cutTime = null) {
  const C = N + 1; // cells per axis: -1..N-1
  const cellVert = new Int32Array(C * C * C).fill(-1);
  const pos = [], nor = [], matw = [], cut = [], idx = [];
  const ox = cx * N, oy = cy * N, oz = cz * N;
  const d = new Float32Array(8);
  const m = new Uint8Array(8);
  const ct = new Float32Array(8);
  const w = new Float32Array(nMaterials);

  function vertexOf(i, j, k) {
    const ci = (i + 1) + C * ((j + 1) + C * (k + 1));
    const cached = cellVert[ci];
    if (cached >= 0) return cached;
    let mask = 0;
    for (let c = 0; c < 8; c++) {
      const s = sampleIndex(N, i + CORNER[c][0], j + CORNER[c][1], k + CORNER[c][2]);
      d[c] = density[s]; m[c] = material[s]; ct[c] = cutTime ? cutTime[s] : 0;
      if (d[c] > 0) mask |= 1 << c;
    }
    let px = 0, py = 0, pz = 0, cnt = 0;
    for (const [a, b] of EDGES) {
      const sa = d[a] > 0, sb = d[b] > 0;
      if (sa === sb) continue;
      const t = d[a] / (d[a] - d[b]);
      px += CORNER[a][0] + (CORNER[b][0] - CORNER[a][0]) * t;
      py += CORNER[a][1] + (CORNER[b][1] - CORNER[a][1]) * t;
      pz += CORNER[a][2] + (CORNER[b][2] - CORNER[a][2]) * t;
      cnt++;
    }
    if (cnt === 0) { px = py = pz = 0.5; cnt = 1; } // cannot happen for referenced cells; keep safe
    const v = pos.length / 3;
    pos.push((ox + i + px / cnt) * voxel, (oy + j + py / cnt) * voxel, (oz + k + pz / cnt) * voxel);
    // Gradient over the cell; normal points toward empty space (decreasing density).
    const gx = d[1] + d[3] + d[5] + d[7] - d[0] - d[2] - d[4] - d[6];
    const gy = d[2] + d[3] + d[6] + d[7] - d[0] - d[1] - d[4] - d[5];
    const gz = d[4] + d[5] + d[6] + d[7] - d[0] - d[1] - d[2] - d[3];
    const len = Math.hypot(gx, gy, gz) || 1;
    nor.push(-gx / len, -gy / len, -gz / len);
    w.fill(0);
    let ws = 0;
    for (let c = 0; c < 8; c++) if (d[c] > 0) { const ww = Math.min(d[c], 1) + 0.05; w[m[c]] += ww; ws += ww; }
    if (ws === 0) { w[0] = 1; ws = 1; }
    for (let q = 0; q < nMaterials; q++) matw.push(w[q] / ws);
    let cutMax = 0;
    if (cutTime) for (let c = 0; c < 8; c++) if (d[c] > 0 && ct[c] > cutMax) cutMax = ct[c];
    cut.push(cutMax);
    cellVert[ci] = v;
    return v;
  }

  for (let k = 0; k < N; k++) {
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) {
        const d0 = density[sampleIndex(N, i, j, k)];
        const s0 = d0 > 0;
        for (let a = 0; a < 3; a++) {
          const d1 = density[sampleIndex(N, i + (a === 0), j + (a === 1), k + (a === 2))];
          if (s0 === (d1 > 0)) continue;
          const q = QUAD[a];
          const v0 = vertexOf(i + q[0][0], j + q[0][1], k + q[0][2]);
          const v1 = vertexOf(i + q[1][0], j + q[1][1], k + q[1][2]);
          const v2 = vertexOf(i + q[2][0], j + q[2][1], k + q[2][2]);
          const v3 = vertexOf(i + q[3][0], j + q[3][1], k + q[3][2]);
          if (s0) idx.push(v0, v1, v2, v0, v2, v3);
          else idx.push(v0, v2, v1, v0, v3, v2);
        }
      }
    }
  }

  const vCount = pos.length / 3;
  return {
    positions: new Float32Array(pos),
    normals: new Float32Array(nor),
    matw: new Float32Array(matw),
    cut: new Float32Array(cut),
    indices: vCount > 65535 ? new Uint32Array(idx) : new Uint16Array(idx),
    vertexCount: vCount,
    triangleCount: idx.length / 3,
  };
}
