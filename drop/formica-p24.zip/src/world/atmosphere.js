// Air and scent on the cavity graph (ADD §66, §68): values live on open NavGrid cells and only flow between
// neighbouring open cells, so rock blocks them and every dug opening immediately becomes a channel. Pure JS.

const FIELDS = ['o2', 'co2', 'tox'];

export class Atmosphere {
  /**
   * @param {import('./navgrid.js').NavGrid} nav
   * @param {{zones?:Array, vents?:Array}} air   level.air
   * @param {(p:number[])=>string|null} zoneAt  zone name at a world point
   */
  constructor(nav, air = {}, zoneAt = () => null, opts = {}) {
    this.nav = nav;
    const n = nav.count;
    this.o2 = new Float32Array(n); this.co2 = new Float32Array(n); this.tox = new Float32Array(n);
    this.known = new Uint8Array(n);          // cell has air values (was open when last seen)
    this.scent = new Map();                  // owner → Float32Array
    this.crumbs = new Map();                 // owner → [{p, t}] breadcrumb trail (direction/history)
    this.air = air; this.zoneAt = zoneAt;
    this.airRate = opts.airRate ?? 0.15;     // exchange fraction per step between neighbours
    this.scentRate = opts.scentRate ?? 0.005;
    this.scentHalfLife = opts.scentHalfLife ?? 90;
    this.step = opts.step ?? 0.05;
    this.acc = 0; this.time = 0;
    this.open = [];
    this.dirty = true;
  }

  /** Initial atmosphere: normal air everywhere, level zones override. */
  init() {
    const nav = this.nav, zones = this.air.zones || [];
    for (let i = 0; i < nav.count; i++) {
      if (!nav.open[i]) continue;
      const z = zones.length ? this.zoneAt(nav.worldPos(i)) : null;
      const zd = z && zones.find((q) => q.zone === z);
      this.o2[i] = zd ? zd.o2 : 1; this.co2[i] = zd ? zd.co2 : 0; this.tox[i] = zd ? zd.tox ?? 0 : 0;
      this.known[i] = 1;
    }
    this.vents = (this.air.vents || []).map((v) => this._cellsNear(v.pos, v.radius));
    this.seeps = (this.air.seeps || []).map((v) => ({ cells: this._cellsNear(v.pos, v.radius), co2: v.co2 ?? 0.05, o2: v.o2 ?? 0.03 }));
    this.refresh();
  }

  _cellsNear(p, r) {
    const nav = this.nav, out = [];
    const c = nav.cellAt(p);
    if (c < 0) return out;
    const [i0, j0, k0] = nav.coords(c), R = Math.ceil(r / nav.cell);
    for (let k = k0 - R; k <= k0 + R; k++) for (let j = j0 - R; j <= j0 + R; j++) for (let i = i0 - R; i <= i0 + R; i++) {
      if (i < 0 || j < 0 || k < 0 || i >= nav.dims[0] || j >= nav.dims[1] || k >= nav.dims[2]) continue;
      out.push(nav.index(i, j, k));
    }
    return out;
  }

  /** Rebuilds the open-cell list; newly opened cells inherit the air of their open neighbours. */
  refresh() {
    const nav = this.nav, [X, Y, Z] = nav.dims;
    const list = [];
    for (let i = 0; i < nav.count; i++) if (nav.open[i]) list.push(i);
    for (const i of list) {
      if (this.known[i]) continue;
      let n = 0, a = 0, b = 0, c = 0;
      for (const nb of this._neighbours(i, X, Y, Z)) if (nav.open[nb] && this.known[nb]) { a += this.o2[nb]; b += this.co2[nb]; c += this.tox[nb]; n++; }
      if (n) { this.o2[i] = a / n; this.co2[i] = b / n; this.tox[i] = c / n; } else { this.o2[i] = 1; this.co2[i] = 0; this.tox[i] = 0; }
      this.known[i] = 1;
    }
    for (let i = 0; i < nav.count; i++) if (!nav.open[i] && this.known[i]) {
      this.known[i] = 0; this.o2[i] = 0; this.co2[i] = 0; this.tox[i] = 0;
      for (const s of this.scent.values()) s[i] = 0;
    }
    this.open = list;
    this.dirty = false;
  }

  *_neighbours(i, X, Y, Z) {
    const x = i % X, y = Math.floor(i / X) % Y, z = Math.floor(i / (X * Y));
    if (x + 1 < X) yield i + 1; if (x > 0) yield i - 1;
    if (y + 1 < Y) yield i + X; if (y > 0) yield i - X;
    if (z + 1 < Z) yield i + X * Y; if (z > 0) yield i - X * Y;
  }

  markDirty() { this.dirty = true; }

  /** Dynamic fresh-air sources (processors, pipes, camps): [{pos, radius}]. */
  setSources(list) {
    this._srcCache = this._srcCache || new Map();
    this.sources = list.map((s) => {
      const key = `${s.pos.map((v) => v.toFixed(1)).join(',')}:${s.radius}`;
      if (!this._srcCache.has(key)) this._srcCache.set(key, this._cellsNear(s.pos, s.radius).filter((c) => Math.hypot(...this.nav.worldPos(c).map((v, i) => v - s.pos[i])) <= s.radius));
      return this._srcCache.get(key);
    });
  }

  _diffuse(arr, rate) {
    const nav = this.nav, [X, Y] = nav.dims, XY = X * Y;
    for (const i of this.open) {
      const x = i % X, y = Math.floor(i / X) % Y;
      // exchange with the +x, +y, +z neighbours only → each pair once, mass conserved
      if (x + 1 < X && nav.open[i + 1]) { const f = (arr[i] - arr[i + 1]) * rate; arr[i] -= f; arr[i + 1] += f; }
      if (y + 1 < Y && nav.open[i + X]) { const f = (arr[i] - arr[i + X]) * rate; arr[i] -= f; arr[i + X] += f; }
      const k = i + XY;
      if (k < nav.count && nav.open[k]) { const f = (arr[i] - arr[k]) * rate; arr[i] -= f; arr[k] += f; }
    }
  }

  update(dt) {
    if (this.dirty) this.refresh();
    this.acc += dt;
    while (this.acc >= this.step) {
      this.acc -= this.step; this.time += this.step;
      for (const f of FIELDS) this._diffuse(this[f], this.airRate);
      for (const cells of this.vents || []) for (const c of cells) if (this.nav.open[c]) { this.o2[c] = 1; this.co2[c] = 0; this.tox[c] = 0; }
      // geological seeps keep leaking CO₂ (per second rates)
      for (const sp of this.seeps || []) for (const c of sp.cells) if (this.nav.open[c]) {
        this.co2[c] = Math.min(1, this.co2[c] + sp.co2 * this.step); this.o2[c] = Math.max(0, this.o2[c] - sp.o2 * this.step);
      }
      // network sources scrub gradually rather than instantly (a processor is not a hole to the surface)
      for (const cells of this.sources || []) for (const c of cells) if (this.nav.open[c]) {
        this.o2[c] += (1 - this.o2[c]) * 0.25; this.co2[c] *= 0.75; this.tox[c] *= 0.75;
      }
      const decay = Math.pow(0.5, this.step / this.scentHalfLife);
      for (const s of this.scent.values()) {
        this._diffuse(s, this.scentRate);
        for (const i of this.open) s[i] *= decay;
      }
    }
  }

  /** Breathing / burning consumes oxygen and produces CO₂ at a point. */
  consume(p, amount) {
    const c = this.nav.nearestOpen(p, 2);
    if (c < 0) return;
    const d = Math.min(this.o2[c], amount);
    this.o2[c] -= d; this.co2[c] = Math.min(1, this.co2[c] + d * 0.8);
  }

  /** Air quality 0..1 at a world point (1 = normal air). */
  quality(p) {
    const c = this.nav.nearestOpen(p, 2);
    if (c < 0) return 1;
    return this.cellQuality(c);
  }
  cellQuality(c) { return Math.max(0, Math.min(1, this.o2[c] - 0.8 * this.co2[c] - 1.2 * this.tox[c])); }

  scentOf(owner) {
    if (!this.scent.has(owner)) { this.scent.set(owner, new Float32Array(this.nav.count)); this.crumbs.set(owner, []); }
    return this.scent.get(owner);
  }

  /** Leaves scent at a point; every ~1 unit also drops a breadcrumb (time-stamped, gives trail direction). */
  deposit(owner, p, amount) {
    const s = this.scentOf(owner);
    const c = this.nav.nearestOpen(p, 2);
    if (c >= 0) s[c] = Math.min(1, s[c] + amount);
    const cr = this.crumbs.get(owner);
    const last = cr[cr.length - 1];
    if (!last || Math.hypot(last.p[0] - p[0], last.p[1] - p[1], last.p[2] - p[2]) > 1) {
      cr.push({ p: p.slice(), t: this.time });
      if (cr.length > 2000) cr.shift();
    }
  }

  scentAt(owner, p) { const c = this.nav.nearestOpen(p, 2); return c < 0 ? 0 : this.scentOf(owner)[c]; }

  totalO2() { let t = 0; for (const i of this.open) t += this.o2[i]; return t; }
}
