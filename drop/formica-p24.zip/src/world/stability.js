// Structural stability (ADD §55–65). Pure JS. Works on the NavGrid: a "roof" is a solid cell with open space below it.
// S = (max(0, raw − equilibrium) + fatigue·thin + damage) × (1 − supportRelief)
// raw = span / spanLimit(material) + thinLayerPenalty.
import { STRUCTURE as P } from '../data/structure.js';
import { MATERIALS } from '../data/materials.js';

export const State = Object.freeze({ STABLE: 0, STRESSED: 1, FRACTURED: 2, CRITICAL: 3 });
const DIRS = [[1, 0], [0, 1], [1, 1], [1, -1]];

export class Stability {
  /** @param {{materialAt(x,y,z):number}} field  @param {import('./navgrid.js').NavGrid} nav */
  constructor(field, nav) {
    this.field = field; this.nav = nav;
    const n = nav.count;
    this.S = new Float32Array(n);
    this.base = new Float32Array(n).fill(NaN);
    this.timer = new Float32Array(n);
    this.fatigue = new Float32Array(n);
    this.damage = new Float32Array(n);
    this.info = new Map(); // idx → {span, thin, thickness, raw}
    this.roofs = [];
    this.roofDirty = true;
    this.active = new Set();
    this.urgent = new Set();
    this.rr = 0;
    this.supports = [];
    this.stats = { evals: 0, collapses: 0 };
  }

  isRoof(idx) {
    const nav = this.nav, X = nav.dims[0], Y = nav.dims[1];
    if (nav.open[idx]) return false;
    const j = Math.floor(idx / X) % Y;
    return j > 0 && nav.open[idx - X] === 1;
  }

  refreshRoofs() {
    const nav = this.nav, X = nav.dims[0];
    const list = [];
    for (let idx = X; idx < nav.count; idx++) if (!nav.open[idx] && nav.open[idx - X] && Math.floor(idx / X) % nav.dims[1] > 0) list.push(idx);
    this.roofs = list;
    this.roofDirty = false;
    // new roof cells inherit the equilibrium of settled neighbours (natural caves stay settled)
    for (const idx of list) if (Number.isNaN(this.base[idx])) this.base[idx] = this._inherit(idx);
  }

  _inherit(idx) {
    const nav = this.nav, [X, Y, Z] = nav.dims;
    const [i, j, k] = nav.coords(idx);
    let best = 0;
    for (let dz = -2; dz <= 2; dz++) for (let dy = -1; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
      const a = i + dx, b = j + dy, c = k + dz;
      if (a < 0 || b < 0 || c < 0 || a >= X || b >= Y || c >= Z) continue;
      const v = this.base[a + X * (b + Y * c)];
      if (v > best) best = v;
    }
    return best;
  }

  /** Records the natural equilibrium of every roof (call once after the world is loaded). */
  build() {
    this.refreshRoofs();
    for (const idx of this.roofs) { const r = this._raw(idx); this.base[idx] = r.raw; this.S[idx] = 0; }
  }

  _supportRelief(p) {
    let best = 0;
    for (const s of this.supports) {
      const lo = Math.min(s.a[1], s.b[1]) - 1.2, hi = Math.max(s.a[1], s.b[1]) + 1.2;
      if (p[1] < lo || p[1] > hi) continue;
      const cx = (s.a[0] + s.b[0]) / 2, cz = (s.a[2] + s.b[2]) / 2;
      const d = Math.hypot(p[0] - cx, p[2] - cz);
      if (d < P.supportRadius) best = Math.max(best, 1 - (d / P.supportRadius) ** 2);
    }
    return best * P.supportRelief;
  }

  _blockedBySupport(p) {
    for (const s of this.supports) {
      const lo = Math.min(s.a[1], s.b[1]) - 0.5, hi = Math.max(s.a[1], s.b[1]) + 0.5;
      if (p[1] < lo || p[1] > hi) continue;
      if (Math.hypot(p[0] - (s.a[0] + s.b[0]) / 2, p[2] - (s.a[2] + s.b[2]) / 2) < 0.3 + this.nav.cell * 0.75) return true;
    }
    return false;
  }

  /** Raw geometric stress of a roof cell (before equilibrium, fatigue and supports). */
  _raw(idx) {
    const nav = this.nav, [X, Y, Z] = nav.dims, cell = nav.cell;
    const [i, j, k] = nav.coords(idx);
    const lj = j - 1; // the open layer below the roof
    const maxSteps = Math.ceil(P.maxRay / cell);
    let span = Infinity;
    for (const [dx, dz] of DIRS) {
      const len = Math.hypot(dx, dz) * cell;
      let w = cell;
      for (const sgn of [1, -1]) {
        for (let s = 1; s <= maxSteps; s++) {
          const a = i + dx * s * sgn, c = k + dz * s * sgn;
          if (a < 0 || c < 0 || a >= X || c >= Z) break;
          const nb = a + X * (lj + Y * c);
          if (!nav.open[nb]) break;
          if (this.supports.length && this._blockedBySupport(nav.worldPos(nb))) break;
          w += len;
        }
      }
      span = Math.min(span, w);
    }
    // thickness of rock above the roof until the next cavity
    let thickness = Infinity;
    const up = Math.ceil(P.thinLayer / cell) + 1;
    for (let s = 1; s <= up && j + s < Y; s++) {
      if (nav.open[i + X * (j + s + Y * k)]) { thickness = s * cell; break; }
    }
    const thin = thickness < P.thinLayer;
    const p = nav.worldPos(idx);
    const m = MATERIALS[this.field.materialAt(p[0], p[1] - cell * 0.4, p[2])] || MATERIALS[1];
    const limit = P.spanBase + P.spanPerStrength * m.stability;
    const raw = span / limit + (thin ? P.thinWeight * (1 - thickness / P.thinLayer) : 0);
    return { raw, span, thin, thickness, material: m.id };
  }

  evaluate(idx) {
    if (!this.isRoof(idx)) {
      this.S[idx] = 0; this.timer[idx] = 0; this.info.delete(idx);
      if (!this.fatigue[idx] && !this.damage[idx]) this.active.delete(idx);
      return 0;
    }
    if (Number.isNaN(this.base[idx])) this.base[idx] = this._inherit(idx);
    const r = this._raw(idx);
    const relief = this.supports.length ? this._supportRelief(this.nav.worldPos(idx)) : 0;
    const s = (Math.max(0, r.raw - this.base[idx]) + this.fatigue[idx] * (r.thin ? 1 : 0.25) + this.damage[idx]) * (1 - relief);
    this.S[idx] = s;
    this.info.set(idx, r);
    if (s >= P.stressed || this.timer[idx] > 0 || this.fatigue[idx] > 0 || this.damage[idx] > 0) this.active.add(idx);
    else this.active.delete(idx);
    this.stats.evals++;
    return s;
  }

  state(idx) {
    const s = this.S[idx], t = this.timer[idx];
    if (s >= P.failure || t > 0) return t >= 0.5 ? State.CRITICAL : State.FRACTURED;
    return s >= P.stressed ? State.STRESSED : State.STABLE;
  }

  _box(center, r, fn) {
    const nav = this.nav, [X, Y, Z] = nav.dims, cell = nav.cell;
    const lo = [0, 1, 2].map((a) => Math.max(0, Math.floor(((center[a] - r) / this.field.voxel - nav.g0[a]) / nav.step)));
    const hi = [0, 1, 2].map((a) => Math.min(nav.dims[a] - 1, Math.floor(((center[a] + r) / this.field.voxel - nav.g0[a]) / nav.step)));
    for (let k = lo[2]; k <= hi[2]; k++) for (let j = lo[1]; j <= hi[1]; j++) for (let i = lo[0]; i <= hi[0]; i++) fn(i + X * (j + Y * k), cell);
  }

  /** Terrain changed (the NavGrid must already be updated). Bites also damage nearby roofs slightly. */
  onEdit(center, r, { bite = false } = {}) {
    this.roofDirty = true;
    this._box(center, r + P.maxRay * 0.5, (idx) => { if (this.isRoof(idx) || this.active.has(idx)) this.urgent.add(idx); });
    if (bite) this._box(center, 2, (idx) => {
      if (!this.isRoof(idx)) return;
      this.damage[idx] = Math.min(P.damageMax, this.damage[idx] + P.damagePerBite);
      this.active.add(idx); this.urgent.add(idx);
    });
  }

  /** Strong vibration (vibro pick, collapse) shakes nearby roofs (ADD §55 Vibration term). */
  addVibration(pos, strength) {
    if (strength < 1) return;
    const r = Math.min(8, strength * 1.2);
    this._box(pos, r, (idx) => {
      if (!this.isRoof(idx)) return;
      const p = this.nav.worldPos(idx);
      const d = Math.hypot(p[0] - pos[0], p[1] - pos[1], p[2] - pos[2]);
      if (d > r) return;
      this.damage[idx] = Math.min(P.damageMax, this.damage[idx] + 0.015 * strength * (1 - d / r));
      this.active.add(idx); this.urgent.add(idx);
    });
  }

  /** Something walked at `pos` (feet); loads the roof directly beneath, if any. */
  addTraffic(pos, dt, weight = 1) {
    const nav = this.nav, X = nav.dims[0];
    let idx = nav.cellAt(pos);
    if (idx < 0) return;
    for (let s = 0; s < 5 && idx >= X; s++, idx -= X) {
      if (nav.open[idx]) continue;
      if (nav.open[idx - X]) {
        this.fatigue[idx] = Math.min(P.fatigueMax, this.fatigue[idx] + P.fatiguePerSecond * dt * weight);
        this.active.add(idx); this.urgent.add(idx);
        return;
      }
    }
  }

  addSupport(a, b) {
    this.supports.push({ a: a.slice(), b: b.slice() });
    const c = a.map((v, i) => (v + b[i]) / 2);
    this._box(c, P.maxRay * 0.5, (idx) => { if (this.isRoof(idx)) this.urgent.add(idx); });
  }

  /**
   * @returns {Array<{idx:number, pos:number[], S:number, info:object}>} roofs that failed this step
   */
  update(dt, focus) {
    if (this.roofDirty) this.refreshRoofs();
    let budget = P.evalPerFrame;
    for (const idx of this.urgent) { this.urgent.delete(idx); this.evaluate(idx); if (--budget <= 0) break; }
    const r2 = P.evalRadius * P.evalRadius;
    for (let n = 0; n < this.roofs.length && budget > 0; n++) {
      this.rr = (this.rr + 1) % this.roofs.length;
      const idx = this.roofs[this.rr];
      const p = this.nav.worldPos(idx);
      if (focus && (p[0] - focus[0]) ** 2 + (p[1] - focus[1]) ** 2 + (p[2] - focus[2]) ** 2 > r2) continue;
      this.evaluate(idx); budget--;
    }
    const failed = [];
    for (const idx of this.active) {
      if (this.fatigue[idx] > 0) this.fatigue[idx] = Math.max(0, this.fatigue[idx] - P.fatigueDecay * dt);
      if (this.damage[idx] > 0) this.damage[idx] = Math.max(0, this.damage[idx] - P.damageDecay * dt);
      const s = this.S[idx];
      if (s >= P.failure) {
        this.timer[idx] += (dt * s * s) / P.failTime;
        if (this.timer[idx] >= 1) failed.push({ idx, pos: this.nav.worldPos(idx), S: s, info: this.info.get(idx) || this._raw(idx) });
      } else if (this.timer[idx] > 0) this.timer[idx] = Math.max(0, this.timer[idx] - dt * P.recover);
    }
    // one collapse per step at most (the worst): the terrain change re-evaluates the neighbourhood anyway
    failed.sort((a, b) => b.S - a.S);
    return failed.slice(0, 1);
  }

  /** Terrain operations for a failed roof (ADD §64): break upward, rubble onto the floor below. */
  planCollapse(f) {
    const nav = this.nav, X = nav.dims[0], p = f.pos, info = f.info;
    const carve = info.thin
      ? { c: [p[0], p[1] + info.thickness / 2, p[2]], r: Math.max(0.95, info.thickness * 0.7 + 0.45) }
      : { c: [p[0], p[1] + 0.6, p[2]], r: Math.min(2.4, Math.max(1.0, info.span * 0.22)) };
    let idx = f.idx - X, drop = 0;
    while (idx >= X && nav.open[idx] && drop < 16) { idx -= X; drop++; }
    const floorY = p[1] - (drop + 1) * nav.cell + nav.cell * 0.5;
    const fill = { c: [p[0], floorY, p[2]], r: Math.min(2.0, Math.max(0.9, info.span * 0.25)), material: info.material };
    return { carve, fill };
  }

  /** After a collapse the surrounding rock re-arches: roofs nearby settle at their new stress. */
  settle(center, r) {
    this.roofDirty = true;
    this.refreshRoofs();
    this._box(center, r, (idx) => {
      this.timer[idx] = 0; this.fatigue[idx] = 0; this.damage[idx] = 0;
      if (this.isRoof(idx)) { this.base[idx] = this._raw(idx).raw; this.evaluate(idx); }
    });
    this.stats.collapses++;
  }

  /** Up to n stress sources near `focus` for rendering (cracks, sag, dust). */
  sources(focus, n = 8, radius = 22, minSep = 1.8) {
    const c = [];
    for (const idx of this.active) {
      const st = this.state(idx);
      if (st === State.STABLE) continue;
      const p = this.nav.worldPos(idx);
      const d = Math.hypot(p[0] - focus[0], p[1] - focus[1], p[2] - focus[2]);
      if (d > radius) continue;
      c.push({ idx, pos: p, level: Math.min(1, (this.S[idx] - P.stressed) / (P.failure - P.stressed) * 0.6 + this.timer[idx] * 0.4), state: st, d });
    }
    c.sort((a, b) => b.state - a.state || b.level - a.level || a.d - b.d);
    const out = [];
    for (const s of c) {
      if (out.every((o) => Math.hypot(o.pos[0] - s.pos[0], o.pos[1] - s.pos[1], o.pos[2] - s.pos[2]) > minSep)) out.push(s);
      if (out.length >= n) break;
    }
    return out;
  }
}
