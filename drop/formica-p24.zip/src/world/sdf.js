// Signed-distance primitives for cavities (negative inside the empty space).

export function sdEllipsoid(px, py, pz, c, r) {
  const x = px - c[0], y = py - c[1], z = pz - c[2];
  const k0 = Math.hypot(x / r[0], y / r[1], z / r[2]);
  const k1 = Math.hypot(x / (r[0] * r[0]), y / (r[1] * r[1]), z / (r[2] * r[2]));
  return k1 === 0 ? -Math.min(r[0], r[1], r[2]) : (k0 * (k0 - 1)) / k1;
}

export function sdCapsule(px, py, pz, a, b, r) {
  const pax = px - a[0], pay = py - a[1], paz = pz - a[2];
  const bax = b[0] - a[0], bay = b[1] - a[1], baz = b[2] - a[2];
  const bb = bax * bax + bay * bay + baz * baz;
  let h = bb === 0 ? 0 : (pax * bax + pay * bay + paz * baz) / bb;
  h = h < 0 ? 0 : h > 1 ? 1 : h;
  return Math.hypot(pax - bax * h, pay - bay * h, paz - baz * h) - r;
}

/** Polynomial smooth minimum (k = blend radius). */
export function smin(a, b, k) {
  if (k <= 0) return Math.min(a, b);
  const h = Math.max(k - Math.abs(a - b), 0) / k;
  return Math.min(a, b) - h * h * k * 0.25;
}

/** Distance to one cavity description (data from levels/*.js). */
export function sdCavity(cav, x, y, z) {
  switch (cav.type) {
    case 'ellipsoid': return sdEllipsoid(x, y, z, cav.c, cav.r);
    case 'capsule': return sdCapsule(x, y, z, cav.a, cav.b, cav.r);
    case 'tube': {
      let d = Infinity;
      const pts = cav.points;
      for (let i = 0; i < pts.length - 1; i++) d = Math.min(d, sdCapsule(x, y, z, pts[i], pts[i + 1], cav.r));
      return d;
    }
    default: throw new Error('Unknown cavity type ' + cav.type);
  }
}

/** Padded axis-aligned bounds of a cavity — lets density evaluation skip far cavities. */
export function cavityBounds(cav, pad) {
  const pts = cav.type === 'ellipsoid' ? [cav.c] : cav.type === 'capsule' ? [cav.a, cav.b] : cav.points;
  const ext = cav.type === 'ellipsoid' ? Math.max(...cav.r) : cav.r;
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (const p of pts) for (let i = 0; i < 3; i++) { min[i] = Math.min(min[i], p[i] - ext - pad); max[i] = Math.max(max[i], p[i] + ext + pad); }
  return { min, max };
}
