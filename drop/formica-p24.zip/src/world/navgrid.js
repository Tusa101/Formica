// Navigation grid (ADD §33 gameplay/navigation layer, §45 clearance). Pure JS.
// A cell covers 2×2×2 density samples and is open when any of them is clearly empty (min density < −OPEN_MARGIN):
// thin passages such as the Squeeze stay connected even though they are narrower than a cell.
import { sampleIndex } from './field.js';

const OPEN_MARGIN = 0.2;
const N6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const N26 = [];
for (let z = -1; z <= 1; z++) for (let y = -1; y <= 1; y++) for (let x = -1; x <= 1; x++) if (x || y || z) N26.push([x, y, z, Math.hypot(x, y, z)]);

export class NavGrid {
  constructor(field, step = 2) {
    this.field = field; this.step = step;
    this.cell = field.voxel * step;
    this.g0 = field.gMin.slice();
    this.dims = [0, 1, 2].map((a) => Math.floor((field.gMax[a] - field.gMin[a]) / step));
    const [X, Y, Z] = this.dims;
    this.count = X * Y * Z;
    this.open = new Uint8Array(this.count);
    this.clear = new Float32Array(this.count); // −density: distance-ish to the nearest wall (for path costs)
    this.label = new Int32Array(this.count).fill(-1);
    this.sizes = new Map(); // label → cell count
    this.nextLabel = 0;
  }

  index(i, j, k) { return i + this.dims[0] * (j + this.dims[1] * k); }
  coords(idx) { const X = this.dims[0], Y = this.dims[1]; return [idx % X, Math.floor(idx / X) % Y, Math.floor(idx / (X * Y))]; }
  worldPos(idx) {
    const [i, j, k] = this.coords(idx), v = this.field.voxel, s = this.step, h = (s - 1) / 2;
    return [(this.g0[0] + i * s + h) * v, (this.g0[1] + j * s + h) * v, (this.g0[2] + k * s + h) * v];
  }
  cellAt(p) {
    const v = this.field.voxel, s = this.step;
    const c = [0, 1, 2].map((a) => Math.floor((p[a] / v - this.g0[a]) / s));
    if (c.some((x, a) => x < 0 || x >= this.dims[a])) return -1;
    return this.index(c[0], c[1], c[2]);
  }
  /** Nearest open cell to p (searching outward a few cells), or −1. */
  nearestOpen(p, radius = 3) {
    const c0 = this.cellAt(p);
    if (c0 >= 0 && this.open[c0]) return c0;
    const v = this.field.voxel, s = this.step;
    const base = [0, 1, 2].map((a) => Math.floor((p[a] / v - this.g0[a]) / s));
    let best = -1, bd = Infinity;
    for (let dz = -radius; dz <= radius; dz++) for (let dy = -radius; dy <= radius; dy++) for (let dx = -radius; dx <= radius; dx++) {
      const i = base[0] + dx, j = base[1] + dy, k = base[2] + dz;
      if (i < 0 || j < 0 || k < 0 || i >= this.dims[0] || j >= this.dims[1] || k >= this.dims[2]) continue;
      const idx = this.index(i, j, k);
      const d = dx * dx + dy * dy + dz * dz;
      if (this.open[idx] && d < bd) { bd = d; best = idx; }
    }
    return best;
  }

  /** Minimum density over the cell's samples. */
  _sample(idx) {
    const [i, j, k] = this.coords(idx), s = this.step;
    let m = Infinity;
    for (let c = 0; c < s * s * s; c++) {
      const d = this.field.sampleAt(this.g0[0] + i * s + (c % s), this.g0[1] + j * s + (Math.floor(c / s) % s), this.g0[2] + k * s + Math.floor(c / (s * s)));
      if (d < m) m = d;
    }
    return m;
  }

  build() {
    // fast path: walk each chunk's owned samples once and fold them into cells
    const minD = new Float32Array(this.count).fill(Infinity);
    const f = this.field, N = f.N, s = this.step, [X, Y] = this.dims;
    for (const ch of f.chunks.values()) {
      const ox = ch.cx * N - this.g0[0], oy = ch.cy * N - this.g0[1], oz = ch.cz * N - this.g0[2];
      for (let k = 0; k < N; k++) {
        const ck = Math.floor((oz + k) / s); if (ck < 0 || ck >= this.dims[2]) continue;
        for (let j = 0; j < N; j++) {
          const cj = Math.floor((oy + j) / s); if (cj < 0 || cj >= Y) continue;
          let si = sampleIndex(N, 0, j, k);
          for (let i = 0; i < N; i++, si++) {
            const ci = Math.floor((ox + i) / s); if (ci < 0 || ci >= X) continue;
            const idx = ci + X * (cj + Y * ck);
            const d = ch.density[si];
            if (d < minD[idx]) minD[idx] = d;
          }
        }
      }
    }
    for (let idx = 0; idx < this.count; idx++) {
      const d = minD[idx] === Infinity ? 3 : minD[idx];
      this.open[idx] = d < -OPEN_MARGIN ? 1 : 0;
      this.clear[idx] = -d;
    }
    this.relabel();
  }

  /** Full connected-component labelling (6-connectivity). */
  relabel() {
    this.label.fill(-1); this.sizes.clear(); this.nextLabel = 0;
    for (let idx = 0; idx < this.count; idx++) if (this.open[idx] && this.label[idx] < 0) this._flood(idx, this.nextLabel++);
  }

  _flood(start, lab) {
    const stack = [start]; this.label[start] = lab; let n = 0;
    const [X, Y, Z] = this.dims;
    while (stack.length) {
      const idx = stack.pop(); n++;
      const i = idx % X, j = Math.floor(idx / X) % Y, k = Math.floor(idx / (X * Y));
      for (const [dx, dy, dz] of N6) {
        const a = i + dx, b = j + dy, c = k + dz;
        if (a < 0 || b < 0 || c < 0 || a >= X || b >= Y || c >= Z) continue;
        const nb = a + X * (b + Y * c);
        if (this.open[nb] && this.label[nb] !== lab) { this.label[nb] = lab; stack.push(nb); }
      }
    }
    this.sizes.set(lab, n);
    return n;
  }

  /** Relabels the connected cells carrying label `from` (starting at `start`) as `to`. */
  _replace(start, from, to) {
    const [X, Y, Z] = this.dims;
    const stack = [start]; this.label[start] = to; let n = 0;
    while (stack.length) {
      const idx = stack.pop(); n++;
      const i = idx % X, j = Math.floor(idx / X) % Y, k = Math.floor(idx / (X * Y));
      for (const [dx, dy, dz] of N6) {
        const a = i + dx, b = j + dy, c = k + dz;
        if (a < 0 || b < 0 || c < 0 || a >= X || b >= Y || c >= Z) continue;
        const nb = a + X * (b + Y * c);
        if (this.label[nb] === from) { this.label[nb] = to; stack.push(nb); }
      }
    }
    return n;
  }

  /**
   * Re-samples cells inside a world-space box after a terrain edit.
   * @returns {{changed:boolean, opened:number[], closed:number[], merged:Array<[number,number]>}}
   */
  updateBox(min, max) {
    const v = this.field.voxel, s = this.step;
    const lo = [0, 1, 2].map((a) => Math.max(0, Math.floor((min[a] / v - this.g0[a]) / s)));
    const hi = [0, 1, 2].map((a) => Math.min(this.dims[a] - 1, Math.ceil((max[a] / v - this.g0[a]) / s)));
    const opened = [], closed = [];
    for (let k = lo[2]; k <= hi[2]; k++) for (let j = lo[1]; j <= hi[1]; j++) for (let i = lo[0]; i <= hi[0]; i++) {
      const idx = this.index(i, j, k);
      const d = this._sample(idx);
      this.clear[idx] = -d;
      const o = d < -OPEN_MARGIN ? 1 : 0;
      if (o === this.open[idx]) continue;
      this.open[idx] = o;
      (o ? opened : closed).push(idx);
    }
    const merged = [];
    if (closed.length) {
      // a closure may split a cavity — relabel everything (rare: collapses, P05)
      const before = this.sizes.size;
      this.relabel();
      return { changed: true, opened, closed, merged, split: this.sizes.size > before };
    }
    const [X, Y, Z] = this.dims;
    for (const idx of opened) {
      const i = idx % X, j = Math.floor(idx / X) % Y, k = Math.floor(idx / (X * Y));
      const labs = new Map(); // label → one neighbour cell carrying it
      for (const [dx, dy, dz] of N6) {
        const a = i + dx, b = j + dy, c = k + dz;
        if (a < 0 || b < 0 || c < 0 || a >= X || b >= Y || c >= Z) continue;
        const nb = a + X * (b + Y * c);
        if (this.open[nb] && this.label[nb] >= 0 && !labs.has(this.label[nb])) labs.set(this.label[nb], nb);
      }
      if (labs.size === 0) { this.label[idx] = this.nextLabel; this.sizes.set(this.nextLabel++, 1); continue; }
      const sorted = [...labs.keys()].sort((a, b) => (this.sizes.get(b) || 0) - (this.sizes.get(a) || 0));
      const keep = sorted[0];
      this.label[idx] = keep;
      this.sizes.set(keep, (this.sizes.get(keep) || 0) + 1);
      for (const other of sorted.slice(1)) {
        merged.push([keep, other]);
        const n = this._replace(labs.get(other), other, keep);
        this.sizes.set(keep, this.sizes.get(keep) + n);
        this.sizes.delete(other);
      }
    }
    return { changed: opened.length > 0, opened, closed, merged, split: false };
  }

  /**
   * A* over open cells (26-neighbours). Cost prefers cells near walls (crawlers hug surfaces).
   * @returns {number[]|null} cell indices from start to goal
   */
  findPath(startIdx, goalIdx, { hug = 0.6, maxExpand = 60000 } = {}) {
    if (startIdx < 0 || goalIdx < 0 || !this.open[startIdx] || !this.open[goalIdx]) return null;
    if (this.label[startIdx] !== this.label[goalIdx]) return null;
    const [X, Y, Z] = this.dims;
    const g = new Map([[startIdx, 0]]), came = new Map();
    const gc = this.coords(goalIdx);
    const h = (idx) => { const c = this.coords(idx); return Math.hypot(c[0] - gc[0], c[1] - gc[1], c[2] - gc[2]); };
    const heap = new MinHeap();
    heap.push(startIdx, h(startIdx));
    const closed = new Set();
    let expanded = 0;
    while (heap.size) {
      const cur = heap.pop();
      if (cur === goalIdx) {
        const path = [cur];
        let c = cur;
        while (came.has(c)) { c = came.get(c); path.push(c); }
        return path.reverse();
      }
      if (closed.has(cur)) continue;
      closed.add(cur);
      if (++expanded > maxExpand) return null;
      const i = cur % X, j = Math.floor(cur / X) % Y, k = Math.floor(cur / (X * Y));
      const gcur = g.get(cur);
      for (const [dx, dy, dz, len] of N26) {
        const a = i + dx, b = j + dy, c = k + dz;
        if (a < 0 || b < 0 || c < 0 || a >= X || b >= Y || c >= Z) continue;
        const nb = a + X * (b + Y * c);
        if (!this.open[nb] || closed.has(nb)) continue;
        const wall = Math.max(0, this.clear[nb] - 0.9); // far from any surface → extra cost
        const ng = gcur + len * (1 + hug * wall);
        if (ng < (g.get(nb) ?? Infinity)) { g.set(nb, ng); came.set(nb, cur); heap.push(nb, ng + h(nb)); }
      }
    }
    return null;
  }
}

export class MinHeap {
  constructor() { this.k = []; this.p = []; }
  get size() { return this.k.length; }
  push(key, pri) {
    const k = this.k, p = this.p; let i = k.length; k.push(key); p.push(pri);
    while (i > 0) { const par = (i - 1) >> 1; if (p[par] <= p[i]) break; [k[i], k[par]] = [k[par], k[i]]; [p[i], p[par]] = [p[par], p[i]]; i = par; }
  }
  pop() {
    const k = this.k, p = this.p; const top = k[0]; const lk = k.pop(), lp = p.pop();
    if (k.length) {
      k[0] = lk; p[0] = lp; let i = 0;
      for (;;) {
        const l = 2 * i + 1, r = l + 1; let m = i;
        if (l < k.length && p[l] < p[m]) m = l;
        if (r < k.length && p[r] < p[m]) m = r;
        if (m === i) break;
        [k[i], k[m]] = [k[m], k[i]]; [p[i], p[m]] = [p[m], p[i]]; i = m;
      }
    }
    return top;
  }
}
