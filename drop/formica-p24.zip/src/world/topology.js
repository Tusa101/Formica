// Topology manager (ADD §42–44, §76): turns terrain edits into connectivity changes and named events.
// Cheap local grid updates on every edit; region graph + zone distances rebuilt only when the grid changed.
import { NavGrid } from './navgrid.js';
import { RegionGraph } from './regions.js';

function zonePoint(c) {
  if (c.type === 'ellipsoid') return c.c;
  if (c.type === 'capsule') return c.a.map((v, i) => (v + c.b[i]) / 2);
  return c.points[Math.floor(c.points.length / 2)];
}

export class Topology {
  constructor(field, level, opts = {}) {
    this.nav = new NavGrid(field);
    this.graph = new RegionGraph(this.nav);
    this.zones = level.cavities.filter((c) => c.name).map((c) => ({ name: c.name, p: zonePoint(c) }));
    this.rebuildInterval = opts.rebuildInterval ?? 0.4;
    this.passageRatio = opts.passageRatio ?? 0.6;
    this.passageMin = opts.passageMin ?? 8;
    this.dirty = false; this.urgent = false; this._t = 0;
    this.lastEdit = null;
    this.version = 0;
    this.stats = { buildMs: 0, rebuilds: 0 };
  }

  build() {
    const t0 = performance.now();
    this.nav.build();
    this._rebuild();
    this.stats.buildMs = performance.now() - t0;
  }

  _rebuild() {
    this.graph.build();
    this.zoneNodes = this.zones.map((z) => this.graph.nodeAt(z.p));
    this.zoneDist = this.zoneNodes.map((n) => { const d = this.graph.distancesFrom(n); return this.zoneNodes.map((m) => (m < 0 ? Infinity : d[m])); });
    this.version++; this.stats.rebuilds++;
  }

  get cavityCount() { return this.nav.sizes.size; }

  /** Called by World after every terrain edit. */
  onEdit(center, r) {
    const pad = r + 1.0;
    const res = this.nav.updateBox(center.map((v) => v - pad), center.map((v) => v + pad));
    if (!res.changed) return;
    this.dirty = true;
    this.lastEdit = center.slice();
    if (res.merged.length || res.split) this.urgent = true;
  }

  /** @returns {Array<{type:'connected'|'passage', a:string, b:string, from?:number, to?:number, at:number[]}>} */
  tick(dt) {
    this._t += dt;
    if (!this.dirty || (!this.urgent && this._t < this.rebuildInterval)) return [];
    this._t = 0; this.dirty = false; this.urgent = false;
    const old = this.zoneDist;
    this._rebuild();
    return this._compare(old, this.zoneDist);
  }

  _compare(old, now) {
    const e = this.lastEdit || [0, 0, 0];
    const near = (i, j) => Math.hypot(...this.zones[i].p.map((v, k) => v - e[k])) + Math.hypot(...this.zones[j].p.map((v, k) => v - e[k]));
    let conn = null, pass = null;
    for (let i = 0; i < this.zones.length; i++) for (let j = i + 1; j < this.zones.length; j++) {
      const o = old[i][j], n = now[i][j];
      if (o === Infinity && n < Infinity) { if (!conn || near(i, j) < conn.score) conn = { i, j, score: near(i, j) }; }
      else if (o < Infinity && n < o * this.passageRatio && o - n > this.passageMin) {
        if (!pass || near(i, j) < pass.score) pass = { i, j, score: near(i, j), from: o, to: n };
      }
    }
    const ev = [];
    if (conn) ev.push({ type: 'connected', a: this.zones[conn.i].name, b: this.zones[conn.j].name, at: e });
    if (pass) ev.push({ type: 'passage', a: this.zones[pass.i].name, b: this.zones[pass.j].name, from: pass.from, to: pass.to, at: e });
    return ev;
  }

  zoneDistance(a, b) {
    const i = this.zones.findIndex((z) => z.name === a), j = this.zones.findIndex((z) => z.name === b);
    return i < 0 || j < 0 ? NaN : this.zoneDist[i][j];
  }

  /** Cell path → spaced waypoints (world positions). */
  pathPoints(from, to, every = 3) {
    const nav = this.nav;
    const path = nav.findPath(nav.nearestOpen(from, 4), nav.nearestOpen(to, 4));
    if (!path) return null;
    const pts = [];
    for (let i = every; i < path.length; i += every) pts.push(nav.worldPos(path[i]));
    pts.push(nav.worldPos(path[path.length - 1]));
    return pts;
  }
}
