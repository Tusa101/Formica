// Terrain worker: generates chunk data and meshes it (ADD §40). Module worker, pure JS.
import { generateChunk } from './field.js';
import { meshChunk } from './surface-nets.js';
import { buildLevelField } from './levelfield.js';
import { LEVELS } from '../levels/index.js';

const fields = new Map();
function fieldFor(levelId) {
  if (!fields.has(levelId)) fields.set(levelId, buildLevelField(LEVELS[levelId]));
  return fields.get(levelId);
}

function meshPayload(m) {
  return { positions: m.positions, normals: m.normals, matw: m.matw, cut: m.cut, indices: m.indices, triangleCount: m.triangleCount };
}
const meshTransfer = (m) => [m.positions.buffer, m.normals.buffer, m.matw.buffer, m.cut.buffer, m.indices.buffer];

self.onmessage = (e) => {
  const job = e.data;
  try {
    if (job.type === 'generate') {
      const t0 = performance.now();
      const F = fieldFor(job.levelId);
      const g = generateChunk(job.cx, job.cy, job.cz, job.N, job.voxel, F.density, F.material);
      const t1 = performance.now();
      const mesh = g.allSolid || g.allEmpty ? null : meshChunk(g.density, g.material, job.N, job.voxel, job.cx, job.cy, job.cz);
      const t2 = performance.now();
      const transfer = [g.density.buffer, g.material.buffer, ...(mesh ? meshTransfer(mesh) : [])];
      self.postMessage({ id: job.id, ok: true, density: g.density, material: g.material, allSolid: g.allSolid, allEmpty: g.allEmpty,
        mesh: mesh && meshPayload(mesh), genMs: t1 - t0, meshMs: t2 - t1 }, transfer);
    } else if (job.type === 'mesh') {
      const t0 = performance.now();
      const mesh = meshChunk(job.density, job.material, job.N, job.voxel, job.cx, job.cy, job.cz, 4, job.cutTime || null);
      self.postMessage({ id: job.id, ok: true, mesh: meshPayload(mesh), version: job.version, meshMs: performance.now() - t0 }, meshTransfer(mesh));
    } else throw new Error('Unknown job ' + job.type);
  } catch (err) {
    self.postMessage({ id: job.id, ok: false, error: String(err && err.stack || err) });
  }
};
