// Ground reachability (ADDENDUM 03 §9): where an ant without an Adhesion Suit can stand and walk.
// Built on the NavGrid; edges are walkable slopes (≤ minUp) and one-way drops. Pure JS.

const H8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

export class GroundNav {
  /** @param {import('./navgrid.js').NavGrid} nav  @param {{densityAt, normalAt, dropToSurface}} field */
  constructor(nav, field, { minUp = 0.643, floorDepth = 0.9, maxDrop = 24 } = {}) {
    this.nav = nav; this.field = field; this.minUp = minUp; this.floorDepth = floorDepth; this.maxDrop = maxDrop;
    this.floorY = new Float32Array(nav.count).fill(NaN);
    this.adj = new Map();   // idx → Set(idx)
    this.radj = new Map();  // reverse
  }

  standable(idx) { return !Number.isNaN(this.floorY[idx]); }

  build() {
    const nav = this.nav, f = this.field;
    this.floorY.fill(NaN); this.adj.clear(); this.radj.clear();
    for (let idx = 0; idx < nav.count; idx++) {
      if (!nav.open[idx]) continue;
      const c = nav.worldPos(idx);
      if (f.densityAt(c[0], c[1], c[2]) > 0) continue;
      const fl = f.dropToSurface(c, this.floorDepth);
      if (!fl) continue;
      const n = f.normalAt(fl[0], fl[1] + 0.05, fl[2]);
      if (n[1] >= this.minUp) this.floorY[idx] = fl[1];
    }
    const [X, Y, Z] = nav.dims, tan = Math.tan(Math.acos(this.minUp));
    for (let idx = 0; idx < nav.count; idx++) {
      if (!this.standable(idx)) continue;
      const [i, j, k] = nav.coords(idx);
      for (const [dx, dz] of H8) {
        const a = i + dx, c = k + dz;
        if (a < 0 || c < 0 || a >= X || c >= Z) continue;
        const h = Math.hypot(dx, dz) * nav.cell;
        let linked = false;
        for (const dj of [0, 1, -1]) { // walk: same level, one up, one down
          const b = j + dj;
          if (b < 0 || b >= Y) continue;
          const nb = nav.index(a, b, c);
          if (!this.standable(nb)) continue;
          const dy = this.floorY[nb] - this.floorY[idx];
          if (dy > tan * h + 0.05) continue; // too steep to walk up
          if (dy < -tan * h - 0.05) continue; // handled as a drop below
          this._edge(idx, nb); linked = true;
        }
        if (linked) continue;
        // drop: fall down an open column next to us onto a standable cell
        const top = nav.index(a, j, c);
        if (!nav.open[top]) continue;
        for (let b = j - 1; b >= Math.max(0, j - this.maxDrop); b--) {
          const nb = nav.index(a, b, c);
          if (this.standable(nb)) { this._edge(idx, nb); break; }
          if (!nav.open[nb]) break;
        }
      }
    }
    return this;
  }

  _edge(a, b) {
    if (!this.adj.has(a)) this.adj.set(a, new Set());
    if (!this.radj.has(b)) this.radj.set(b, new Set());
    this.adj.get(a).add(b); this.radj.get(b).add(a);
  }

  /** Nearest standable cell to a world point (searching a few cells). */
  cellNear(p, radius = 3) {
    const nav = this.nav;
    const c0 = nav.cellAt(p);
    if (c0 < 0) return -1;
    const [i0, j0, k0] = nav.coords(c0);
    let best = -1, bd = Infinity;
    for (let dk = -radius; dk <= radius; dk++) for (let dj = -radius; dj <= radius; dj++) for (let di = -radius; di <= radius; di++) {
      const i = i0 + di, j = j0 + dj, k = k0 + dk;
      if (i < 0 || j < 0 || k < 0 || i >= nav.dims[0] || j >= nav.dims[1] || k >= nav.dims[2]) continue;
      const idx = nav.index(i, j, k);
      if (!this.standable(idx)) continue;
      const d = di * di + dj * dj * 1.5 + dk * dk;
      if (d < bd) { bd = d; best = idx; }
    }
    return best;
  }

  _search(start, graph) {
    const seen = new Set();
    if (start < 0) return seen;
    const stack = [start]; seen.add(start);
    while (stack.length) { const u = stack.pop(); for (const v of graph.get(u) || []) if (!seen.has(v)) { seen.add(v); stack.push(v); } }
    return seen;
  }

  /** Cells reachable from p on foot. */
  reachableFrom(p) { return this._search(this.cellNear(p), this.adj); }
  /** Cells from which p can be reached on foot. */
  canReturnTo(p) { return this._search(this.cellNear(p), this.radj); }

  /** Can an ant walk from a to b (and optionally back)? */
  reachable(a, b, { back = true } = {}) {
    const tb = this.cellNear(b);
    if (tb < 0) return false;
    if (!this.reachableFrom(a).has(tb)) return false;
    return !back || this.canReturnTo(a).has(tb);
  }
}

/** Adhesion (suit/creatures): any open neighbour is reachable — the NavGrid cavity label. */
export function reachableWithAdhesion(nav, a, b) {
  const ca = nav.nearestOpen(a, 3), cb = nav.nearestOpen(b, 3);
  return ca >= 0 && cb >= 0 && nav.label[ca] === nav.label[cb];
}
