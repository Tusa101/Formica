// Places ritual lamps along a polyline (P13). Pure JS: the caller supplies the floor query.

/**
 * @param {number[][]} line          polyline through the tunnels
 * @param {(p:number[])=>number[]|null} floorAt  floor point below p, or null
 * @param {{spacing?:number, side?:number, flickerEvery?:number}} o
 * @returns {Array<{pos:number[], flicker:boolean, s:number}>}
 */
export function placeLamps(line, floorAt, { spacing = 4, side = 0.55, flickerEvery = 6 } = {}) {
  const out = [];
  let next = 0, n = 0, s0 = 0; // next = path distance of the next lamp; s0 = path distance at segment start
  for (let i = 0; i < line.length - 1; i++) {
    const a = line[i], b = line[i + 1];
    const len = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const px = -(b[2] - a[2]), pz = b[0] - a[0], pl = Math.hypot(px, pz) || 1; // horizontal perpendicular
    while (next <= s0 + len) {
      const t = (next - s0) / (len || 1), sgn = n % 2 ? 1 : -1;
      const c = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
      const shifted = [c[0] + (px / pl) * side * sgn, c[1] + 0.3, c[2] + (pz / pl) * side * sgn];
      const f = floorAt(shifted) || floorAt([c[0], c[1] + 0.3, c[2]]);
      if (f) { out.push({ pos: f, flicker: (n + 1) % flickerEvery === 0, s: next }); n++; }
      next += spacing;
    }
    s0 += len;
  }
  return out;
}

/**
 * Chooses which sources get a real light. Keeps currently assigned sources unless a new one is clearly nearer
 * (hysteresis) — so lights do not jump back and forth.
 * @param {Array<{pos:number[]}>} sources  @param {number[]} p  @param {number} n  @param {number[]} current  indices
 */
export function chooseSources(sources, p, n, current = [], hysteresis = 1.5) {
  const d = sources.map((s, i) => ({ i, d: Math.hypot(s.pos[0] - p[0], s.pos[1] - p[1], s.pos[2] - p[2]) - (current.includes(i) ? hysteresis : 0) }));
  d.sort((a, b) => a.d - b.d);
  return d.slice(0, n).map((x) => x.i).sort((a, b) => a - b);
}

