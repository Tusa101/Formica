// GREYBOX story objects (ADD §7): things that tell the history of the tunnels. USE shows their text.
import * as THREE from 'three';

const M = {
  chitin: new THREE.MeshStandardMaterial({ color: 0x3b2c20, roughness: 0.5 }),
  metal: new THREE.MeshStandardMaterial({ color: 0xa9adb0, roughness: 0.35, metalness: 0.8, side: THREE.DoubleSide }),
  glyph: new THREE.MeshStandardMaterial({ color: 0x6a5a40, emissive: 0x2a2010, roughness: 0.8 }),
  hair: new THREE.MeshStandardMaterial({ color: 0x7a6a58, roughness: 0.7 }),
};

function build(id) {
  const g = new THREE.Group();
  const add = (geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, ry, rz); g.add(m); return m; };
  if (id === 'sign' || id === 'names') { add(new THREE.BoxGeometry(0.7, 0.45, 0.06), M.glyph, 0, 0.5, 0); add(new THREE.CylinderGeometry(0.04, 0.05, 0.5, 6), M.chitin, 0, 0.25, 0); }
  else if (id === 'canister') { add(new THREE.CylinderGeometry(0.12, 0.12, 0.5, 12), M.metal, 0, 0.12, 0, Math.PI / 2, 0.4, 0); }
  else if (id === 'foil') { add(new THREE.IcosahedronGeometry(0.35, 1), M.metal, 0, 0.2, 0); }
  else if (id === 'hair') { add(new THREE.CylinderGeometry(0.05, 0.03, 2.4, 6), M.hair, 0, 0.06, 0, 0.1, 0.5, Math.PI / 2 - 0.05); }
  else if (id === 'comb') { add(new THREE.BoxGeometry(0.3, 0.04, 0.12), M.chitin, 0, 0.03, 0); }
  else { add(new THREE.SphereGeometry(0.12, 8, 6), M.glyph, 0, 0.12, 0); }
  return g;
}

export class Inspectables {
  constructor(scene, field, list, skip = new Set()) {
    this.scene = scene;
    this.entries = (list || []).filter((it) => !skip.has('insp-' + it.id)).map((it) => {
      const floor = field.dropToSurface(it.pos, 6) || it.pos;
      const mesh = build(it.id); mesh.position.set(floor[0], floor[1], floor[2]);
      scene.add(mesh);
      return { ...it, kind: 'inspect', floor, center: [floor[0], floor[1] + 0.3, floor[2]], mesh };
    });
  }
  remove(id) { const e = this.entries.find((x) => x.id === id); if (e) { this.scene.remove(e.mesh); this.entries = this.entries.filter((x) => x !== e); } }
  aimed(eye, dir, reach = 2.2) {
    let best = null, bd = Infinity;
    for (const e of this.entries) {
      const v = e.center.map((x, i) => x - eye[i]);
      const t = v[0] * dir[0] + v[1] * dir[1] + v[2] * dir[2];
      if (t < 0 || t > reach) continue;
      if (Math.hypot(v[0] - dir[0] * t, v[1] - dir[1] * t, v[2] - dir[2] * t) < 0.5 && t < bd) { bd = t; best = e; }
    }
    return best;
  }
}
