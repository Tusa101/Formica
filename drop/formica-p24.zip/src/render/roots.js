// GREYBOX Root Forest visuals (GDD §9): a tube slightly wider than the solid root in the density field, so the terrain
// surface inside is hidden. Replaced by the Root Forest kit (PIPE §42: 8–12 root variants, 2 landmark roots).
import * as THREE from 'three';

export function buildRoots(scene, roots) {
  const mat = new THREE.MeshStandardMaterial({ color: 0x4d3a28, roughness: 0.92 });
  const g = new THREE.Group(); g.name = 'roots (GREYBOX)';
  for (const r of roots || []) {
    const curve = new THREE.CatmullRomCurve3(r.points.map((p) => new THREE.Vector3(...p)), false, 'centripetal');
    const geo = new THREE.TubeGeometry(curve, 24 * r.points.length, r.r + 0.07, 10, false);
    // bark: slight radial noise so it does not read as a pipe
    const pos = geo.attributes.position, v = new THREE.Vector3();
    for (let i = 0; i < pos.count; i++) { v.fromBufferAttribute(pos, i); const k = 1 + Math.sin(v.x * 7 + v.y * 5.3 + v.z * 6.1) * 0.02; pos.setXYZ(i, v.x * k, v.y * k, v.z * k); }
    geo.computeVertexNormals();
    g.add(new THREE.Mesh(geo, mat));
    for (const end of [r.points[0], r.points.at(-1)]) { const cap = new THREE.Mesh(new THREE.SphereGeometry(r.r + 0.07, 10, 8), mat); cap.position.set(...end); g.add(cap); }
  }
  scene.add(g);
  return g;
}
