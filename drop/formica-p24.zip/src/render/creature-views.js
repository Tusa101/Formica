// GREYBOX creatures oriented by their motors (AB §29 creature design comes later from the Blender pipeline).
import * as THREE from 'three';

class Critter {
  constructor(scene) {
    this.root = new THREE.Group(); scene.add(this.root);
    this.legs = []; this.t = 0;
    this._m = new THREE.Matrix4(); this._x = new THREE.Vector3(); this._y = new THREE.Vector3(); this._z = new THREE.Vector3();
  }
  addLegs(n, mat, spread, len, y = -0.03) {
    const geo = new THREE.CylinderGeometry(0.015, 0.01, len, 5);
    for (let i = 0; i < n; i++) {
      const side = i < n / 2 ? -1 : 1, row = (i % (n / 2)) - (n / 2 - 1) / 2;
      const pivot = new THREE.Group(); pivot.position.set(side * spread, y, row * spread * 0.9);
      const leg = new THREE.Mesh(geo, mat); leg.position.set(side * len * 0.38, -len * 0.3, 0); leg.rotation.z = side * 0.95;
      pivot.add(leg); this.root.add(pivot); this.legs.push(pivot);
    }
  }
  update(dt, motor, sink = 0.1, visible = true) {
    this.root.visible = visible;
    if (!visible) return;
    const u = motor.up, h = motor.heading;
    this._y.set(u[0], u[1], u[2]); this._z.set(-h[0], -h[1], -h[2]);
    this._x.crossVectors(this._y, this._z).normalize();
    this._m.makeBasis(this._x, this._y, this._z);
    this.root.quaternion.setFromRotationMatrix(this._m);
    this.root.position.set(motor.pos[0] - u[0] * sink, motor.pos[1] - u[1] * sink, motor.pos[2] - u[2] * sink);
    this.t += dt * (0.5 + motor.speed * 7);
    this.legs.forEach((l, i) => { l.rotation.y = Math.sin(this.t + (i % 2) * Math.PI) * 0.4; });
  }
}

export class SpiderView extends Critter {
  constructor(scene) {
    super(scene);
    const hair = new THREE.MeshStandardMaterial({ color: 0x3a3028, roughness: 0.9 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x1d1814, roughness: 0.6 });
    const ab = new THREE.Mesh(new THREE.SphereGeometry(0.34, 14, 10), hair); ab.scale.set(0.9, 0.75, 1.2); ab.position.set(0, 0.1, 0.38);
    const ce = new THREE.Mesh(new THREE.SphereGeometry(0.24, 12, 9), dark); ce.scale.set(1, 0.6, 1.1); ce.position.set(0, 0.04, -0.1);
    const eyes = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.1, metalness: 0.4 }));
    eyes.position.set(0, 0.1, -0.33);
    this.root.add(ab, ce, eyes);
    this.addLegs(8, dark, 0.18, 0.75, 0.02);
  }
}

export class ScoutView extends Critter {
  constructor(scene) {
    super(scene);
    const chitin = new THREE.MeshStandardMaterial({ color: 0x6a2f1e, roughness: 0.4, metalness: 0.05 }); // foreign colony: redder
    const seg = (r, z, sy = 0.8) => { const m = new THREE.Mesh(new THREE.SphereGeometry(r, 12, 9), chitin); m.scale.set(0.85, sy, 1.2); m.position.set(0, 0.05, z); this.root.add(m); };
    seg(0.13, -0.32, 0.9); seg(0.12, -0.05); seg(0.2, 0.3, 0.75);
    const antG = new THREE.CylinderGeometry(0.008, 0.006, 0.35, 4);
    for (const s of [-1, 1]) { const a = new THREE.Mesh(antG, chitin); a.position.set(s * 0.06, 0.2, -0.45); a.rotation.set(-0.9, 0, s * 0.3); this.root.add(a); }
    this.addLegs(6, chitin, 0.1, 0.42);
  }
}
