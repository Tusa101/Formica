// GREYBOX beetle: shell + head + six legs, oriented by its motor (up/heading). Replaced by a creature asset (AB §29).
import * as THREE from 'three';

export class BeetleView {
  constructor(scene) {
    const shell = new THREE.MeshStandardMaterial({ color: 0x2d3440, roughness: 0.35, metalness: 0.15 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x17191d, roughness: 0.6 });
    this.root = new THREE.Group();
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 10), shell);
    body.scale.set(0.8, 0.5, 1.15); body.position.y = 0.02;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), dark);
    head.position.set(0, 0.0, -0.27);
    this.root.add(body, head);
    this.legs = [];
    const legGeo = new THREE.CylinderGeometry(0.012, 0.01, 0.26, 5);
    for (let i = 0; i < 6; i++) {
      const side = i < 3 ? -1 : 1, row = (i % 3) - 1;
      const pivot = new THREE.Group();
      pivot.position.set(side * 0.13, -0.02, row * 0.13);
      const leg = new THREE.Mesh(legGeo, dark);
      leg.position.set(side * 0.1, -0.08, 0); leg.rotation.z = side * 0.9;
      pivot.add(leg); this.root.add(pivot); this.legs.push(pivot);
    }
    scene.add(this.root);
    this._m = new THREE.Matrix4(); this._x = new THREE.Vector3(); this._y = new THREE.Vector3(); this._z = new THREE.Vector3();
    this.t = 0;
  }

  update(dt, motor) {
    const u = motor.up, h = motor.heading;
    this._y.set(u[0], u[1], u[2]);
    this._z.set(-h[0], -h[1], -h[2]);
    this._x.crossVectors(this._y, this._z).normalize();
    this._m.makeBasis(this._x, this._y, this._z);
    this.root.quaternion.setFromRotationMatrix(this._m);
    // sit on the surface: motor keeps the body at `hover` above it
    this.root.position.set(motor.pos[0] - u[0] * 0.1, motor.pos[1] - u[1] * 0.1, motor.pos[2] - u[2] * 0.1);
    this.t += dt * (0.5 + motor.speed * 6);
    this.legs.forEach((l, i) => { l.rotation.y = Math.sin(this.t + (i % 2) * Math.PI) * 0.35; });
  }
}
