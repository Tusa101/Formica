// Turns worker mesh buffers into Three.js meshes (one per chunk).
import * as THREE from 'three';

export class ChunkMeshes {
  constructor(scene, material) {
    this.group = new THREE.Group();
    this.group.name = 'terrain';
    scene.add(this.group);
    this.material = material;
    this.meshes = new Map();
  }

  upsert(chunk, m) {
    const old = this.meshes.get(chunk.key);
    if (old) { this.group.remove(old); old.geometry.dispose(); this.meshes.delete(chunk.key); }
    if (!m || m.triangleCount === 0) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(m.positions, 3));
    g.setAttribute('normal', new THREE.BufferAttribute(m.normals, 3));
    g.setAttribute('matw', new THREE.BufferAttribute(m.matw, 4));
    g.setAttribute('cutT', new THREE.BufferAttribute(m.cut, 1));
    g.setIndex(new THREE.BufferAttribute(m.indices, 1));
    g.computeBoundingSphere();
    const mesh = new THREE.Mesh(g, this.material);
    mesh.name = 'chunk ' + chunk.key;
    mesh.matrixAutoUpdate = false;
    this.group.add(mesh);
    this.meshes.set(chunk.key, mesh);
    return mesh;
  }
}
