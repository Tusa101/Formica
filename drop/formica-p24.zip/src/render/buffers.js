// GPU-friendly attribute updates (P24). Replacing a BufferAttribute leaves the old WebGL buffer alive until the geometry is
// disposed — on phones that leak ends in a lost WebGL context (black screen). Here attributes are updated in place, with
// spare capacity; when capacity runs out, the geometry is disposed once and the attribute re-created bigger.

/**
 * @param {import('three').BufferGeometry} geo
 * @param {Object<string, {data: ArrayLike<number>, itemSize: number}>} attrs  all attributes must describe the same count
 * @param {(arr: Float32Array, n: number) => any} make  (array, itemSize) → BufferAttribute (injected to keep this module three-free)
 */
export function writeAttributes(geo, attrs, make) {
  const entries = Object.entries(attrs);
  const count = entries.length ? entries[0][1].data.length / entries[0][1].itemSize : 0;
  const fits = entries.every(([name, { data }]) => { const a = geo.getAttribute(name); return a && a.array.length >= data.length; });
  if (!fits) {
    if (entries.some(([name]) => geo.getAttribute(name))) geo.dispose(); // frees every GPU buffer of this geometry
    for (const [name, { data, itemSize }] of entries) {
      const cap = Math.max(64, 1 << Math.ceil(Math.log2(Math.max(1, data.length / itemSize)))) * itemSize;
      const arr = new Float32Array(cap);
      geo.setAttribute(name, make(arr, itemSize));
    }
  }
  for (const [name, { data }] of entries) {
    const a = geo.getAttribute(name);
    a.array.set(data);
    a.needsUpdate = true;
    if (a.updateRanges !== undefined) { a.clearUpdateRanges?.(); a.addUpdateRange?.(0, data.length); }
  }
  geo.setDrawRange(0, count);
  geo.computeBoundingSphere?.();
  return count;
}
