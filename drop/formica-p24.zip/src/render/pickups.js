// GREYBOX resource props and water drips (GDD §15, ADD §7). Replaced by Root Forest kit assets (PIPE §42).
import * as THREE from 'three';

function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
const hash = (str) => { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };

const MATS = {
  resin: new THREE.MeshStandardMaterial({ color: 0xc98a2e, roughness: 0.2, transparent: true, opacity: 0.85 }),
  fungus: new THREE.MeshStandardMaterial({ color: 0xd8cfb8, roughness: 0.85 }),
  fungusCap: new THREE.MeshStandardMaterial({ color: 0x9b7a5a, roughness: 0.8 }),
  seed: new THREE.MeshStandardMaterial({ color: 0x6b4a2a, roughness: 0.6 }),
  chitin: new THREE.MeshStandardMaterial({ color: 0x3a2a1e, roughness: 0.4, metalness: 0.05, side: THREE.DoubleSide }),
  scrap: new THREE.MeshStandardMaterial({ color: 0xa9adb0, roughness: 0.35, metalness: 0.8, side: THREE.DoubleSide }),
  water: new THREE.MeshStandardMaterial({ color: 0x6f8f98, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.75 }),
};

function build(item, seed) {
  const r = rng(seed), g = new THREE.Group();
  if (item === 'resin') {
    for (let i = 0; i < 3; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.1 + r() * 0.08, 10, 8), MATS.resin); m.position.set((r() - 0.5) * 0.25, 0.08, (r() - 0.5) * 0.25); m.scale.y = 0.7; g.add(m); }
  } else if (item === 'fungus') {
    for (let i = 0; i < 3; i++) {
      const h = 0.15 + r() * 0.15;
      const st = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.035, h, 6), MATS.fungus); st.position.set((r() - 0.5) * 0.3, h / 2, (r() - 0.5) * 0.3);
      const cap = new THREE.Mesh(new THREE.SphereGeometry(0.08 + r() * 0.05, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), MATS.fungusCap); cap.position.set(st.position.x, h, st.position.z);
      g.add(st, cap);
    }
  } else if (item === 'seed') {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), MATS.seed); m.scale.set(1, 0.7, 1.5); m.position.y = 0.11; m.rotation.y = r() * 3; g.add(m);
  } else if (item === 'chitin') {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 6, 0, Math.PI, 0, Math.PI / 2), MATS.chitin); m.rotation.set(-0.3, r() * 3, 0); m.position.y = 0.05; g.add(m);
  } else if (item === 'scrap') {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.28, 4, 3), MATS.scrap); m.rotation.set(-1.35, r() * 3, 0.2); m.position.y = 0.04;
    const w = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.45, 5), MATS.scrap); w.rotation.set(0, r() * 3, Math.PI / 2 - 0.1); w.position.set(0.05, 0.03, 0.08);
    g.add(m, w);
  }
  return g;
}

export class Pickups {
  constructor(scene, field, level, collected) {
    this.scene = scene;
    this.entries = [];
    for (const p of level.pickups || []) {
      if (collected.has(p.id)) continue;
      const floor = field.dropToSurface(p.pos, 6) || p.pos;
      const mesh = build(p.item, hash(p.id));
      mesh.position.set(floor[0], floor[1], floor[2]);
      scene.add(mesh);
      this.entries.push({ kind: 'pickup', id: p.id, item: p.item, n: p.n || 1, pos: [floor[0], floor[1] + 0.12, floor[2]], mesh });
    }
    for (const w of level.waterSources || []) {
      const floor = field.dropToSurface(w.pos, 6) || w.pos;
      const g = new THREE.Group();
      const pool = new THREE.Mesh(new THREE.CircleGeometry(0.35, 20), MATS.water); pool.rotation.x = -Math.PI / 2; pool.position.y = 0.02;
      const drop = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), MATS.water);
      g.add(pool, drop); g.position.set(floor[0], floor[1], floor[2]); scene.add(g);
      this.entries.push({ kind: 'water', id: w.id, pos: [floor[0], floor[1] + 0.1, floor[2]], mesh: g, drop, t: Math.random(), cooldown: 0 });
    }
  }

  /** Nearest entry whose position lies close to the view ray within reach. */
  aimed(eye, dir, reach = 1.9) {
    let best = null, bd = Infinity;
    for (const e of this.entries) {
      const v = [e.pos[0] - eye[0], e.pos[1] - eye[1], e.pos[2] - eye[2]];
      const t = v[0] * dir[0] + v[1] * dir[1] + v[2] * dir[2];
      if (t < 0 || t > reach) continue;
      const off = Math.hypot(v[0] - dir[0] * t, v[1] - dir[1] * t, v[2] - dir[2] * t);
      if (off < 0.35 + t * 0.12 && t < bd) { bd = t; best = e; }
    }
    return best;
  }

  remove(e) { this.scene.remove(e.mesh); this.entries = this.entries.filter((x) => x !== e); }

  update(dt) {
    for (const e of this.entries) {
      if (e.kind !== 'water') continue;
      if (e.cooldown > 0) e.cooldown -= dt;
      e.t = (e.t + dt * 0.8) % 1;
      e.drop.position.y = 1.6 * (1 - e.t * e.t);
      e.drop.visible = e.cooldown <= 0;
    }
  }
}
