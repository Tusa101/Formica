// GLSL chunks for the terrain material. UV-free procedural 3D noise (AB §6, §12): macro + meso + micro,
// low-contrast micro detail, strata for layered rock. Kept separate so smoke tests can compile it standalone.

export const TERRAIN_PARS_VERTEX = /* glsl */`
attribute vec4 matw;
attribute float cutT;
varying float vCut;
varying vec4 vMatW;
varying vec3 vTerrainPos;
uniform vec4 uStress[8];
`;

export const TERRAIN_VERTEX = /* glsl */`
// Critical roofs sag (ADD §56): ceiling vertices near a critical source dip slightly.
for (int i = 0; i < 8; i++) {
  float lv = uStress[i].w;
  if (lv > 0.7) {
    float d = distance(transformed, uStress[i].xyz);
    float above = smoothstep(-0.6, 0.2, transformed.y - uStress[i].y);
    transformed.y -= 0.14 * (lv - 0.7) / 0.3 * (1.0 - smoothstep(0.3, 2.4, d)) * above;
  }
}
vMatW = matw;
vCut = cutT;
vTerrainPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
`;

export const TERRAIN_PARS_FRAGMENT = /* glsl */`
varying vec4 vMatW;
varying float vCut;
varying vec3 vTerrainPos;
uniform float uTime;
uniform float uFreshTau;
uniform vec4 uStress[8];
uniform vec3 uColA[4];
uniform vec3 uColB[4];
uniform vec4 uRough;
uniform vec4 uStrata;
uniform float uStrataFreq;

float terrainHash(vec3 p) {
  p = fract(p * 0.1031);
  p += dot(p, p.zyx + 31.32);
  return fract((p.x + p.y) * p.z);
}
float terrainNoise(vec3 p) {
  vec3 i = floor(p);
  vec3 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = mix(terrainHash(i), terrainHash(i + vec3(1.0, 0.0, 0.0)), f.x);
  float b = mix(terrainHash(i + vec3(0.0, 1.0, 0.0)), terrainHash(i + vec3(1.0, 1.0, 0.0)), f.x);
  float c = mix(terrainHash(i + vec3(0.0, 0.0, 1.0)), terrainHash(i + vec3(1.0, 0.0, 1.0)), f.x);
  float d = mix(terrainHash(i + vec3(0.0, 1.0, 1.0)), terrainHash(i + vec3(1.0, 1.0, 1.0)), f.x);
  return mix(mix(a, b, f.y), mix(c, d, f.y), f.z);
}
float terrainFbm(vec3 p) {
  return (0.5 * terrainNoise(p) + 0.25 * terrainNoise(p * 2.03) + 0.125 * terrainNoise(p * 4.01)) / 0.875;
}
vec3 terrainAlbedo(vec3 wp, vec4 w, out float rough) {
  float macro = terrainFbm(wp * 0.08);
  float meso = terrainNoise(wp * 0.6);
#ifdef TERRAIN_LOW
  float micro = 0.5;
#else
  float micro = terrainNoise(wp * 4.0);
#endif
  float strata = sin(wp.y * uStrataFreq + macro * 7.0 + meso * 0.8) * 0.5 + 0.5;
  w = pow(w, vec4(1.5));
  w /= max(w.x + w.y + w.z + w.w, 1e-4);
  vec3 col = vec3(0.0);
  float base = 0.55 * macro + 0.3 * meso + 0.15 * micro;
  for (int i = 0; i < 4; i++) {
    float t = clamp(base + uStrata[i] * (strata - 0.5), 0.0, 1.0);
    col += w[i] * mix(uColA[i], uColB[i], t);
  }
  col *= 0.94 + 0.12 * micro;
  rough = clamp(dot(w, uRough) + (meso - 0.5) * 0.08, 0.3, 1.0);
  // Fresh cut (AB §7): darker, slightly moister, loose grain; decays over time.
  float fresh = vCut > 0.0 ? exp(-max(uTime - vCut, 0.0) / uFreshTau) : 0.0;
  col *= 1.0 - fresh * (0.2 + 0.1 * terrainNoise(wp * 9.0));
  rough = clamp(rough - fresh * 0.18, 0.3, 1.0);
  // Structural stress (ADD §56): thin dark cracks that widen and multiply with stress.
  float st = 0.0;
  for (int i = 0; i < 8; i++) {
    float lv = uStress[i].w;
    if (lv > 0.0) st = max(st, lv * (1.0 - smoothstep(0.4, 2.6, distance(wp, uStress[i].xyz))));
  }
  if (st > 0.02) {
    float c1 = abs(terrainNoise(wp * 2.7) - 0.5);
    float c2 = abs(terrainNoise(wp * 5.9 + 7.0) - 0.5);
    float crack = 1.0 - smoothstep(0.0, 0.012 + 0.045 * st, c1);
#ifndef TERRAIN_LOW
    crack = max(crack, (1.0 - smoothstep(0.0, 0.01 + 0.03 * st, c2)) * step(0.45, st));
#endif
    col *= 1.0 - 0.8 * crack * smoothstep(0.02, 0.2, st);
    col = mix(col, col * vec3(0.85, 0.8, 0.75), st * 0.35); // dusty, drained look
  }
  return col;
}
`;

export const TERRAIN_COLOR_FRAGMENT = /* glsl */`
float tRough = 0.9;
diffuseColor.rgb = terrainAlbedo(vTerrainPos, vMatW, tRough);
`;

export const TERRAIN_ROUGH_FRAGMENT = /* glsl */`
roughnessFactor = tRough;
`;
