// Subsurface Scanner visuals (P20): x-ray cavity silhouettes through rock, fading; shortcut rings on walls.
import * as THREE from 'three';
import { writeAttributes } from './buffers.js';
const mkAttr = (a, n) => new THREE.BufferAttribute(a, n);

export class SubsurfaceView {
  constructor(scene) {
    this.points = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({
      size: 0.16, color: 0x5fd0c0, transparent: true, opacity: 0, depthTest: false, depthWrite: false, blending: THREE.AdditiveBlending }));
    this.points.frustumCulled = false; this.points.renderOrder = 12;
    this.rings = new THREE.Group();
    scene.add(this.points, this.rings);
    this.t = 0; this.rt = 0;
    this.ringMat = new THREE.MeshBasicMaterial({ color: 0xe0a64a, transparent: true, opacity: 0.9, depthTest: false, side: THREE.DoubleSide });
  }
  show(positions) {
    writeAttributes(this.points.geometry, { position: { data: positions.flat(), itemSize: 3 } }, mkAttr);
    this.t = 8;
  }
  markShortcuts(list) {
    this.rings.clear();
    for (const c of list) {
      const r = new THREE.Mesh(new THREE.RingGeometry(0.3, 0.42, 24), this.ringMat);
      r.position.set(...c.hit); r.lookAt(c.beyond[0], c.beyond[1], c.beyond[2]); r.renderOrder = 13;
      this.rings.add(r);
    }
    this.rt = 14;
  }
  update(dt) {
    if (this.t > 0) { this.t -= dt; this.points.material.opacity = Math.min(0.85, this.t / 3); }
    this.points.visible = this.t > 0;
    if (this.rt > 0) { this.rt -= dt; this.ringMat.opacity = 0.5 + 0.4 * Math.sin(this.rt * 5); }
    this.rings.visible = this.rt > 0;
  }
}
