// NAV-CARAPACE 3D map (GDD §44): a hologram of the space the ant has seen — cave walls as a point shell tinted by height,
// the route walked, pheromone markers and beacons. Rendered as its own scene in the same canvas.
import * as THREE from 'three';
import { writeAttributes } from './buffers.js';
const mkAttr = (a, n) => new THREE.BufferAttribute(a, n);
import { MARKERS } from '../gameplay/exploration.js';

export class MapView {
  constructor() {
    const s = (this.scene = new THREE.Scene());
    s.background = new THREE.Color(0x040708);
    s.add(new THREE.HemisphereLight(0x9fe8dc, 0x101010, 1.2));
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 500);
    this.cloud = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({ size: 0.32, vertexColors: true, transparent: true, opacity: 0.85, sizeAttenuation: true, depthWrite: false }));
    this.route = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0xe8f4f0, transparent: true, opacity: 0.7 }));
    this.player = new THREE.Mesh(new THREE.ConeGeometry(0.45, 1.3, 10), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    this.markers = new THREE.Group();
    // P23 the player's network: dug tunnels (warm) and own lamps (bright)
    this.dug = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({ size: 0.34, color: 0xe0a64a, transparent: true, opacity: 0.85, depthWrite: false }));
    this.lamps = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({ size: 0.9, color: 0xffd49a, transparent: true, opacity: 1, depthWrite: false }));
    this.dug.frustumCulled = false; this.lamps.frustumCulled = false;
    s.add(this.dug, this.lamps);
    this.netVersion = -1;
    this.beacons = new THREE.Group();
    for (const o of [this.cloud, this.route]) o.frustumCulled = false;
    s.add(this.cloud, this.route, this.player, this.markers, this.beacons);
    this.yaw = 0.6; this.pitch = 0.75; this.dist = 26; this.target = new THREE.Vector3();
    this.version = -1;
    this._c = new THREE.Color();
    this._geoMarker = new THREE.OctahedronGeometry(0.45, 0);
    this._geoStem = new THREE.CylinderGeometry(0.04, 0.04, 1.2, 4);
    this._geoBeam = new THREE.CylinderGeometry(0.08, 0.08, 8, 6);
    this._mats = new Map();
  }

  /** Rebuilds the point shell: seen open cells that border rock. */
  _cloud(ex, nav) {
    const [X, Y] = nav.dims, pos = [], col = [];
    let minY = Infinity, maxY = -Infinity;
    const cells = [];
    for (let i = 0; i < nav.count; i++) {
      const sc = !ex.seen[i] && ex.scanned?.[i];
      if ((!ex.seen[i] && !sc) || !nav.open[i]) continue;
      const x = i % X, y = Math.floor(i / X) % Y;
      const border = (x > 0 && !nav.open[i - 1]) || (x + 1 < X && !nav.open[i + 1]) || (y > 0 && !nav.open[i - X]) || (y + 1 < Y && !nav.open[i + X]) ||
        (i - X * Y >= 0 && !nav.open[i - X * Y]) || (i + X * Y < nav.count && !nav.open[i + X * Y]);
      if (!border) continue;
      const p = nav.worldPos(i); p.dim = sc; cells.push(p);
      if (p[1] < minY) minY = p[1]; if (p[1] > maxY) maxY = p[1];
    }
    const lo = new THREE.Color(0x1f5a52), hi = new THREE.Color(0xa8f0e2);
    for (const p of cells) {
      pos.push(p[0], p[1], p[2]);
      const c = this._c.copy(lo).lerp(hi, maxY > minY ? (p[1] - minY) / (maxY - minY) : 0.5);
      const k = p.dim ? 0.35 : 1; // scanned-but-unvisited space is drawn dim
      col.push(c.r * k, c.g * k, c.b * k);
    }
    writeAttributes(this.cloud.geometry, { position: { data: pos, itemSize: 3 }, color: { data: col, itemSize: 3 } }, mkAttr);
  }

  syncNetwork(net) {
    if (!net || net.version === this.netVersion) return;
    this.netVersion = net.version;
    writeAttributes(this.dug.geometry, { position: { data: net.dugPoints().flat(), itemSize: 3 } }, mkAttr);
    writeAttributes(this.lamps.geometry, { position: { data: net.lamps.map((l) => [l[0], l[1] + 0.5, l[2]]).flat(), itemSize: 3 } }, mkAttr);
  }

  sync(ex, nav, player, heading, beacons) {
    if (ex.version !== this.version) {
      this.version = ex.version;
      this._cloud(ex, nav);
      writeAttributes(this.route.geometry, { position: { data: ex.route.flat(), itemSize: 3 } }, mkAttr);
      // markers: shared geometry, one material per type (no GPU allocations per rebuild)
      this.markers.clear();
      for (const m of ex.markers) {
        const mat = this._mat(MARKERS[m.type].color, 1);
        const mk = new THREE.Mesh(this._geoMarker, mat); mk.position.set(m.pos[0], m.pos[1] + 1.2, m.pos[2]);
        const stem = new THREE.Mesh(this._geoStem, mat); stem.position.set(m.pos[0], m.pos[1] + 0.6, m.pos[2]);
        this.markers.add(mk, stem);
      }
    }
    // beacon beams: rebuilt only when the list changes (was: every frame while the map was open — a GPU leak)
    const sig = beacons.map((b) => `${b.color}:${b.pos.map((v) => v.toFixed(1)).join(',')}`).join('|');
    if (sig !== this._beaconSig) {
      this._beaconSig = sig;
      this.beacons.clear();
      for (const b of beacons) {
        const beam = new THREE.Mesh(this._geoBeam, this._mat(b.color, 0.55));
        beam.position.set(b.pos[0], b.pos[1] + 4, b.pos[2]);
        this.beacons.add(beam);
      }
    }
    this.player.position.set(player[0], player[1] + 0.6, player[2]);
    this.player.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(heading[0], 0, heading[2]).normalize());
  }

  _mat(color, opacity) {
    const k = `${color}/${opacity}`;
    if (!this._mats.has(k)) this._mats.set(k, new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity }));
    return this._mats.get(k);
  }

  recenter(p) { this.target.set(p[0], p[1], p[2]); }
  orbit(dx, dy) { this.yaw -= dx * 0.008; this.pitch = Math.max(0.1, Math.min(1.5, this.pitch + dy * 0.006)); }
  zoom(f) { this.dist = Math.max(6, Math.min(120, this.dist * f)); }

  updateCamera(aspect) {
    const c = this.camera, t = this.target;
    c.aspect = aspect; c.updateProjectionMatrix();
    c.position.set(t.x + Math.sin(this.yaw) * Math.cos(this.pitch) * this.dist, t.y + Math.sin(this.pitch) * this.dist, t.z + Math.cos(this.yaw) * Math.cos(this.pitch) * this.dist);
    c.lookAt(t);
  }
}
