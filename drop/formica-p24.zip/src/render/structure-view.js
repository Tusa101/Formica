// Structural visuals: support columns (GREYBOX resin), scanner overlay (ADD §63 — coarse, no numbers).
import * as THREE from 'three';
import { writeAttributes } from './buffers.js';
const mkAttr = (a, n) => new THREE.BufferAttribute(a, n);
import { State } from '../world/stability.js';

export class SupportView {
  constructor(scene) {
    this.scene = scene;
    this.mat = new THREE.MeshStandardMaterial({ color: 0xc98a2e, roughness: 0.25, metalness: 0, transparent: true, opacity: 0.88 });
    this.capMat = new THREE.MeshStandardMaterial({ color: 0x8a5a1e, roughness: 0.5 });
  }
  add(a, b) {
    const va = new THREE.Vector3(...a), vb = new THREE.Vector3(...b);
    const len = va.distanceTo(vb);
    const g = new THREE.Group();
    const col = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.14, len, 10), this.mat);
    const capA = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.06, 10), this.capMat);
    const capB = capA.clone();
    capA.position.y = -len / 2; capB.position.y = len / 2;
    g.add(col, capA, capB);
    g.position.copy(va).add(vb).multiplyScalar(0.5);
    g.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), vb.clone().sub(va).normalize());
    this.scene.add(g);
  }
}

export class ScannerView {
  constructor(scene) {
    this.points = new THREE.Points(new THREE.BufferGeometry(),
      new THREE.PointsMaterial({ size: 0.35, vertexColors: true, transparent: true, opacity: 0.9, depthTest: false }));
    this.points.renderOrder = 11; this.points.frustumCulled = false; this.points.visible = false;
    scene.add(this.points);
    this.t = 0;
    this._c = new THREE.Color();
  }
  show(sources) {
    const pos = [], col = [];
    for (const s of sources) {
      pos.push(...s.pos);
      this._c.set(s.state >= State.FRACTURED ? 0xc8574b : 0xe0a64a);
      col.push(this._c.r, this._c.g, this._c.b);
    }
    writeAttributes(this.points.geometry, { position: { data: pos, itemSize: 3 }, color: { data: col, itemSize: 3 } }, mkAttr);
    this.points.visible = true; this.t = 6;
    return sources.length;
  }
  update(dt) { if (this.t > 0) { this.t -= dt; if (this.t <= 0) this.points.visible = false; } }
}
