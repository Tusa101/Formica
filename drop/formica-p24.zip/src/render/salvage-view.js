// GREYBOX salvage objects (P18). Each kind gets a recognisable silhouette; replaced by PIPE §43 assets.
import * as THREE from 'three';

const metal = new THREE.MeshStandardMaterial({ color: 0x7d7a72, roughness: 0.45, metalness: 0.6 });
const dark = new THREE.MeshStandardMaterial({ color: 0x2d2a26, roughness: 0.6 });
const resin = new THREE.MeshStandardMaterial({ color: 0xa8742c, roughness: 0.35, transparent: true, opacity: 0.85 });
const strap = new THREE.MeshStandardMaterial({ color: 0x5a4432, roughness: 0.8 });

function build(kind) {
  const g = new THREE.Group();
  const add = (geo, m, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.rotation.set(rx, ry, rz); g.add(o); return o; };
  switch (kind) {
    case 'actuator': add(new THREE.CylinderGeometry(0.08, 0.08, 0.9, 8), metal, 0, 0.12, 0, 0, 0, Math.PI / 2 - 0.2); add(new THREE.CylinderGeometry(0.13, 0.13, 0.35, 8), dark, 0.3, 0.16, 0, 0, 0, Math.PI / 2 - 0.2); break;
    case 'pipe_segment': for (let i = 0; i < 4; i++) add(new THREE.TorusGeometry(0.16, 0.03, 6, 12), metal, -0.3 + i * 0.2, 0.17, 0, 0, Math.PI / 2, 0); add(new THREE.CylinderGeometry(0.15, 0.15, 0.8, 10, 1, true), dark, 0, 0.17, 0, 0, 0, Math.PI / 2); break;
    case 'harness_scrap': add(new THREE.TorusGeometry(0.25, 0.03, 6, 16), strap, 0, 0.05, 0, Math.PI / 2); add(new THREE.TorusGeometry(0.18, 0.03, 6, 16), strap, 0.2, 0.08, 0.1, Math.PI / 2 - 0.3); break;
    case 'cell_casing': add(new THREE.CylinderGeometry(0.1, 0.1, 0.4, 10), metal, 0, 0.1, 0, 0, 0.4, Math.PI / 2); add(new THREE.CylinderGeometry(0.06, 0.06, 0.08, 8), resin, 0.22, 0.1, 0.08, 0, 0.4, Math.PI / 2); break;
    case 'fan_housing': add(new THREE.TorusGeometry(0.28, 0.05, 8, 20), metal, 0, 0.3, 0, 0.2); for (let i = 0; i < 4; i++) add(new THREE.BoxGeometry(0.22, 0.02, 0.07), dark, 0, 0.3, 0, 0.2, 0, (i * Math.PI) / 2); break;
    case 'pressure_regulator': add(new THREE.BoxGeometry(0.3, 0.22, 0.2), metal, 0, 0.11, 0); add(new THREE.CylinderGeometry(0.07, 0.07, 0.03, 12), resin, 0, 0.14, 0.11, Math.PI / 2); break;
    case 'camp_frame': for (const s of [-1, 1]) add(new THREE.TorusGeometry(0.4, 0.035, 6, 14, Math.PI), resin, s * 0.2, 0, 0, 0, Math.PI / 2, 0); break;
    case 'field_battery': add(new THREE.BoxGeometry(0.4, 0.25, 0.25), dark, 0, 0.12, 0); add(new THREE.BoxGeometry(0.08, 0.05, 0.08), metal, 0.1, 0.27, 0); break;
    default: add(new THREE.BoxGeometry(0.3, 0.3, 0.3), metal, 0, 0.15, 0);
  }
  return g;
}

export class SalvageView {
  constructor(scene, field, list, salvaged) {
    this.scene = scene;
    this.entries = [];
    for (const s of list || []) {
      if (salvaged.has(s.id)) continue;
      let fl = field.dropToSurface(s.pos, 4) || s.pos;
      const g = build(s.kind);
      if (s.ceiling) { // hang it from the rock above (suit-only caches, P22)
        for (let t = 0; t < 4; t += 0.05) if (field.densityAt(s.pos[0], s.pos[1] + t, s.pos[2]) > 0) { fl = [s.pos[0], s.pos[1] + t, s.pos[2]]; break; }
        g.rotation.x = Math.PI;
      }
      g.position.set(...fl); g.rotation.y = (s.id.length * 1.7) % 6.28;
      scene.add(g);
      this.entries.push({ ...s, floor: fl, center: [fl[0], fl[1] + (s.ceiling ? -0.2 : 0.2), fl[2]], mesh: g });
    }
  }
  remove(id) { const e = this.entries.find((x) => x.id === id); if (e) { this.scene.remove(e.mesh); this.entries = this.entries.filter((x) => x !== e); } }
}
