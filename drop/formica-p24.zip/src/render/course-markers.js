// GREYBOX course gate beacons: next gate glows and carries a light, the rest are dim, passed ones hide.
import * as THREE from 'three';

export class CourseMarkers {
  constructor(scene, course) {
    this.course = course;
    const geo = new THREE.OctahedronGeometry(0.28, 0);
    this.dim = new THREE.MeshStandardMaterial({ color: 0x1d3a36, emissive: 0x5fd0c0, emissiveIntensity: 0.25, roughness: 0.4 });
    this.lit = new THREE.MeshStandardMaterial({ color: 0x5fd0c0, emissive: 0x5fd0c0, emissiveIntensity: 1.6, roughness: 0.3 });
    this.meshes = course.def.gates.map((g) => {
      const m = new THREE.Mesh(geo, this.dim);
      m.position.set(...g.pos);
      scene.add(m);
      return m;
    });
    this.light = new THREE.PointLight(0x5fd0c0, 4, 8, 1.8);
    scene.add(this.light);
    this.t = 0;
    this.sync();
  }

  sync() {
    this.meshes.forEach((m, i) => {
      m.visible = i >= this.course.index;
      m.material = i === this.course.index ? this.lit : this.dim;
    });
    const g = this.course.next;
    this.light.visible = !!g;
    if (g) this.light.position.set(...g.pos);
  }

  update(dt) {
    this.t += dt;
    for (const m of this.meshes) { m.rotation.y = this.t * 1.2; m.rotation.x = Math.sin(this.t) * 0.3; }
    const cur = this.meshes[this.course.index];
    if (cur) cur.scale.setScalar(1 + Math.sin(this.t * 4) * 0.12);
  }
}
