// Pooled debris particles for excavation bites (visual only — the permanent result lives in the density field).
import * as THREE from 'three';
import { MATERIALS } from '../data/materials.js';

export class Debris {
  constructor(scene, max = 400) {
    this.max = max;
    this.pos = new Float32Array(max * 3);
    this.col = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    this.next = 0;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    this.geo = g;
    this.points = new THREE.Points(g, new THREE.PointsMaterial({ size: 0.045, vertexColors: true, sizeAttenuation: true }));
    this.points.frustumCulled = false;
    scene.add(this.points);
    this._c = new THREE.Color();
    for (let i = 0; i < max; i++) this.pos[i * 3 + 1] = -1e4;
  }

  burst(at, normal, materialId, count) {
    this._c.set(MATERIALS[materialId]?.debris ?? 0x6a5040);
    for (let k = 0; k < count; k++) {
      const i = this.next; this.next = (this.next + 1) % this.max;
      const j = i * 3;
      this.pos[j] = at[0] + (Math.random() - 0.5) * 0.3;
      this.pos[j + 1] = at[1] + (Math.random() - 0.5) * 0.3;
      this.pos[j + 2] = at[2] + (Math.random() - 0.5) * 0.3;
      const s = 0.8 + Math.random() * 1.6;
      this.vel[j] = normal[0] * s + (Math.random() - 0.5) * 1.2;
      this.vel[j + 1] = normal[1] * s + Math.random() * 0.8;
      this.vel[j + 2] = normal[2] * s + (Math.random() - 0.5) * 1.2;
      const shade = 0.75 + Math.random() * 0.5;
      this.col[j] = this._c.r * shade; this.col[j + 1] = this._c.g * shade; this.col[j + 2] = this._c.b * shade;
      this.life[i] = 0.6 + Math.random() * 0.6;
    }
  }

  update(dt) {
    let any = false;
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      any = true;
      const j = i * 3;
      this.life[i] -= dt;
      this.vel[j + 1] -= 9 * dt;
      this.pos[j] += this.vel[j] * dt; this.pos[j + 1] += this.vel[j + 1] * dt; this.pos[j + 2] += this.vel[j + 2] * dt;
      if (this.life[i] <= 0) this.pos[j + 1] = -1e4;
    }
    if (any || this._wasAny) this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.color.needsUpdate = any;
    this._wasAny = any;
  }
}
