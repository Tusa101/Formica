// A fixed number of real point lights that follow the nearest light sources (P13). The light count never changes,
// so three.js never recompiles shaders; far sources keep their emissive glow but cast no light.
import * as THREE from 'three';
import { chooseSources } from '../world/lamp-path.js';

export class LightPool {
  constructor(scene, n = 5) {
    this.sources = [];
    this.lights = Array.from({ length: n }, () => { const l = new THREE.PointLight(0xffffff, 0, 8, 1.6); scene.add(l); return l; });
    this.assigned = [];
    this.t = 0; this.clock = 0;
  }

  add(src) { this.sources.push({ flicker: false, ...src }); return this.sources.length - 1; }

  update(dt, p) {
    this.clock += dt;
    this.t -= dt;
    if (this.t <= 0) { this.t = 0.25; this.assigned = chooseSources(this.sources, p, this.lights.length, this.assigned); }
    this.lights.forEach((l, k) => {
      const i = this.assigned[k];
      const s = this.sources[i];
      if (!s) { l.intensity = 0; return; }
      if (l.userData.src !== i) { l.userData.src = i; l.position.set(s.pos[0], s.pos[1], s.pos[2]); l.color.set(s.color); l.distance = s.distance; l.intensity = 0; }
      let target = s.intensity;
      if (s.flicker) target *= Math.sin(this.clock * 13 + i) > 0.55 || Math.sin(this.clock * 3.1 + i * 2) > 0.8 ? 0.15 : 1;
      l.intensity += (target - l.intensity) * Math.min(1, dt * 6);
      if (s.bulb) s.bulb.material.color.setScalar(s.flicker && target < s.intensity * 0.5 ? 0.25 : 1).multiply(s.tint);
    });
  }
}
