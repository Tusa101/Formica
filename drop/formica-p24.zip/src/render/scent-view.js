// Pheromone sense in the world (GDD §19; AB §35 — information over the world, never an opaque false-colour screen):
// motes hovering on the cells that carry scent, plus the ant's own markers as small lights.
import * as THREE from 'three';
import { writeAttributes } from './buffers.js';
const mkAttr = (a, n) => new THREE.BufferAttribute(a, n);
import { MARKERS } from '../gameplay/exploration.js';

const TINT = { player: [0.85, 0.95, 0.95], beetle: [0.9, 0.62, 0.25], marker: [0.6, 0.95, 0.85] };

export class ScentView {
  constructor(scene) {
    this.points = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({ size: 0.07, vertexColors: true, transparent: true, opacity: 0.9, depthWrite: false }));
    this.points.frustumCulled = false; this.points.visible = false;
    this.markers = new THREE.Group();
    scene.add(this.points, this.markers);
    this.t = 0; this.active = 0; this.version = -1; this._acc = 0;
  }

  pulse(seconds = 8) { this.active = seconds; this._acc = 1; }

  update(dt, air, nav, focus, ex) {
    this.t += dt;
    if (ex.version !== this.version) {
      this.version = ex.version; this.markers.clear();
      for (const m of ex.markers) {
        const o = new THREE.Mesh(new THREE.OctahedronGeometry(0.09, 0), new THREE.MeshBasicMaterial({ color: MARKERS[m.type].color }));
        o.position.set(m.pos[0], m.pos[1] + 0.35, m.pos[2]); this.markers.add(o);
      }
    }
    this.markers.children.forEach((o, i) => { o.rotation.y = this.t * 1.5 + i; o.visible = true; o.scale.setScalar(this.active > 0 ? 1.8 : 1); });
    if (this.active <= 0) { this.points.visible = false; return; }
    this.active -= dt;
    this._acc += dt;
    if (this._acc < 0.4) { this.points.material.opacity = Math.min(1, this.active / 1.5); return; }
    this._acc = 0;
    const pos = [], col = [];
    const r2 = 14 * 14;
    for (const [owner, arr] of air.scent) {
      const t = TINT[owner] || [0.7, 0.7, 0.9];
      for (const i of air.open) {
        const v = arr[i];
        if (v < 0.03) continue;
        const p = nav.worldPos(i);
        if ((p[0] - focus[0]) ** 2 + (p[1] - focus[1]) ** 2 + (p[2] - focus[2]) ** 2 > r2) continue;
        const n = v > 0.3 ? 3 : v > 0.1 ? 2 : 1;
        for (let k = 0; k < n; k++) {
          pos.push(p[0] + (Math.random() - 0.5) * 0.7, p[1] + (Math.random() - 0.5) * 0.7, p[2] + (Math.random() - 0.5) * 0.7);
          const b = Math.min(1, 0.35 + v * 2);
          col.push(t[0] * b, t[1] * b, t[2] * b);
        }
      }
    }
    writeAttributes(this.points.geometry, { position: { data: pos, itemSize: 3 }, color: { data: col, itemSize: 3 } }, mkAttr);
    this.points.visible = true;
    this.points.material.opacity = Math.min(1, this.active / 1.5);
  }
}
