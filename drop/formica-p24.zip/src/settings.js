// Player settings (mutable, persisted) — CONFIG stays the frozen source of defaults.
import { CONFIG } from './config.js';

export const DEFAULTS = Object.freeze({
  lookTouch: CONFIG.input.touchLookSensitivity,
  lookMouse: CONFIG.input.mouseSensitivity,
  invertY: CONFIG.input.invertY,
  quality: 'auto',          // low | medium | high | auto
  volume: 0.8,
  voice: false,
  showCourse: true,
  hints: true,
  vignette: true,
});
export const LIMITS = Object.freeze({ lookTouch: [0.002, 0.012], lookMouse: [0.0008, 0.005], volume: [0, 1] });
const KEY = 'formica.settings';

export const settings = { ...DEFAULTS };

export function clampSetting(k, v) {
  const l = LIMITS[k];
  return l ? Math.max(l[0], Math.min(l[1], Number(v))) : v;
}

export function loadSettings(storage = globalThis.localStorage) {
  let saved = {};
  try { saved = JSON.parse(storage?.getItem(KEY) || '{}') || {}; } catch { saved = {}; }
  for (const k of Object.keys(DEFAULTS)) settings[k] = k in saved ? clampSetting(k, saved[k]) : DEFAULTS[k];
  if (!['low', 'medium', 'high', 'auto'].includes(settings.quality)) settings.quality = 'auto';
  return settings;
}

export function saveSettings(storage = globalThis.localStorage) {
  try { storage?.setItem(KEY, JSON.stringify(settings)); } catch { /* quota */ }
}

export function setSetting(k, v, storage = globalThis.localStorage) {
  if (!(k in DEFAULTS)) throw new Error('unknown setting ' + k);
  settings[k] = clampSetting(k, v);
  saveSettings(storage);
  return settings[k];
}
