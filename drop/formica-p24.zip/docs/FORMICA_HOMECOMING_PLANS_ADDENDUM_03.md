# FORMICA: HOMECOMING --- PLANS ADDENDUM 03

## Locomotion Comfort, Connected Exploration, Signals, Scanning & Early-Game Safety

**Status:** Binding design revision based on hands-on prototype
testing.\
**Override rule:** Where this document conflicts with earlier FORMICA
documents on locomotion, tunnel connectivity, navigation, scanning,
starter power, or early-game survival pressure, this document takes
precedence.

------------------------------------------------------------------------

# 1. Revision goals

Prototype testing showed that unrestricted 360-degree first-person
locomotion across floors, walls and ceilings causes disorientation and
motion sickness when used continuously. The revised design makes normal
exploration horizon-stable and moves full wall/ceiling traversal into an
optional technological ability.

This revision also clarifies five connected systems:

1.  ground-first locomotion and the later Adhesion Suit;
2.  mandatory connectivity of the underground tunnel network;
3.  Subsurface Scanner for seeing tunnel silhouettes through terrain;
4.  Beacon/Signal navigation;
5.  forgiving starter life support, Analysis Scanner, blueprint
    discovery and salvage.

------------------------------------------------------------------------

# 2. Ground-first locomotion

> **FORMICA primarily uses horizon-stable ground locomotion. Full
> wall-and-ceiling traversal is an unlockable, energy-limited
> technological ability rather than the default movement mode.**

Modern evolved Formica have gradually become dependent on engineered
tunnels, floors, ramps and infrastructure. Their ancestors' effortless
all-surface locomotion is no longer part of ordinary daily movement.

Default traversal includes: - floors; - slopes; - natural ramps; - rocks
and roots; - constructed stairs/ramps; - ordinary ground-traversable
tunnel geometry.

**Mandatory comfort rule:**

> **Normal locomotion must never continuously roll the player's horizon
> to match walls or ceilings.**

Critical routes must therefore be traversable without 360-degree
crawling.

------------------------------------------------------------------------

# 3. Adhesion Suit / Climbing Rig

Full 360-degree traversal remains as a later technological unlock.

Working names: - Adhesion Suit; - Climbing Rig; - Surface Adhesion
Harness.

It enables:

`FLOOR → WALL → CEILING → WALL → FLOOR`

Uses include vertical shafts, secret areas, ceiling resources,
maintenance spaces, traversal shortcuts, alternate combat approaches and
old Formic structures.

It must not be required for critical early-game progression.

------------------------------------------------------------------------

# 4. Adhesion energy

The suit uses replaceable **Energy Cells**.

Charge is consumed primarily while active adhesion is required on walls,
ceilings and extreme surfaces. Normal ground movement should not consume
adhesion charge merely because the suit is equipped.

Possible progression:

`Chemical Cell → Improved Cell → High-Density Cell`

Later upgrades may improve efficiency, duration, load capacity,
stability and emergency reserve.

------------------------------------------------------------------------

# 5. Climbing comfort

Even after the suit is unlocked, support comfort options.

Possible modes:

**FULL** --- camera follows the traversed surface.

**STABILIZED** --- the ant can traverse walls/ceilings while the camera
preserves the world horizon as much as practical.

Additional settings may include reduced roll, configurable transition
duration, ceiling-roll toggle and optional vignette. Surface transitions
should be interpolated and predictable rather than instant.

------------------------------------------------------------------------

# 6. Connected-world rule

> **The generated underground must form a fundamentally connected
> traversable network.**

Important regions cannot exist as isolated tunnel systems separated by
arbitrary solid terrain with no tunnel connection.

The player must never need to excavate blindly through unknown rock
merely to discover whether another mandatory tunnel network exists.

All critical regions belong to a connected macro route graph.

------------------------------------------------------------------------

# 7. No blind digging for critical progression

> **Critical progression must never require blind excavation into
> unknown solid terrain.**

Every mandatory Story Anchor or progression region has at least one
valid route through discoverable empty space and explicit traversal
structures.

The route may be long, dangerous, flooded, contaminated,
creature-controlled, narrow, partially damaged, or gated by a clearly
communicated technology, but a comprehensible route exists.

Digging improves the network rather than replacing navigation.

------------------------------------------------------------------------

# 8. Revised purpose of excavation

Excavation remains a major feature, used for: - shortcuts; - alternate
approaches; - resource extraction; - base expansion; - tactical
routes; - infrastructure; - bypassing hazards; - connecting nearby
known/scanned cavities.

Desired loop:

`TRAVEL EXISTING ROUTE → NOTICE NEARBY SPACE → SCAN → EVALUATE COST → DIG SHORTCUT → REINFORCE → INTEGRATE`

The player should dig because they understand what is behind the wall,
not because they are guessing where the game world continues.

------------------------------------------------------------------------

# 9. Connectivity validation

Generation validates both topological connectivity and progression-aware
traversability.

Conceptually:

`reachableWith(CurrentProgressionAbilities)`

Validation considers: - tunnel graph connectivity; - slope; -
clearance; - verticality; - atmosphere; - water; - current tools; -
Adhesion Suit requirement; - repairable/destructible gates; - vehicle
clearance when relevant.

If a mandatory route requires an ability not yet available, an
alternative route must exist or the affected region must regenerate.

------------------------------------------------------------------------

# 10. Tunnel network becomes infrastructure

Existing tunnels are the world's roads.

The player gradually modifies them with: - shortcuts; - widening; -
reinforcement; - lights; - air infrastructure; - player beacons; -
Forward Camps; - Strider-compatible routes; - later Crawler/Burrower
routes.

The map should visibly evolve from natural/abandoned passages into
player-maintained expedition infrastructure.

------------------------------------------------------------------------

# 11. Three information systems

FORMICA distinguishes three exploration functions.

**Signal Receiver** --- *Where is something worth travelling toward?*

**Subsurface Scanner** --- *What spaces and materials exist behind the
surrounding terrain?*

**Analysis Scanner** --- *What is this visible
object/organism/technology, and what can I learn or salvage from it?*

They may eventually share hardware/UI, but remain separate gameplay
systems.

------------------------------------------------------------------------

# 12. Subsurface Scanner

The Subsurface Scanner is a limited geological "wall hack."

A pulse reveals silhouettes of nearby underground spaces through solid
terrain: - tunnels; - chambers; - vertical shafts; - large voids.

Later upgrades add geology, resources, wall thickness and structural
hazards.

It should reveal enough spatial information to make excavation and route
planning deliberate without permanently exposing the whole world.

------------------------------------------------------------------------

# 13. Subsurface Scanner progression

**Tier I --- Cavity Scanner:** nearby empty spaces.

**Tier II --- Geological Scanner:** material type, major deposits,
approximate wall thickness.

**Tier III --- Structural Scanner:** stressed terrain, thin layers,
collapse risk and reinforcement information.

**Tier IV --- Deep Scanner:** longer range and improved reconstruction.

Exact ranges are prototype/balance values.

------------------------------------------------------------------------

# 14. Scanner + digging

The intended relationship is:

`DISCOVER → SCAN → UNDERSTAND → DECIDE → DIG`

not:

`DIG RANDOMLY → HOPE`

The scanner can reveal parallel tunnels, hidden chambers, shortcut
distance, dangerous water/gas, resources and dangerously thin walls.

------------------------------------------------------------------------

# 15. Beacon System

Beacons are a core navigation system because underground environments
lack ordinary distant landmarks.

A beacon can define:

``` text
Position
Frequency
Power
SignalRange
Owner
SignalType
State
```

The player discovers a beacon by: 1. entering its detectable range; or
2. receiving coordinates/frequency from story, NPCs, terminals or
recovered data.

------------------------------------------------------------------------

# 16. Signal discovery

A newly detected beacon may progress through:

``` text
WEAK SIGNAL DETECTED
→ FORMIC TRANSMISSION
→ SIGNAL STRENGTH: 24%
→ SOURCE DIRECTION ESTIMATED
→ BEACON IDENTIFIED
```

Early equipment may provide only direction and strength. Better
receivers improve range, distance estimation and precision.

------------------------------------------------------------------------

# 17. Coordinates do not reveal routes

Coordinates can identify a target position without revealing the path.

This creates the desired underground problem:

> **I know where it is, but I do not yet know how to get there.**

The player solves the route through connected tunnels, local exploration
and scanning.

------------------------------------------------------------------------

# 18. Beacon categories

Potential categories: - Story Beacon; - Ritual Beacon; - Civilization
Beacon; - Emergency Beacon; - Dead Beacon; - Unknown Beacon; - Ancient
Beacon; - Player Beacon.

Not every signal is a quest. Optional signals are exploration hooks.

------------------------------------------------------------------------

# 19. Beacon density curve

**Early game:** several nearby signals and short expeditions.

**Mid game:** greater spacing, new biomes, Forward Camps and vehicles
become useful.

**Late game:** long-range, weak, intermittent or strange transmissions
requiring serious expedition infrastructure.

Increasing objective distance communicates progression.

------------------------------------------------------------------------

# 20. Starter exploration zone

The Ritual Shelter region must contain multiple nearby destinations.

Illustrative only:

``` text
~80–150 m   Abandoned Equipment Cache
~100–200 m  Old Utility/Water Station
~150–250 m  Damaged Ritual Beacon
~200–300 m  Unknown Signal
~250–350 m  Collapsed Maintenance Outpost
```

The exact distances require playtesting.

Opening rule:

> **The player should repeatedly have something nearby worth
> investigating.**

This reduces fear of leaving base and prevents aimless early wandering.

------------------------------------------------------------------------

# 21. Signals create intent

A destination changes the emotional meaning of darkness.

Prefer the feeling:

> "I am going toward a signal."

over:

> "I am walking randomly into an endless cave."

Mystery remains in the route and what is found at the destination.

------------------------------------------------------------------------

# 22. Signal Horizon

Receiver upgrades can reveal more distant signals.

Example:

``` text
RECEIVER UPGRADE INSTALLED
RANGE +250%

3 NEW SIGNALS DETECTED
```

Receiver range becomes a soft exploration boundary without invisible
walls.

------------------------------------------------------------------------

# 23. Opening beacon

After ritual separation, the Ritual Shelter transmits a known beacon.

The first navigation lesson is following that signal through connected
tunnels.

A family recording may say:

> "The shelter should still be transmitting. Turn on your receiver. If
> the beacon is alive, it'll lead you there."

An optional unknown signal can briefly appear on the way.

Once restored, the shelter's stronger receiver reveals several local
POIs.

------------------------------------------------------------------------

# 24. Early-game safety philosophy

> **Early survival exists to teach systems, not to punish ignorance.**

The opening should let the player experiment with fabrication, scanning,
construction, resources, power, air, water and nearby exploration
without immediately entering a survival death spiral.

The Ritual Shelter is the first safe technological laboratory.

------------------------------------------------------------------------

# 25. Starter life support

Once initially restored, the Ritual Shelter provides dependable minimum
access to: - breathable/clean air; - water; - limited food access or
starting reserves; - lighting; - storage; - basic fabrication; - weak
but permanent power.

The player can learn systems without constantly repairing essential life
support.

------------------------------------------------------------------------

# 26. Weak infinite starter generator

The starter shelter contains a **weak but effectively infinite passive
generator**.

It does not require routine fuel and produces slightly more power than
the shelter's essential starting machinery consumes.

Illustrative balance:

``` text
STARTER GENERATOR
OUTPUT:        1.20 power units

ESSENTIAL LOAD
Air Processor  0.45
Water System   0.25
Lighting       0.10
Fabricator     0.20
Other Base     0.10
-------------------
TOTAL          1.10
RESERVE        0.10
```

Exact numbers are placeholders.

------------------------------------------------------------------------

# 27. Purpose of permanent starter power

The generator guarantees a baseline; it does not solve the energy
economy.

It lets the player: - leave base without fearing total shutdown; -
experiment with fabrication; - test newly discovered technology; -
recover from mistakes; - understand power demand before fuel logistics
matter.

It should feel old, dependable and low-output.

------------------------------------------------------------------------

# 28. Expansion exceeds starter power

Meaningful expansion exceeds generator capacity.

Example:

``` text
POWER DEMAND: 1.42
GENERATION:   1.20
INSUFFICIENT POWER
```

This naturally introduces better generators and energy infrastructure.

Design lesson:

> **Basic survival is provided. Expansion must be engineered.**

------------------------------------------------------------------------

# 29. Essential-load protection

At the starter shelter, overload should preferably shed optional loads
before making the base immediately lethal.

Suggested priority: 1. air; 2. water; 3. emergency lighting; 4. critical
controls; 5. Fabricator; 6. optional machinery.

Later bases may expose configurable power priorities.

------------------------------------------------------------------------

# 30. Analysis Scanner

The player gains a close-range Analysis Scanner very early.

It analyzes: - machines; - tools; - technology fragments; - materials; -
resources; - human artifacts; - Formic artifacts; - organisms; -
environmental specimens.

The player targets an object and holds the scan until analysis
completes.

------------------------------------------------------------------------

# 31. Analysis outcomes

**Complete Blueprint:** simple technology unlocks from one scan.

**Blueprint Fragment:** complex technology requires several compatible
discoveries.

**Knowledge Entry:** lore/scientific/environmental information without a
craftable recipe.

**Known Technology:** no new blueprint, but salvage remains useful.

**Resource-Only Object:** no recoverable technology, but appropriate
objects can still be dismantled.

------------------------------------------------------------------------

# 32. Scan → Learn → Salvage

For salvageable technological objects:

> **ANALYZE → EXTRACT KNOWLEDGE → DISASSEMBLE → RECEIVE RESOURCES**

After successful analysis, the physical salvage object is dismantled and
disappears.

If the blueprint is unknown: - grant blueprint or blueprint progress; -
grant resources.

If already known: - grant resources.

If no useful blueprint exists: - grant resources only.

Duplicate discoveries therefore remain valuable.

------------------------------------------------------------------------

# 33. Example results

Unknown:

``` text
FORMIC FILTER MODULE
NEW TECHNOLOGY ANALYZED
BLUEPRINT FRAGMENT: 1 / 2

SALVAGED:
+2 Formic Metal
+1 Membrane
+1 Filter Medium
```

Known:

``` text
FORMIC FILTER MODULE
TECHNOLOGY ALREADY KNOWN

SALVAGED:
+2 Formic Metal
+1 Membrane
+1 Filter Medium
```

Resource-only:

``` text
BROKEN SUPPORT ACTUATOR
NO RECOVERABLE TECHNOLOGY

SALVAGED:
+3 Formic Metal
+1 Resin Composite
```

------------------------------------------------------------------------

# 34. Salvage eligibility

The destruction rule applies only to objects explicitly marked
**salvageable**.

Suitable: - broken machines; - abandoned tools; - fragments; - damaged
modules; - technological debris; - selected human components.

Do not automatically destroy: - living creatures; - functioning
NPC-owned infrastructure; - story-critical machinery; - whole
buildings; - geology; - protected artifacts.

Living organisms receive database scans, not salvage.

------------------------------------------------------------------------

# 35. Blueprint fragment philosophy

Avoid grind.

Typical targets: - simple tool: 1 scan; - ordinary machine: 1--2; -
substantial technology: 2--3; - major vehicle/system: 3--4 meaningful
discoveries.

Do not routinely require many identical scans.

------------------------------------------------------------------------

# 36. Component-based reverse engineering

Advanced technologies can require distinct components instead of
identical copies.

Example:

``` text
STRIDER TECHNOLOGY

Drive Assembly       ✓
Control Module       ✓
Leg Actuator         ✗
Power Distributor    ✗
```

This makes reverse engineering feel physical and purposeful.

------------------------------------------------------------------------

# 37. Knowledge-domain synthesis

Later research may grant reusable knowledge domains: - Actuation; -
Energy Storage; - Filtration; - Vehicle Control; - Structural
Composite; - Biological Processing; - Signal Processing.

Technologies can combine knowledge from different civilizations.

Example:

``` text
HYBRID AIR PROCESSOR

Formic Filtration       ✓
Rootkeeper Biofilter    ✓
Human Microporous Media ✓

BLUEPRINT SYNTHESIZED
```

This is a later-game extension, not required for the first demo.

------------------------------------------------------------------------

# 38. Knowledge Database

First-time scans populate an Archive/Knowledge Database containing
suitable fields such as: - name; - origin; - description; - hazards; -
useful resources; - technological principles; - ecology; - cultural
context; - known recipes.

The system reinforces the fantasy of learning an unfamiliar underground
world.

------------------------------------------------------------------------

# 39. Scanner placement in opening

The Analysis Scanner is obtained very early: - part of the Rite Kit but
limited; or - repaired inside the Ritual Shelter; or - fabricated
immediately after restoring it.

Nearby opening POIs intentionally contain scan targets so the player
learns:

`SIGNAL → TRAVEL → DISCOVER → SCAN → SALVAGE → RETURN → FABRICATE`

during the opening session.

------------------------------------------------------------------------

# 40. Revised first hour

**Phase 1 --- Separation** - route collapse; - ground movement
tutorial; - Signal Receiver activates; - Ritual Shelter beacon detected.

**Phase 2 --- Reach Shelter** - follow connected tunnels; - gather basic
resources; - discover side tunnels; - optionally detect another weak
signal.

**Phase 3 --- Restore Shelter** - restore basic air/water; - activate
weak infinite generator; - establish safe home; - unlock/repair Analysis
Scanner.

**Phase 4 --- Local Exploration** - shelter receiver reveals nearby
signals; - visit a small POI; - scan technology; - salvage it; - gain
blueprint/fragment and resources.

**Phase 5 --- Fabrication Reward** - return home; - fabricate something
newly learned.

Serious survival pressure comes later.

------------------------------------------------------------------------

# 41. Early emotional curve

Target:

`DISORIENTED → GUIDED → SAFE → CURIOUS → CAPABLE → AMBITIOUS`

Avoid:

`DISORIENTED → STARVING → LOST → AFRAID TO LEAVE BASE`

FORMICA can become dangerous later. First make the player want to
explore.

------------------------------------------------------------------------

# 42. Home vs expedition

**Home:** air, water, permanent low power, fabrication, storage,
familiar location.

**Outside:** uncertain atmosphere, creatures, distance, navigation,
structural hazards and limited portable power.

The player gradually extends the properties of "home" outward through
infrastructure.

This preserves the core fantasy:

> **Extend civilization behind you as you push into the unknown.**

------------------------------------------------------------------------

# 43. Objective-distance progression

Illustrative:

-   Opening: \~100--300 m, mostly on foot.
-   Early: \~300--800 m, Forward Camps increasingly useful.
-   Mid: \~1--3 km, Strider/mobile logistics valuable.
-   Later: multi-kilometer expeditions using advanced mobile
    infrastructure.

Exact values depend on movement speed and world density.

------------------------------------------------------------------------

# 44. Procedural-generation requirements

The generator must support: - connected macro tunnel network; -
progression-aware traversability; - ground-traversable critical
routes; - optional Adhesion-Suit routes; - controlled starter POI
density; - beacon placement constraints and signal ranges; -
scanner-relevant nearby cavities; - meaningful shortcut opportunities; -
scan/salvage distribution; - blueprint-fragment distribution; -
guaranteed accessibility of critical technology; - safe initial
life-support access.

------------------------------------------------------------------------

# 45. Starter-zone generation contract

Every valid seed guarantees:

1.  reachable Ritual Shelter;
2.  working/restorable weak infinite generator;
3.  minimum air/water;
4.  enough resources for tutorial repairs;
5.  several nearby connected POIs;
6.  at least one optional beacon/signal;
7.  several Analysis Scanner targets;
8.  at least one early blueprint reward;
9.  no mandatory 360-degree traversal;
10. no blind digging for critical progression.

Automated seed validation should test these.

------------------------------------------------------------------------

# 46. Prototype implementation order

For the current demo:

1.  Remove mandatory wall/ceiling locomotion.
2.  Lock normal camera to stable world-up.
3.  Ensure the tunnel layout is fully connected and ground-traversable.
4.  Add Signal Receiver and 2--4 nearby beacon targets.
5.  Add weak infinite starter generator and simple power budget.
6.  Keep starter air/water stable.
7.  Add Analysis Scanner.
8.  Add at least three scan/salvage examples:
    -   complete blueprint;
    -   blueprint fragment;
    -   known/resource-only object.
9.  Add Subsurface Scanner showing nearby tunnel silhouettes through
    walls.
10. Add one optional scanner-informed digging shortcut.
11. Add Adhesion Suit only after the normal exploration loop feels good.

------------------------------------------------------------------------

# 47. Demo acceptance test

A successful demo lets the player: - move comfortably without forced
camera roll; - reach shelter by following a signal; - restore it; - see
essential systems remain powered indefinitely; - understand that
expansion can exceed starter power; - detect nearby destinations; -
leave with a clear purpose; - follow connected routes instead of blind
digging; - scan a machine/object; - gain blueprint progress; - receive
salvage; - return home; - fabricate something useful; - use Subsurface
Scanner to find nearby tunnel geometry; - deliberately dig a useful
shortcut.

------------------------------------------------------------------------

# 48. Consolidated binding pillars

> **Ground movement is the default.**\
> Full wall/ceiling traversal is an optional energy-limited technology.

> **The underground is connected.**\
> Critical areas belong to a continuous traversable network.

> **Digging is informed engineering.**\
> It modifies and optimizes routes rather than compensating for blind
> navigation.

> **Exploration is signal-driven.**\
> Beacons, coordinates and anomalies give reasons to enter the darkness.

> **Scanning turns discovery into progression.**\
> New objects teach technology and world knowledge.

> **Duplicate technology remains useful.**\
> Salvageable scanned objects become resources after analysis.

> **The first home is forgiving.**\
> Starter air, water and weak permanent power create room to learn.

> **Progression expands the safe radius.**\
> Technology lets the player travel farther, understand more and extend
> civilization deeper underground.
