// Test Tunnels scene: volumetric level + ant controller (default) or noclip (debug), traversal course.
import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { World } from '../world/world.js';
import { ChunkMeshes } from '../render/chunk-meshes.js';
import { createTerrainMaterial } from '../render/terrain-material.js';
import { CourseMarkers } from '../render/course-markers.js';
import { PROP_BUILDERS } from '../props/greybox.js';
import { NoclipController } from '../player/noclip.js';
import { AntController } from '../player/ant-controller.js';
import { Course, formatTime } from '../gameplay/course.js';
import { Digger } from '../gameplay/dig.js';
import { Debris } from '../render/debris.js';
import { MATERIALS } from '../data/materials.js';

let storage = null;
try { storage = localStorage; } catch { /* private mode */ }

export class TestTunnelsScene {
  constructor(app, input, level) {
    this.app = app; this.input = input; this.level = level;
    const scene = (this.scene = new THREE.Scene());
    const R = CONFIG.render, A = CONFIG.ambient;
    scene.fog = new THREE.Fog(R.fogColor, R.fogNear, R.fogFar);
    scene.add(new THREE.HemisphereLight(A.sky, A.ground, A.intensity));

    const L = CONFIG.lamp;
    this.lamp = new THREE.SpotLight(L.color, L.intensity, L.distance, L.angle, L.penumbra, L.decay);
    this.lamp.target.position.set(0, 0, -1);
    app.camera.add(this.lamp, this.lamp.target);
    scene.add(app.camera);

    this.world = new World(level, storage);
    this.terrainMaterial = createTerrainMaterial();
    this.terrain = new ChunkMeshes(scene, this.terrainMaterial);
    this.digger = new Digger(this.world);
    this.debris = new Debris(scene);
    this.world.onChunkMesh = (chunk, mesh) => this.terrain.upsert(chunk, mesh);

    this.noclip = new NoclipController(app.camera, input, level.spawn);
    this.ant = new AntController(app.camera, input, this.world.field);
    this.ant.body.setVisible(false);
    this.course = new Course(level.course, storage);
    this.mode = 'ant';
    this.ready = false;
    this.zone = null;
    this._zoneT = 0;
    this.courseText = '';
    this.flash = null; this.flashT = 0;
  }

  async load(onProgress) {
    await this.world.load(onProgress);
    this._placeLandmarks();
    this.markers = new CourseMarkers(this.scene, this.course);
    this.ant.place(this.level.spawn.pos, this.level.spawn.yaw);
    this.ant.body.setVisible(this.mode === 'ant');
    this.ready = true;
  }

  _placeLandmarks() {
    this.level.lights.forEach((l, i) => {
      const hit = this.world.field.dropToSurface(l.pos, 12) || l.pos;
      const base = new THREE.Vector3(...hit);
      const build = PROP_BUILDERS[l.kind];
      if (build) { const prop = build(i, l); prop.position.copy(base); this.scene.add(prop); }
      const light = new THREE.PointLight(l.color, l.intensity, l.distance, 1.8);
      light.position.copy(base).add(new THREE.Vector3(0, l.kind === 'ritual-lamp' ? 1.3 : 0.7, 0));
      this.scene.add(light);
    });
  }

  get playerPos() { return this.mode === 'ant' ? this.ant.motor.pos : this.noclip.pos.toArray(); }

  setMode(mode) {
    if (mode === this.mode || !this.ready) return;
    if (mode === 'noclip') {
      this.noclip.pos.copy(this.app.camera.position);
      this.noclip.yaw = this.ant.viewYaw();
      this.noclip.pitch = 0;
    } else {
      const p = this.noclip.pos;
      this.ant.place([p.x, p.y, p.z], this.noclip.yaw);
    }
    this.mode = mode;
    this.ant.body.setVisible(mode === 'ant');
  }

  toggleMode() { this.setMode(this.mode === 'ant' ? 'noclip' : 'ant'); return this.mode; }

  resetCourse() {
    this.course.reset();
    this.markers?.sync();
    if (this.mode === 'ant') this.ant.place(this.level.spawn.pos, this.level.spawn.yaw);
  }

  preUpdate() { if (this.ready && this.mode === 'ant') this.ant.preUpdate(); }

  static now() { return performance.now() / 1000; }

  fixedUpdate(dt) {
    if (!this.ready) return;
    if (this.mode !== 'ant') { this.noclip.fixedUpdate(dt); return; }
    const a = this.ant.aim();
    const bites = this.digger.update(dt, {
      held: this.input.isDown('dig'), eye: a.eye, dir: a.dir, up: this.ant.motor.up,
      eyeHeight: CONFIG.ant.hover + CONFIG.camera.eyeOffset, now: TestTunnelsScene.now(), canDig: this.ant.motor.mode === 'surface',
    });
    this.ant.digging = this.input.isDown('dig') && this.digger.target.status === 'ok';
    for (const b of bites) {
      this.ant.bite();
      const hit = this.digger.target.hit || b.center;
      this.debris.burst(hit, b.normal, b.material, CONFIG.dig.debrisPerBite);
    }
    this.ant.fixedUpdate(dt);
  }

  update(dt) {
    this.terrainMaterial.userData.terrainUniforms.uTime.value = TestTunnelsScene.now();
    if (!this.ready) { this.noclip.update(dt); return; }
    this.world.focus = this.playerPos;
    this.world.tick(dt);
    this.debris.update(dt);
    if (this.mode === 'ant') this.ant.update(dt); else this.noclip.update(dt);
    this._zoneT += dt;
    if (this._zoneT > 0.3) { this._zoneT = 0; const p = this.playerPos; this.zone = this.world.zoneAt({ x: p[0], y: p[1], z: p[2] }); }
    this._updateCourse(dt);
  }

  _updateCourse(dt) {
    if (this.mode === 'ant') {
      const moving = this.input.move.mag > 0.1 || this.ant.motor.mode === 'air';
      const ev = this.course.update(dt, this.ant.motor.pos, moving);
      if (ev) {
        this.markers.sync();
        this.flash = ev.type === 'gate' ? `✓ ${ev.gate.name}` : `FINISH ${formatTime(ev.time)}${ev.record ? ' · RECORD' : ''}`;
        this.flashT = ev.type === 'gate' ? 1.5 : 6;
      }
    }
    this.markers.update(dt);
    if (this.flashT > 0) this.flashT -= dt;
    const c = this.course, n = c.def.gates.length;
    const head = this.flashT > 0 ? this.flash : c.finished ? `DONE ${formatTime(c.time)}` : `${c.index + 1}/${n} ${c.next.name}`;
    this.courseText = `${head} · ${formatTime(c.time)} · ★ ${c.best === null ? "—" : formatTime(c.best)}`;
  }

  debugText() {
    const p = this.playerPos, s = this.world.stats, m = this.ant.motor;
    const inside = this.world.densityAt({ x: p[0], y: p[1], z: p[2] }) > 0 ? ' (in rock)' : '';
    const ant = this.mode === 'ant'
      ? `ant ${m.mode} dist ${m.surfaceDist.toFixed(2)} spd ${m.speed.toFixed(1)}\nup ${m.up.map((v) => v.toFixed(2)).join(',')} cam ${this.ant.cameraMode}`
      : 'noclip';
    return `pos ${p.map((v) => v.toFixed(1)).join(',')}${inside}
zone ${this.zone || '-'}
${ant}
chunks ${s.meshed}/${s.chunks} · ${this.world.threads} workers · ${s.triangles} tris
load ${s.loadMs.toFixed(0)}ms (gen ${s.genMs.toFixed(0)} / mesh ${s.meshMs.toFixed(0)})
dig ${this.digger.tool.id} · ops ${s.ops} · remesh ${s.remeshes} (${s.lastRemeshMs.toFixed(0)}ms) · dirty ${this.world.dirty.size}
spoil ${Object.entries(this.world.spoil).map(([m, v]) => `${MATERIALS[m].key} ${v.toFixed(1)}`).join(' ') || '-'}`;
  }
}
