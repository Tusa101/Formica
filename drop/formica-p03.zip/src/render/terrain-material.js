// Terrain material: MeshStandardMaterial (keeps lamp, fog, tone mapping) + injected procedural shading.
import * as THREE from 'three';
import { MATERIALS } from '../data/materials.js';
import { CONFIG } from '../config.js';
import * as G from './terrain-glsl.js';

export function createTerrainMaterial() {
  const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, metalness: 0 });
  const four = MATERIALS.slice(0, 4);
  const uniforms = {
    uColA: { value: four.map((m) => new THREE.Color(m.color)) },
    uColB: { value: four.map((m) => new THREE.Color(m.color2)) },
    uRough: { value: new THREE.Vector4(...four.map((m) => m.roughness)) },
    uStrata: { value: new THREE.Vector4(...four.map((m) => m.strata)) },
    uStrataFreq: { value: CONFIG.terrain.strataFrequency },
    uTime: { value: 0 },
    uFreshTau: { value: CONFIG.terrain.freshCutSeconds },
  };
  mat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, uniforms);
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\n' + G.TERRAIN_PARS_VERTEX)
      .replace('#include <begin_vertex>', '#include <begin_vertex>\n' + G.TERRAIN_VERTEX);
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\n' + G.TERRAIN_PARS_FRAGMENT)
      .replace('#include <color_fragment>', '#include <color_fragment>\n' + G.TERRAIN_COLOR_FRAGMENT)
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n' + G.TERRAIN_ROUGH_FRAGMENT);
  };
  mat.customProgramCacheKey = () => 'formica-terrain-v2';
  mat.userData.terrainUniforms = uniforms;
  return mat;
}
