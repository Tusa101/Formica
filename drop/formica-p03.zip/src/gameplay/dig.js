// Excavation gameplay: aim ray over the density field, tool selection, bite cadence. Pure JS (tested).
import { TOOLS, biteInterval } from '../data/tools.js';
import { MATERIALS } from '../data/materials.js';

/** Marches from `eye` along unit `dir`; returns the first surface hit within `reach`, or null. */
export function aimRay(field, eye, dir, reach, step = 0.04) {
  let prev = 0;
  if (field.densityAt(eye[0], eye[1], eye[2]) > 0) return null; // eye inside rock
  for (let t = step; t <= reach; t += step) {
    const x = eye[0] + dir[0] * t, y = eye[1] + dir[1] * t, z = eye[2] + dir[2] * t;
    if (field.densityAt(x, y, z) > 0) {
      let lo = prev, hi = t;
      for (let i = 0; i < 6; i++) {
        const m = (lo + hi) / 2;
        if (field.densityAt(eye[0] + dir[0] * m, eye[1] + dir[1] * m, eye[2] + dir[2] * m) > 0) hi = m; else lo = m;
      }
      const hit = [eye[0] + dir[0] * hi, eye[1] + dir[1] * hi, eye[2] + dir[2] * hi];
      const normal = field.normalAt(hit[0], hit[1], hit[2]);
      let material = -1;
      for (const k of [0.2, 0.4, 0.05]) { // look slightly into the rock, along the ray and against the normal
        material = field.materialAt(hit[0] - normal[0] * k + dir[0] * k, hit[1] - normal[1] * k + dir[1] * k, hit[2] - normal[2] * k + dir[2] * k);
        if (material >= 0) break;
      }
      return { hit, normal, dist: hi, material };
    }
    prev = t;
  }
  return null;
}

export class Digger {
  /** @param {{field, dig(center, r, maxHardness, now)}} world */
  constructor(world, tools = TOOLS) {
    this.world = world; this.tools = tools;
    this.toolIndex = 0;
    this.timer = 0;
    this.target = null;   // last aim result + status
  }

  get tool() { return this.tools[this.toolIndex]; }

  setTool(i) { this.toolIndex = ((i % this.tools.length) + this.tools.length) % this.tools.length; this.timer = 0; }
  cycle(dir = 1) { this.setTool(this.toolIndex + dir); }

  /**
   * @param {number} dt
   * @param {{held:boolean, eye:number[], dir:number[], up?:number[], eyeHeight?:number, now:number, canDig:boolean}} s
   * @returns {Array<{center:number[], radius:number, material:number, removed:object, normal:number[]}>} bites this step
   */
  update(dt, s) {
    const tool = this.tool;
    const aim = s.canDig ? aimRay(this.world.field, s.eye, s.dir, tool.reach) : null;
    const mat = aim ? MATERIALS[aim.material] : null;
    const status = !aim || !mat ? 'none' : mat.hardness > tool.maxHardness ? 'hard' : 'ok';
    this.target = aim ? { ...aim, status, materialName: mat?.name ?? '' } : { status: 'none' };
    const bites = [];
    if (!s.held || status !== 'ok') { this.timer = Math.min(this.timer, 0); return bites; }
    this.timer -= dt;
    if (this.timer > 0) return bites;
    this.timer += biteInterval(tool, mat.hardness);
    if (this.timer < 0) this.timer = 0;
    const r = tool.radius;
    const n = aim.normal;
    const center = [aim.hit[0] - n[0] * r * 0.35, aim.hit[1] - n[1] * r * 0.35, aim.hit[2] - n[2] * r * 0.35];
    // Tunnel assist: when aiming forward (not at the floor/ceiling), lift the bite so its bottom stays level with the
    // surface the ant stands on — otherwise every bite steps the tunnel floor down. Aiming down still digs down.
    if (s.up) {
      const f = 1 - Math.abs(s.dir[0] * s.up[0] + s.dir[1] * s.up[1] + s.dir[2] * s.up[2]);
      const lift = Math.max(0, r - (s.eyeHeight ?? 0.38)) * f;
      for (let a = 0; a < 3; a++) center[a] += s.up[a] * lift;
    }
    const res = this.world.dig(center, r, tool.maxHardness, s.now);
    if (res.chunks.size) bites.push({ center, radius: r, material: aim.material, removed: res.removed, normal: n });
    return bites;
  }
}
