// Minimal HUD (GDD §58 grows here in later phases) and the debug panel.
import { BUILD, PHASE } from '../config.js';

export class Hud {
  constructor(root) {
    this.el = document.createElement('div');
    this.el.id = 'hud';
    this.el.innerHTML = `
      <div class="reticle"></div>
      <div class="aim-label"></div>
      <button class="hud-tool" data-hud="hud-tool">MANDIBLES</button>
      <div class="hud-status" data-hud="hud-status"><span class="mode">NOCLIP</span><span class="msg"></span></div>
      <div class="hud-badge" data-hud="hud-selftest" hidden></div>
      <div class="hud-course" data-hud="hud-course" hidden></div>`;
    root.appendChild(this.el);
    this.modeEl = this.el.querySelector('.mode');
    this.msgEl = this.el.querySelector('.msg');
    this.badge = this.el.querySelector('.hud-badge');
    this.courseEl = this.el.querySelector('.hud-course');
    this.reticle = this.el.querySelector('.reticle');
    this.aimLabel = this.el.querySelector('.aim-label');
    this.toolBtn = this.el.querySelector('.hud-tool');
    this.onTool = null;
    this.toolBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); this.onTool?.(); });
    this._aim = '';
  }
  setTool(name) { this.toolBtn.textContent = name; }
  /** status: 'ok' | 'hard' | 'none' */
  setAim(status, label) {
    const key = status + label;
    if (key === this._aim) return;
    this._aim = key;
    this.reticle.className = 'reticle ' + status;
    this.aimLabel.className = 'aim-label ' + status;
    this.aimLabel.textContent = status === 'none' ? '' : status === 'hard' ? `${label} · TOO HARD` : label;
  }
  setCourse(t) { if (this.courseEl.textContent !== t) this.courseEl.textContent = t; this.courseEl.hidden = !t; }
  setVisible(v) { this.el.hidden = !v; }
  setMode(t) { this.modeEl.textContent = t; }
  setMessage(t) { this.msgEl.textContent = t; }
  showSelfTest(result, persistent) {
    const ok = result.problems.length === 0;
    this.badge.hidden = !(persistent || !ok);
    this.badge.className = 'hud-badge ' + (ok ? 'ok' : 'bad');
    this.badge.textContent = ok ? `LAYOUT OK (${result.checked})` : `LAYOUT: ${result.problems.length} issue(s)`;
  }
}

export class DebugPanel {
  constructor(root, app, input) {
    this.app = app; this.input = input;
    this.el = document.createElement('pre');
    this.el.id = 'debug-panel';
    this.el.hidden = true;
    root.appendChild(this.el);
    this.layout = null;
    this.extra = () => '';
    this._t = 0;
  }
  toggle() { this.el.hidden = !this.el.hidden; }
  setLayout(result) { this.layout = result; }
  lateUpdate(dt) {
    if (this.el.hidden) return;
    this._t += dt;
    if (this._t < 0.25) return;
    this._t = 0;
    const a = this.app, r = a.renderer.info.render, i = this.input;
    const lay = this.layout
      ? (this.layout.problems.length ? 'LAYOUT ✗\n  ' + this.layout.problems.join('\n  ') : `LAYOUT OK (${this.layout.checked})`)
      : 'LAYOUT —';
    this.el.textContent =
`${PHASE} build ${BUILD}
fps ${a.fps.toFixed(0)}  cpu ${a.frameMs.toFixed(1)}ms
draws ${r.calls}  tris ${r.triangles}
res ${a.width}×${a.height} @${a.renderer.getPixelRatio().toFixed(2)}
input ${i.source}${i.pointerLocked ? ' (locked)' : ''}
move ${i.move.x.toFixed(2)},${i.move.y.toFixed(2)}
held ${[...i.held].join(' ') || '-'}
${this.extra()}
${lay}`;
  }
}
