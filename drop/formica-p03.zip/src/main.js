import { CONFIG } from './config.js';
import { App } from './core/app.js';
import { Input } from './core/input.js';
import { Shell } from './ui/shell.js';
import { TouchControls } from './ui/touch.js';
import { Hud, DebugPanel } from './ui/hud.js';
import { runLayoutSelfTest } from './ui/selftest.js';
import { TestTunnelsScene } from './scenes/test-tunnels.js';
import { TEST_TUNNELS } from './levels/test-tunnels.js';

const params = new URLSearchParams(location.search);
const touch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
document.body.classList.toggle('is-touch', touch);

const stage = document.getElementById('stage');
const uiRoot = document.getElementById('ui');

const app = new App(stage, { touch });
const input = new Input(app.canvas);
const hud = new Hud(uiRoot);
const debug = new DebugPanel(uiRoot, app, input);
const touchUI = touch ? new TouchControls(uiRoot, input, { onMenu: () => shell.showPause() }) : null;

const persistentSelfTest = params.get('selftest') === '1';
function selfTest() {
  const result = runLayoutSelfTest(CONFIG.ui.minTouchTarget);
  debug.setLayout(result);
  hud.showSelfTest(result, persistentSelfTest);
  window.__formicaLayout = result; // read by headless smoke tests
  return result;
}
let selfTestTimer = 0;
const scheduleSelfTest = () => { clearTimeout(selfTestTimer); selfTestTimer = setTimeout(selfTest, CONFIG.ui.selfTestDelayMs); };
addEventListener('resize', scheduleSelfTest);

function setPlaying(playing) {
  input.enabled = playing;
  if (!playing) input.reset();
  hud.setVisible(playing);
  touchUI?.setVisible(playing);
  scheduleSelfTest();
}

const shell = new Shell(uiRoot, {
  touch,
  onStart: () => { setPlaying(true); input.requestPointerLock(); },
  onPause: () => setPlaying(false),
  onResume: () => { setPlaying(true); input.requestPointerLock(); },
  onSelfTest: () => { debug.el.hidden = false; selfTest(); },
  onDebug: () => debug.toggle(),
  onCamera: () => { shell.setLabels({ camera: level.ant.cycleCameraMode() }); },
  onMode: () => { shell.setLabels({ mode: level.toggleMode() }); syncMode(); },
  onCourse: () => level.resetCourse(),
  onResetWorld: () => { level.world.log.clear(); location.reload(); },
});

input.on((type, value) => {
  if (type === 'press' && value === 'debug') debug.toggle();
  if (type === 'press' && value === 'noclip' && input.enabled) { shell.setLabels({ mode: level.toggleMode() }); syncMode(); }
  if (type === 'press' && value === 'camera' && input.enabled) shell.setLabels({ camera: level.ant.cycleCameraMode() });
  if (type === 'press' && value === 'tool1') setTool(0);
  if (type === 'press' && value === 'tool2') setTool(1);
  if (type === 'wheel') setTool(level.digger.toolIndex + value);
  // Desktop: leaving pointer lock (Esc) opens the pause menu.
  if (type === 'pointerlock' && value === false && !touch && shell.started && !shell.isPaused) shell.showPause();
});
addEventListener('keydown', (e) => { if (e.code === 'Escape' && touch) shell.showPause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) { shell.showPause(); level.world.save(); } });
addEventListener('pagehide', () => level.world.save());

const level = new TestTunnelsScene(app, input, TEST_TUNNELS);
app.scene = level.scene;
app.add({ preUpdate: () => input.update() });
app.add(level);
function setTool(i) { level.digger.setTool(i); hud.setTool(level.digger.tool.name); }
hud.onTool = () => setTool(level.digger.toolIndex + 1);
function syncMode() { hud.setMode(level.mode === 'ant' ? 'ANT' : 'NOCLIP'); }
shell.setLabels({ camera: level.ant.cameraMode, mode: level.mode });
app.add({ lateUpdate: () => input.endFrame() });
app.add(debug);
debug.extra = () => level.debugText();

let lastZone;
app.add({ update: () => {
  if (level.zone !== lastZone) { lastZone = level.zone; hud.setMessage(level.zone || 'Test Tunnels'); }
  hud.setCourse(level.ready ? level.courseText : '');
  const t = level.mode === 'ant' ? level.digger.target : null;
  hud.setAim(t ? t.status : 'none', t?.materialName?.toUpperCase() ?? '');
} });

syncMode();
hud.setMessage('Test Tunnels');
setPlaying(false);
if (params.get('debug') === '1') debug.toggle();

level.load((done, total) => shell.setLoading(done, total)).then(() => {
  shell.setReady();
  window.__formicaWorldReady = true;
  if (params.get('autostart') === '1') shell.goBtn.click();
}).catch((e) => window.__formicaError?.('World generation failed: ' + (e.stack || e.message || e)));

app.start();
window.__formica = { app, input, level };
window.__formicaReady = true;
