// Main-thread world: owns the density field, dispatches generation/meshing to workers, applies terrain
// operations and batches remeshing (ADD §36, §40). No Three.js here; the renderer subscribes via onChunkMesh.
import { CONFIG } from '../config.js';
import { DensityField, ChunkState } from './field.js';
import { WorkerPool } from './pool.js';
import { buildLevelField } from './levelfield.js';
import { carveSphere } from './terrain-ops.js';
import { DigLog } from './persistence.js';
import { MATERIALS } from '../data/materials.js';

const hardnessOf = (m) => MATERIALS[m]?.hardness ?? 1;

export class World {
  constructor(level, storage = null) {
    const W = CONFIG.world;
    this.level = level;
    this.N = W.chunkCells;
    this.voxel = W.voxel;
    this.field = new DensityField(this.N, this.voxel, level.chunks.min, level.chunks.max);
    this.analytic = buildLevelField(level); // zone names / debugging only — gameplay reads this.field
    const threads = Math.max(1, Math.min(W.maxWorkers, (navigator.hardwareConcurrency || 2) - 1));
    this.pool = new WorkerPool(new URL('./worker.js', import.meta.url), threads);
    this.threads = threads;
    this.onChunkMesh = null;
    this.log = new DigLog(level, storage);
    this.dirty = new Set();
    this.focus = [0, 0, 0];
    this._flushT = 0;
    this.stats = { chunks: 0, meshed: 0, triangles: 0, genMs: 0, meshMs: 0, loadMs: 0, remeshes: 0, lastRemeshMs: 0, ops: 0 };
    this.spoil = {}; // removed volume per material id (ADD §54)
  }

  async load(onProgress = () => {}) {
    const { min, max } = this.level.chunks;
    const size = this.field.size;
    const sp = this.level.spawn.pos;
    const list = [];
    for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++) {
      const d = Math.hypot((cx + 0.5) * size - sp[0], (cy + 0.5) * size - sp[1], (cz + 0.5) * size - sp[2]);
      list.push({ cx, cy, cz, d });
    }
    list.sort((a, b) => a.d - b.d); // nearest first
    const t0 = performance.now();
    let done = 0;
    onProgress(0, list.length);
    await Promise.all(list.map(async ({ cx, cy, cz }) => {
      const r = await this.pool.run({ type: 'generate', levelId: this.level.id, cx, cy, cz, N: this.N, voxel: this.voxel });
      const chunk = this.field.set(cx, cy, cz, { density: r.density, material: r.material, allSolid: r.allSolid, allEmpty: r.allEmpty });
      this.stats.chunks++;
      this.stats.genMs += r.genMs;
      if (r.mesh) {
        this.stats.meshed++;
        this.stats.meshMs += r.meshMs;
        this.stats.triangles += r.mesh.triangleCount;
        this._show(chunk, r.mesh);
      }
      onProgress(++done, list.length);
    }));
    // replay saved excavation, then remesh what it touched before the player sees the world
    const ops = this.log.load();
    for (const [x, y, z, r, mh] of ops) this._carve([x, y, z], r, mh, 0);
    this.stats.ops = ops.length;
    await this.flush(true);
    this.stats.loadMs = performance.now() - t0;
  }

  _show(chunk, mesh) {
    chunk.state = mesh && mesh.triangleCount ? ChunkState.ACTIVE : ChunkState.DATA_ONLY;
    if (this.onChunkMesh) this.onChunkMesh(chunk, mesh);
  }

  _carve(c, r, maxHardness, now) {
    const res = carveSphere(this.field, c, r, { maxHardness, hardness: hardnessOf, now });
    for (const ch of res.chunks) this.dirty.add(ch);
    for (const [m, v] of Object.entries(res.removed)) this.spoil[m] = (this.spoil[m] || 0) + v;
    return res;
  }

  /** Player/tool excavation: applied to the field immediately, logged, remeshed in the next batch. */
  dig(center, radius, maxHardness, now) {
    const res = this._carve(center, radius, maxHardness, now);
    if (res.chunks.size) { this.log.push([center[0], center[1], center[2], radius, maxHardness]); this.stats.ops++; }
    return res;
  }

  /** Sends dirty chunks to the workers, nearest to `focus` first. `wait` resolves when all are meshed. */
  flush(wait = false) {
    const f = this.focus, s = this.field.size;
    const list = [...this.dirty].filter((c) => !c.inFlight)
      .sort((a, b) => Math.hypot((a.cx + 0.5) * s - f[0], (a.cy + 0.5) * s - f[1], (a.cz + 0.5) * s - f[2]) -
        Math.hypot((b.cx + 0.5) * s - f[0], (b.cy + 0.5) * s - f[1], (b.cz + 0.5) * s - f[2]));
    const jobs = list.map(async (ch) => {
      this.dirty.delete(ch);
      ch.inFlight = true;
      const t0 = performance.now();
      try {
        const r = await this.pool.run({
          type: 'mesh', N: this.N, voxel: this.voxel, cx: ch.cx, cy: ch.cy, cz: ch.cz, version: ch.version,
          density: ch.density.slice(), material: ch.material.slice(), cutTime: ch.cutTime ? ch.cutTime.slice() : null,
        });
        this.stats.remeshes++;
        this.stats.lastRemeshMs = performance.now() - t0;
        this._show(ch, r.mesh);
      } finally { ch.inFlight = false; }
    });
    return wait ? Promise.all(jobs).then(() => (this.dirty.size ? this.flush(true) : undefined)) : Promise.resolve();
  }

  /** Called every frame by the scene: batched remesh + autosave. */
  tick(dt) {
    this._flushT += dt;
    if (this._flushT >= CONFIG.dig.remeshInterval && this.dirty.size) { this._flushT = 0; this.flush(); }
    this._saveT = (this._saveT || 0) + dt;
    if (this._saveT >= CONFIG.dig.autosaveInterval) { this._saveT = 0; this.save(); }
  }

  save() { return this.log.save(); }

  zoneAt(p) { return this.analytic.zoneAt(p.x, p.y, p.z); }
  densityAt(p) { return this.field.densityAt(p.x, p.y, p.z); }
}
