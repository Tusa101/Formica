// Persistent terrain (ADD §72): untouched chunks come from the seed; edits are stored as an operation log.
export const SAVE_VERSION = 1;

export class DigLog {
  constructor(level, storage) {
    this.key = `formica.world.${level.id}.${level.seed}`;
    this.storage = storage;
    this.ops = [];
    this.dirty = false;
  }

  load() {
    try {
      const raw = this.storage?.getItem(this.key);
      if (!raw) return [];
      const data = JSON.parse(raw);
      if (data.v !== SAVE_VERSION || !Array.isArray(data.ops)) return [];
      this.ops = data.ops;
      return this.ops;
    } catch { return []; }
  }

  /** @param {[number,number,number,number,number]} op x, y, z, radius, maxHardness */
  push(op) {
    this.ops.push(op.map((v) => Math.round(v * 1000) / 1000));
    this.dirty = true;
  }

  save() {
    if (!this.dirty) return true;
    try {
      this.storage?.setItem(this.key, JSON.stringify({ v: SAVE_VERSION, ops: this.ops }));
      this.dirty = false;
      return true;
    } catch { return false; } // quota: keep dirty, report via caller
  }

  clear() {
    this.ops = []; this.dirty = false;
    try { this.storage?.removeItem(this.key); } catch { /* ignore */ }
  }
}
