import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EXACT, PATTERNS } from '../src/i18n/ru.js';

const tr = (s) => { let out = EXACT[s]; if (out !== undefined) return out; out = s; for (const [re, rep] of PATTERNS) { re.lastIndex = 0; if (re.test(out)) { re.lastIndex = 0; out = out.replace(re, rep); } } return out; };

test('Russian: key UI phrases and composed strings translate', () => {
  assert.equal(tr('SCAN'), 'СКАН');
  assert.equal(tr('GOAL · Follow the shelter signal'), 'ЦЕЛЬ · Иди на сигнал убежища');
  assert.equal(tr('SIGNAL STRENGTH: 42%'), 'СИЛА СИГНАЛА: 42%');
  assert.equal(tr('NEW TECHNOLOGY ANALYZED · BLUEPRINT FRAGMENT 1 / 2'), 'НОВАЯ ТЕХНОЛОГИЯ · ФРАГМЕНТ ЧЕРТЕЖА 1 / 2');
  assert.equal(tr('SALVAGED +2 formic metal +1 membrane'), 'РАЗОБРАНО +2 формиковый металл +1 мембрана');
  assert.equal(tr('YOU BLACK OUT (spider bite) · you wake in the shelter'), 'ТЫ ТЕРЯЕШЬ СОЗНАНИЕ (укус паука) · ты просыпаешься в убежище');
  assert.equal(tr('VIBRATION ↑ ahead'), 'ВИБРАЦИЯ ↑ впереди');
  assert.equal(tr('APPROX. DISTANCE ~40 u'), 'РАССТОЯНИЕ ≈ 40 ед');
  assert.ok(tr('SHORTCUT? ~4.0 u of rock → ROOM B · walking ~45 u').startsWith('КОРОТКИЙ ПУТЬ? ≈4.0 ед породы → ЗАЛ Б'));
  assert.equal(tr('Room A'), 'Зал А');
});

test('every story goal and hint-free phrase used by the scene has a translation', () => {
  for (const g of ['Follow the shelter signal', 'Restore the starter generator', 'Follow a local signal (tap the signal plate)',
    'Analyze what you find (hold SCAN) and salvage it', 'Return to the Fabricator and build what you learned',
    'Reach and repair the long-range beacon (north rubble)', 'Power the beacon (auxiliary generator) and transmit']) assert.ok(EXACT[g], g);
});
