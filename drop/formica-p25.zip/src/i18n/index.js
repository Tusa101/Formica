// Localisation (P25). English stays the source language in code and data; Russian is applied as
// (1) overlays on display-only data (item/module/catalog names, lore, level texts) before the scene is built, and
// (2) tr(): exact phrases + patterns for composed UI strings, used by HUD sinks and by a DOM observer as a safety net.
let dict = null;
export let LANG = 'en';

export async function setLanguage(lang, data) {
  LANG = lang === 'ru' ? 'ru' : 'en';
  if (LANG !== 'ru') { dict = null; return; }
  const ru = await import('./ru.js');
  dict = ru;
  ru.applyOverlays(data);
}

const cache = new Map();
/** Translates a UI string (exact match, then patterns). Unknown strings pass through unchanged. */
export function tr(s) {
  if (!dict || s == null || s === '') return s;
  s = String(s);
  if (cache.has(s)) return cache.get(s);
  let out = dict.EXACT[s] ?? dict.EXACT[s.trim()];
  if (out === undefined) {
    out = s;
    for (const [re, rep] of dict.PATTERNS) {
      re.lastIndex = 0;
      if (re.test(out)) { re.lastIndex = 0; out = out.replace(re, rep); }
    }
  }
  if (cache.size > 4000) cache.clear();
  cache.set(s, out);
  return out;
}

/** Translates every text node under root that has a translation. */
export function translateTree(root) {
  if (!dict || !root) return;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    const v = n.nodeValue; if (!v || !/[A-Za-z]/.test(v)) continue;
    const t = tr(v); if (t !== v) n.nodeValue = t;
  }
}

/** Keeps translating whatever the UI writes (panels, notices, lists). */
export function observeTranslations(root) {
  if (!dict || !root) return;
  translateTree(root);
  new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === 'characterData') { const v = m.target.nodeValue; if (v && /[A-Za-z]/.test(v)) { const t = tr(v); if (t !== v) m.target.nodeValue = t; } }
      else for (const n of m.addedNodes) { if (n.nodeType === 3) { const v = n.nodeValue; const t = tr(v); if (t !== v) n.nodeValue = t; } else if (n.nodeType === 1) translateTree(n); }
    }
  }).observe(root, { subtree: true, childList: true, characterData: true });
}
