// NAV-CARAPACE 3D map (GDD §44): a hologram of the space the ant has seen — cave walls as a point shell tinted by height,
// the route walked, pheromone markers and beacons. Rendered as its own scene in the same canvas.
import * as THREE from 'three';
import { MARKERS } from '../gameplay/exploration.js';

export class MapView {
  constructor() {
    const s = (this.scene = new THREE.Scene());
    s.background = new THREE.Color(0x040708);
    s.add(new THREE.HemisphereLight(0x9fe8dc, 0x101010, 1.2));
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 500);
    this.cloud = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({ size: 0.32, vertexColors: true, transparent: true, opacity: 0.85, sizeAttenuation: true, depthWrite: false }));
    this.route = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0xe8f4f0, transparent: true, opacity: 0.7 }));
    this.player = new THREE.Mesh(new THREE.ConeGeometry(0.45, 1.3, 10), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    this.markers = new THREE.Group();
    this.beacons = new THREE.Group();
    for (const o of [this.cloud, this.route]) o.frustumCulled = false;
    s.add(this.cloud, this.route, this.player, this.markers, this.beacons);
    this.yaw = 0.6; this.pitch = 0.75; this.dist = 26; this.target = new THREE.Vector3();
    this.version = -1;
    this._c = new THREE.Color();
  }

  /** Rebuilds the point shell: seen open cells that border rock. */
  _cloud(ex, nav) {
    const [X, Y] = nav.dims, pos = [], col = [];
    let minY = Infinity, maxY = -Infinity;
    const cells = [];
    for (let i = 0; i < nav.count; i++) {
      if (!ex.seen[i] || !nav.open[i]) continue;
      const x = i % X, y = Math.floor(i / X) % Y;
      const border = (x > 0 && !nav.open[i - 1]) || (x + 1 < X && !nav.open[i + 1]) || (y > 0 && !nav.open[i - X]) || (y + 1 < Y && !nav.open[i + X]) ||
        (i - X * Y >= 0 && !nav.open[i - X * Y]) || (i + X * Y < nav.count && !nav.open[i + X * Y]);
      if (!border) continue;
      const p = nav.worldPos(i); cells.push(p);
      if (p[1] < minY) minY = p[1]; if (p[1] > maxY) maxY = p[1];
    }
    const lo = new THREE.Color(0x1f5a52), hi = new THREE.Color(0xa8f0e2);
    for (const p of cells) {
      pos.push(p[0], p[1], p[2]);
      const c = this._c.copy(lo).lerp(hi, maxY > minY ? (p[1] - minY) / (maxY - minY) : 0.5);
      col.push(c.r, c.g, c.b);
    }
    const g = this.cloud.geometry;
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3));
    g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(col), 3));
  }

  sync(ex, nav, player, heading, beacons) {
    if (ex.version !== this.version) {
      this.version = ex.version;
      this._cloud(ex, nav);
      this.route.geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(ex.route.flat()), 3));
      this.markers.clear();
      for (const m of ex.markers) {
        const mk = new THREE.Mesh(new THREE.OctahedronGeometry(0.45, 0), new THREE.MeshBasicMaterial({ color: MARKERS[m.type].color }));
        mk.position.set(m.pos[0], m.pos[1] + 1.2, m.pos[2]);
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.2, 4), new THREE.MeshBasicMaterial({ color: MARKERS[m.type].color }));
        stem.position.set(m.pos[0], m.pos[1] + 0.6, m.pos[2]);
        this.markers.add(mk, stem);
      }
    }
    this.beacons.clear();
    for (const b of beacons) {
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 8, 6), new THREE.MeshBasicMaterial({ color: b.color, transparent: true, opacity: 0.55 }));
      beam.position.set(b.pos[0], b.pos[1] + 4, b.pos[2]);
      this.beacons.add(beam);
    }
    this.player.position.set(player[0], player[1] + 0.6, player[2]);
    this.player.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(heading[0], 0, heading[2]).normalize());
  }

  recenter(p) { this.target.set(p[0], p[1], p[2]); }
  orbit(dx, dy) { this.yaw -= dx * 0.008; this.pitch = Math.max(0.1, Math.min(1.5, this.pitch + dy * 0.006)); }
  zoom(f) { this.dist = Math.max(6, Math.min(120, this.dist * f)); }

  updateCamera(aspect) {
    const c = this.camera, t = this.target;
    c.aspect = aspect; c.updateProjectionMatrix();
    c.position.set(t.x + Math.sin(this.yaw) * Math.cos(this.pitch) * this.dist, t.y + Math.sin(this.pitch) * this.dist, t.z + Math.cos(this.yaw) * Math.cos(this.pitch) * this.dist);
    c.lookAt(t);
  }
}
