// Debug "map" (P04; the real NAV-CARAPACE map is P09): region graph drawn through rock, coloured per cavity,
// plus the beetle's current path.
import * as THREE from 'three';

const PALETTE = [0x5fd0c0, 0xe0a64a, 0x9f8fd8, 0xc8574b, 0x7fd07a];

export class GraphView {
  constructor(scene) {
    const mk = (color, opacity) => new THREE.LineBasicMaterial({ color, transparent: true, opacity, depthTest: false, vertexColors: color === null });
    this.group = new THREE.Group();
    this.group.renderOrder = 10;
    this.edges = new THREE.LineSegments(new THREE.BufferGeometry(), mk(null, 0.55));
    this.nodes = new THREE.Points(new THREE.BufferGeometry(),
      new THREE.PointsMaterial({ size: 0.16, vertexColors: true, transparent: true, opacity: 0.9, depthTest: false }));
    this.path = new THREE.Line(new THREE.BufferGeometry(), mk(0xe0a64a, 0.9));
    this.scent = new THREE.Points(new THREE.BufferGeometry(),
      new THREE.PointsMaterial({ size: 0.09, vertexColors: true, transparent: true, opacity: 0.8, depthTest: false }));
    this._airT = 0;
    for (const o of [this.edges, this.nodes, this.path, this.scent]) { o.frustumCulled = false; o.renderOrder = 10; this.group.add(o); }
    this.group.visible = false;
    scene.add(this.group);
    this.version = -1;
    this._c = new THREE.Color();
  }

  get visible() { return this.group.visible; }
  toggle() { this.group.visible = !this.group.visible; return this.group.visible; }

  /**
   * @param {object} topology
   * @param {number[][]|null} beetlePath
   * @param {import('../world/atmosphere.js').Atmosphere|null} air  colours nodes by air quality, draws scent
   */
  update(topology, beetlePath, air = null, dt = 0) {
    if (!this.group.visible) return;
    const g = topology.graph;
    this._airT -= dt;
    if (air && this._airT <= 0) { this._airT = 0.5; this.version = -1; this._scent(topology.nav, air); }
    if (g.version !== this.version) {
      this.version = g.version;
      const labels = [...new Set(g.nodes.map((n) => n.label))].sort((a, b) => (topology.nav.sizes.get(b) || 0) - (topology.nav.sizes.get(a) || 0));
      const colorOf = (lab) => this._c.set(PALETTE[labels.indexOf(lab) % PALETTE.length]);
      const np = new Float32Array(g.nodes.length * 3), nc = new Float32Array(g.nodes.length * 3);
      const bad = new THREE.Color(0xc8574b), good = new THREE.Color(0x5fd0c0);
      g.nodes.forEach((n, i) => {
        np.set(n.pos, i * 3);
        const c = air ? this._c.copy(bad).lerp(good, air.quality(n.pos)) : colorOf(n.label);
        nc.set([c.r, c.g, c.b], i * 3);
      });
      const ep = [], ec = [];
      g.adj.forEach((m, u) => { for (const v of m.keys()) if (v > u) {
        ep.push(...g.nodes[u].pos, ...g.nodes[v].pos);
        const c = colorOf(g.nodes[u].label); ec.push(c.r, c.g, c.b, c.r, c.g, c.b);
      } });
      this._set(this.nodes.geometry, np, nc);
      this._set(this.edges.geometry, new Float32Array(ep), new Float32Array(ec));
    }
    const pts = beetlePath ? beetlePath.flat() : [];
    this._set(this.path.geometry, new Float32Array(pts), null);
  }

  _scent(nav, air) {
    const pos = [], col = [];
    const tint = { player: [0.85, 0.95, 0.95], beetle: [0.88, 0.65, 0.29] };
    for (const [owner, arr] of air.scent) {
      const t = tint[owner] || [0.7, 0.7, 0.9];
      for (const i of air.open) {
        if (arr[i] < 0.02) continue;
        const p = nav.worldPos(i);
        pos.push(p[0], p[1] - 0.3, p[2]);
        const k = Math.min(1, 0.3 + arr[i] * 3);
        col.push(t[0] * k, t[1] * k, t[2] * k);
        if (pos.length > 9000) break;
      }
    }
    this._set(this.scent.geometry, new Float32Array(pos), new Float32Array(col));
  }

  _set(geo, pos, col) {
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    if (col) geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.computeBoundingSphere?.();
  }
}
