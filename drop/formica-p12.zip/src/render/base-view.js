// GREYBOX shelter modules and placed infrastructure. Replaced by PIPE §43 assets (Air Processor is in the first art test).
import * as THREE from 'three';
import { MODULE_TYPES } from '../data/modules.js';

const M = {
  chitin: new THREE.MeshStandardMaterial({ color: 0x3b2c20, roughness: 0.45, metalness: 0.05 }),
  resin: new THREE.MeshStandardMaterial({ color: 0xb57f35, roughness: 0.3, transparent: true, opacity: 0.8 }),
  dark: new THREE.MeshStandardMaterial({ color: 0x1c1a18, roughness: 0.7 }),
  screen: new THREE.MeshStandardMaterial({ color: 0x0d1c1c, emissive: 0x5fd0c0, emissiveIntensity: 0.0, roughness: 0.3 }),
};
const LAMP = { on: 0x5fd0c0, degraded: 0xe0a64a, broken: 0xc8574b, off: 0x222222 };

function body(type) {
  const g = new THREE.Group();
  const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); g.add(m); return m; };
  switch (type) {
    case 'storage':
      for (let i = 0; i < 2; i++) add(new THREE.BoxGeometry(0.9, 0.55, 0.6), M.chitin, 0, 0.3 + i * 0.6, 0);
      break;
    case 'condenser': add(new THREE.CylinderGeometry(0.28, 0.35, 0.9, 12), M.chitin, 0, 0.45, 0); add(new THREE.SphereGeometry(0.28, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), M.resin, 0, 0.9, 0); break;
    case 'terminal': add(new THREE.CylinderGeometry(0.05, 0.08, 0.7, 6), M.chitin, 0, 0.35, 0); { const s = add(new THREE.BoxGeometry(0.5, 0.35, 0.05), M.screen.clone(), 0, 0.8, 0); s.rotation.x = -0.5; g.userData.screen = s; } break;
    case 'power': add(new THREE.CylinderGeometry(0.45, 0.5, 0.6, 14), M.chitin, 0, 0.3, 0); for (let i = 0; i < 3; i++) add(new THREE.CylinderGeometry(0.07, 0.07, 0.25, 8), M.resin, -0.2 + i * 0.2, 0.72, 0); break;
    case 'air': add(new THREE.BoxGeometry(0.8, 0.9, 0.6), M.chitin, 0, 0.45, 0); { const f = add(new THREE.CylinderGeometry(0.28, 0.28, 0.05, 12), M.dark, 0, 0.55, 0.32); f.rotation.x = Math.PI / 2; g.userData.fan = f; } break;
    case 'fabricator': add(new THREE.BoxGeometry(1.0, 0.5, 0.7), M.chitin, 0, 0.25, 0); { const a = add(new THREE.CylinderGeometry(0.04, 0.04, 0.6, 6), M.dark, 0.3, 0.75, 0); a.rotation.z = 0.6; } break;
    case 'beacon': add(new THREE.CylinderGeometry(0.06, 0.12, 1.8, 8), M.dark, 0, 0.9, 0); add(new THREE.SphereGeometry(0.14, 10, 8), M.chitin, 0, 1.85, 0); break;
    case 'pipe': add(new THREE.CylinderGeometry(0.1, 0.13, 0.3, 8), M.chitin, 0, 0.15, 0); break;
    case 'booster': add(new THREE.CylinderGeometry(0.2, 0.25, 0.5, 10), M.chitin, 0, 0.25, 0); { const f = add(new THREE.CylinderGeometry(0.16, 0.16, 0.04, 10), M.dark, 0, 0.52, 0); g.userData.fan = f; } break;
    case 'camp': { const d = add(new THREE.SphereGeometry(0.55, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), M.resin, 0, 0, 0); d.scale.y = 0.8; } break;
    default: break;
  }
  return g;
}

export class BaseView {
  constructor(scene, field) {
    this.scene = scene; this.field = field;
    this.views = new Map();
    this.links = new THREE.LineSegments(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0x5fd0c0, transparent: true, opacity: 0.5 }));
    this.links.frustumCulled = false;
    scene.add(this.links);
    this.lights = [];
    this.t = 0;
  }

  /** Floor position for a module definition (lighting hangs where it is defined). */
  ground(m) {
    if (m.type === 'lighting' || m.placed) return m.pos;
    const s = this.field.dropToSurface(m.pos, 6);
    return s || m.pos;
  }

  sync(base) {
    for (const m of base.modules) {
      if (!this.views.has(m.id)) {
        const g = body(m.type);
        const p = this.ground(m);
        m.floor = p;
        g.position.set(p[0], p[1], p[2]);
        const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), new THREE.MeshBasicMaterial({ color: LAMP.off }));
        lamp.position.set(0.25, m.type === 'beacon' ? 1.2 : 0.8, 0.25);
        if (m.type !== 'lighting') g.add(lamp);
        this.scene.add(g);
        const v = { g, lamp };
        if (m.type === 'lighting') {
          for (const dx of [-2, 2]) {
            const l = new THREE.PointLight(0xffe2b0, 5, 9, 1.8); l.position.set(p[0] + dx, p[1], p[2]);
            const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffe2b0 }));
            bulb.position.copy(l.position); this.scene.add(l, bulb); this.lights.push({ l, bulb });
          }
        }
        if (m.type === 'camp') { const l = new THREE.PointLight(0xe0a64a, 3, 6, 1.8); l.position.set(p[0], p[1] + 0.6, p[2]); this.scene.add(l); v.light = l; }
        this.views.set(m.id, v);
      }
      const v = this.views.get(m.id);
      const state = m.state === 'working' ? (m.powered || !(MODULE_TYPES[m.type].draw > 0) ? 'on' : 'off') : m.state === 'degraded' ? 'degraded' : 'broken';
      const lampState = m.type === 'power' && !(m.fuel > 0) ? 'off' : m.type === 'camp' ? (m.battery > 0 ? 'degraded' : 'off') : state;
      v.lamp.material.color.set(LAMP[lampState] ?? LAMP.off);
      v.powered = m.powered; v.state = m.state;
      if (v.g.userData.screen) v.g.userData.screen.material.emissiveIntensity = m.powered || m.state === 'working' ? 0.9 : 0;
      if (v.light) v.light.visible = m.battery > 0;
    }
    const lit = base.get('lights')?.powered;
    for (const { l, bulb } of this.lights) { l.visible = !!lit; bulb.visible = !!lit; }
    // air network links
    const pos = [];
    for (const [child, parent] of base.parent || []) {
      const a = base.get(child)?.floor, b = base.get(parent)?.floor;
      if (a && b) pos.push(a[0], a[1] + 0.25, a[2], b[0], b[1] + 0.25, b[2]);
    }
    this.links.geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3));
  }

  update(dt, base) {
    this.t += dt;
    for (const m of base.modules) {
      const v = this.views.get(m.id);
      if (v?.g.userData.fan && m.powered) v.g.userData.fan.rotation.y += dt * (m.state === 'working' ? 12 : 3);
      if (m.state === 'degraded' && v) v.lamp.visible = Math.sin(this.t * 7 + m.pos[0]) > -0.3;
    }
  }

  /** Module nearest to the view ray within reach. */
  aimed(base, eye, dir, reach = 2.6) {
    let best = null, bd = Infinity;
    for (const m of base.modules) {
      const p = m.floor || m.pos;
      const c = [p[0], p[1] + (m.type === 'lighting' ? 0 : 0.5), p[2]];
      const v = [c[0] - eye[0], c[1] - eye[1], c[2] - eye[2]];
      const t = v[0] * dir[0] + v[1] * dir[1] + v[2] * dir[2];
      if (t < 0 || t > reach) continue;
      const off = Math.hypot(v[0] - dir[0] * t, v[1] - dir[1] * t, v[2] - dir[2] * t);
      if (off < 0.55 && t < bd) { bd = t; best = m; }
    }
    return best;
  }
}
