// GREYBOX first-person ant body: mandibles at the bottom of the view, antenna tips at the top.
// Replaced by the evolved-ant model from the Blender pipeline (PIPE §43, AB §26).
import * as THREE from 'three';

function strand(points, radius, mat) {
  const curve = new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(...p)));
  return new THREE.Mesh(new THREE.TubeGeometry(curve, 16, radius, 6, false), mat);
}

export class AntBody {
  constructor(camera) {
    const chitin = new THREE.MeshStandardMaterial({ color: 0x2b1e15, roughness: 0.45, metalness: 0.08 });
    this.group = new THREE.Group();
    this.group.name = 'ant-body (GREYBOX)';
    this.mandibles = [-1, 1].map((s) => {
      const pivot = new THREE.Group();
      pivot.position.set(0.07 * s, -0.078, -0.115);
      pivot.add(strand([[0, 0, 0], [-0.012 * s, 0.006, -0.045], [-0.042 * s, 0.012, -0.075]], 0.0075, chitin));
      this.group.add(pivot);
      return pivot;
    });
    this.antennae = [-1, 1].map((s) => {
      const pivot = new THREE.Group();
      pivot.position.set(0.05 * s, 0.085, -0.11);
      pivot.add(strand([[0, 0, 0], [0.03 * s, 0.03, -0.06], [0.07 * s, 0.035, -0.16]], 0.0035, chitin));
      this.group.add(pivot);
      return pivot;
    });
    camera.add(this.group);
    this.t = 0;
    this.open = 0;
  }

  setVisible(v) { this.group.visible = v; }
  chomp() { this.open = -0.15; }

  update(dt, speed, digHeld) {
    this.t += dt * (1 + speed * 3);
    this.open += ((digHeld ? 1 : 0) - this.open) * Math.min(1, dt * 12);
    const sway = Math.sin(this.t * 2.2) * 0.04;
    this.mandibles.forEach((m, i) => { const s = i ? 1 : -1; m.rotation.y = s * (0.05 + this.open * 0.35) + sway * 0.3; });
    this.antennae.forEach((a, i) => { a.rotation.x = Math.sin(this.t * 1.7 + i) * 0.08; a.rotation.z = Math.sin(this.t * 1.1 + i * 2) * 0.06; });
  }
}
