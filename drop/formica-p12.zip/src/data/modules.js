// Base modules (GDD §16–17, ADD §8). draw/supply in power units; repair = materials to reach 'working'.
export const MODULE_TYPES = Object.freeze({
  storage:    { name: 'STORAGE', draw: 0, desc: 'Sealed chitin lockers. Items left here are safe.' },
  lighting:   { name: 'EMERGENCY LIGHTING', draw: 0.3, desc: 'Resin-glass lamps.' },
  condenser:  { name: 'WATER CONDENSER', draw: 0.2, desc: 'Pulls water from the damp air.' },
  terminal:   { name: 'MAINTENANCE TERMINAL', draw: 0, desc: 'Shelter log.' },
  power:      { name: 'POWER NODE', supply: { working: 3, degraded: 1.5 }, desc: 'Burns chemical cells.',
    repair: { degraded: { resin: 2, scrap: 1 } } },
  air:        { name: 'AIR PROCESSOR', draw: 1, airRadius: { working: 4.5, degraded: 1.6 }, desc: 'Scrubs CO₂, releases oxygen.',
    repair: { degraded: { resin: 2, chitin: 1, scrap: 1 } } },
  fabricator: { name: 'FABRICATOR', draw: 1, desc: 'Builds infrastructure from field materials.',
    repair: { damaged: { resin: 3, scrap: 2, chitin: 1 } } },
  beacon:     { name: 'LONG RANGE BEACON', draw: 2, desc: 'Ritual beacon. Silent for years.',
    repair: { broken: { scrap: 4, chitin: 2, resin: 2 } } },
  pipe:       { name: 'AIR PIPE', draw: 0, link: 6, airRadius: { working: 1.8 }, desc: 'Carries processed air.' },
  booster:    { name: 'AIR BOOSTER', draw: 0.5, link: 12, airRadius: { working: 2.8 }, desc: 'Pushes air down long pipe runs.' },
  camp:       { name: 'FORWARD CAMP', draw: 0, airRadius: { working: 2.6 }, battery: 100, drain: 100 / 600, desc: 'Minimal camp: air bubble, light, a place to wake up.' },
});

export const STATE_LABEL = Object.freeze({ working: 'WORKING', degraded: 'DEGRADED', damaged: 'DAMAGED', broken: 'BROKEN', offline: 'NO POWER' });
