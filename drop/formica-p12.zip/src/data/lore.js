// Authored text (ADD §8: the maintenance log is an early crack in the hero's picture of home).
export const MAINTENANCE_LOG = Object.freeze([
  'RITUAL SHELTER 7 — MAINTENANCE REGISTER',
  'Cycle 402 · Full service. Air processor filters replaced. Beacon calibrated. Signed: Warden Ilse.',
  'Cycle 403 · Routine inspection. Fabricator feed jammed, cleared.',
  'Cycle 404 · Inspection POSTPONED by order of the Council of Return.',
  'Cycle 405 · —',
  'Cycle 406 · —',
  'Cycle 407 · Automated entry: power node degraded. No response.',
  '…',
  'Automated entry: 31 cycles without service.',
  'Automated entry: beacon silent. Ritual route status: UNKNOWN.',
]);

// P11 — the Rite (GDD §1, §63–64; ADD §3–4). Recordings explain only what a relative plausibly would (ADD §3).
export const ESCORT = Object.freeze([
  { who: 'ESCORT', text: 'This is where we leave you. Walk east. Do not follow us.' },
  { who: 'ESCORT', text: 'Seal it.' },
]);
export const RITE_KIT_BOOT = Object.freeze(['RITE KIT · IDENTITY CONFIRMED', 'RETURN-ROUTE DATA PURGED', 'RITUAL SHELTER SIGNAL DETECTED', 'APPROX. DISTANCE']);
export const RECORDINGS = Object.freeze({
  start: [
    { who: 'MOTHER · recording', text: 'If you are hearing this, they have left you. That is the rite. Everyone before you walked it.' },
    { who: 'MOTHER · recording', text: 'Follow the shelter signal. It points, it does not lead — the tunnels will not be straight.' },
  ],
  resin: [{ who: 'MOTHER · recording', text: 'If you see amber resin, take some. Those old shelters always leak somewhere.' }],
  air: [{ who: 'MOTHER · recording', text: 'If the air turns sour, do not be brave. Turn back and breathe.' }],
  spider: [{ who: 'MOTHER · recording', text: 'Things live down there that were there long before us. Most of them only want you gone. Let them have it.' }],
  shelter: [
    { who: 'MOTHER · recording', text: 'You reached the shelter. Good. The wardens keep them ready — the beacon will tell them you are alive.' },
  ],
  log: [{ who: 'MOTHER · recording', text: '…your uncle never came back from his rite. They said it was the flood. I stopped asking.' }],
  beacon: [{ who: 'MOTHER · recording', text: 'If the beacon answers, say your name. Say it clearly. They will—' }, { who: 'RECORDING', text: '[the recording ends in static]' }],
});
export const TRANSMISSION = Object.freeze([
  { text: '…carrier found…', pause: 1.6 },
  { text: 'If anyone receives this signal — the old way home no longer exists.', pause: 3.4 },
  { text: '[static]', pause: 1.8 },
  { text: 'Do not try to go back.', pause: 3.0 },
  { text: '[silence]', pause: 2.2 },
  { text: 'They did not tell you why the rite really exists.', pause: 4.0 },
]);
