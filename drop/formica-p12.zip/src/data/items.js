// Items (GDD §15, ADD §5). weight in carry units; `use` names the effect applied by Survival.use().
export const ITEMS = Object.freeze({
  resin:          { name: 'Amber Resin',     weight: 0.5, desc: 'Sticky tree resin. Seals, patches, binds.' },
  fungus:         { name: 'Cave Fungus',     weight: 0.4, use: { energy: 12 }, verb: 'EAT', desc: 'Edible, bland, filling enough.' },
  seed:           { name: 'Seed',            weight: 0.6, use: { energy: 8, hydration: 3 }, verb: 'EAT', desc: 'A dropped seed from the surface.' },
  chitin:         { name: 'Chitin Scrap',    weight: 0.4, desc: 'Shed exoskeleton plate. Light and tough.' },
  scrap:          { name: 'Human Scrap',     weight: 0.8, desc: 'Foil, wire, a battery fragment — human debris.' },
  food_ration:    { name: 'Food Portion',    weight: 0.5, use: { energy: 40 }, verb: 'EAT', desc: 'Packed ration from the Rite Kit.' },
  water:          { name: 'Water Capsule',   weight: 0.5, use: { hydration: 35 }, verb: 'DRINK', desc: 'A sealed sip of clean water.' },
  air_capsule:    { name: 'Air Capsule',     weight: 0.5, use: { breath: 100, airBuffer: 60 }, verb: 'BREATHE', desc: 'Emergency air: a minute of clean breath.' },
  resin_patch:    { name: 'Resin Patch',     weight: 0.3, use: { health: 30 }, verb: 'APPLY', desc: 'Seals cracks in the carapace.' },
  resin_support:  { name: 'Resin Support',   weight: 1.5, place: 'support', verb: 'PLACE', desc: 'Column that props up a roof. USE on floor or ceiling.' },
  spiracle_filter:{ name: 'Spiracle Filter', weight: 0.2, use: { filter: 240 }, verb: 'WEAR', desc: 'Filters stale air for ~4 minutes.' },
  chemical_cell:  { name: 'Chemical Cell',   weight: 0.7, use: { toolCharge: 100 }, verb: 'LOAD', desc: 'Powers the Vibro Pick.' },
  air_pipe:       { name: 'Air Pipe',        weight: 0.8, place: 'pipe', verb: 'PLACE', desc: 'Links to a powered air network within 6 u.' },
  air_booster:    { name: 'Air Booster',     weight: 1.2, place: 'booster', verb: 'PLACE', desc: 'Links up to 12 u; needs 0.5 power.' },
  camp_kit:       { name: 'Forward Camp Kit', weight: 2.5, place: 'camp', verb: 'PLACE', desc: 'Deploys a minimal camp on stable ground.' },
  cargo_harness:  { name: 'Cargo Harness',   weight: 0.5, use: { carry: 30 }, verb: 'WEAR', desc: 'Raises carry limit to 30.' },
  scent_mask:     { name: 'Scent Mask',      weight: 0.2, use: { scentMask: 120 }, verb: 'WEAR', desc: 'Musky resin: leaves no trail for 2 minutes.' },
  family_token:   { name: 'Family Token',    weight: 0.1, key: true, desc: 'A worn chitin token with your family\u2019s mark.' },
});

/** Initial Rite Kit (ADD §5). Worn systems (lamp, synthesizer, NAV-CARAPACE, scanner, mandibles) are not items. */
export const RITE_KIT = Object.freeze({ food_ration: 2, water: 2, air_capsule: 1, resin_patch: 2, chemical_cell: 1, resin: 3, family_token: 1 });
