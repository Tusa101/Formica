// Field crafting (no Fabricator needed). Advanced recipes arrive with the Fabricator in P08.
export const RECIPES = Object.freeze([
  { id: 'resin_patch', out: 'resin_patch', n: 1, needs: { resin: 1 } },
  { id: 'resin_support', out: 'resin_support', n: 1, needs: { resin: 2, chitin: 1 } },
  { id: 'spiracle_filter', out: 'spiracle_filter', n: 1, needs: { fungus: 1, chitin: 1 } },
  { id: 'food_ration', out: 'food_ration', n: 1, needs: { fungus: 2, seed: 1 } },
  { id: 'chemical_cell', out: 'chemical_cell', n: 1, needs: { scrap: 2, fungus: 1 } },
  { id: 'air_capsule', out: 'air_capsule', n: 1, needs: { resin: 1, scrap: 1 } },
  { id: 'scent_mask', out: 'scent_mask', n: 1, needs: { fungus: 1, resin: 1 } },
  // Fabricator only (P08)
  { id: 'air_pipe', out: 'air_pipe', n: 2, needs: { resin: 1, chitin: 1 }, station: 'fabricator' },
  { id: 'air_booster', out: 'air_booster', n: 1, needs: { resin: 2, scrap: 2, chitin: 1 }, station: 'fabricator' },
  { id: 'camp_kit', out: 'camp_kit', n: 1, needs: { resin: 3, chitin: 2, scrap: 1, chemical_cell: 1 }, station: 'fabricator' },
  { id: 'cargo_harness', out: 'cargo_harness', n: 1, needs: { chitin: 3, resin: 2 }, station: 'fabricator' },
  { id: 'cell_fab', out: 'chemical_cell', n: 2, needs: { scrap: 2, fungus: 1 }, station: 'fabricator' },
]);
