// What the ant has seen, where it has been, and the pheromone markers it left (GDD §19, §44). Pure JS.
export const MARKERS = Object.freeze({
  home: { name: 'HOME', color: 0x5fd0c0 },
  danger: { name: 'DANGER', color: 0xc8574b },
  food: { name: 'FOOD', color: 0x9fcf6a },
  path: { name: 'PATH', color: 0xe0a64a },
});

export class Exploration {
  constructor(nav, opts = {}) {
    this.nav = nav;
    this.seen = new Uint8Array(nav.count);
    this.seenCount = 0;
    this.version = 0;
    this.route = [];               // [[x,y,z], …] one point per `routeStep` units
    this.routeStep = opts.routeStep ?? 1.5;
    this.routeMax = opts.routeMax ?? 3000;
    this.markers = [];             // {id, type, pos}
    this._nextMarker = 1;
  }

  /** Marks open cells reachable through open space within `radius` of p (no seeing through rock). */
  reveal(p, radius = 5) {
    const nav = this.nav, [X, Y, Z] = nav.dims;
    const start = nav.nearestOpen(p, 2);
    if (start < 0) return 0;
    const [si, sj, sk] = nav.coords(start);
    const R = Math.ceil(radius / nav.cell), R2 = R * R;
    const visited = new Set([start]);
    const stack = [start];
    let added = 0;
    while (stack.length) {
      const c = stack.pop();
      if (!this.seen[c]) { this.seen[c] = 1; this.seenCount++; added++; }
      const i = c % X, j = Math.floor(c / X) % Y, k = Math.floor(c / (X * Y));
      for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
        const a = i + dx, b = j + dy, e = k + dz;
        if (a < 0 || b < 0 || e < 0 || a >= X || b >= Y || e >= Z) continue;
        if ((a - si) ** 2 + (b - sj) ** 2 + (e - sk) ** 2 > R2) continue;
        const n = a + X * (b + Y * e);
        if (!nav.open[n] || visited.has(n)) continue;
        visited.add(n); stack.push(n);
      }
    }
    if (added) this.version++;
    return added;
  }

  addRoute(p) {
    const last = this.route[this.route.length - 1];
    if (last && Math.hypot(p[0] - last[0], p[1] - last[1], p[2] - last[2]) < this.routeStep) return false;
    this.route.push([+p[0].toFixed(1), +p[1].toFixed(1), +p[2].toFixed(1)]);
    if (this.route.length > this.routeMax) this.route.splice(0, this.route.length - this.routeMax);
    this.version++;
    return true;
  }

  addMarker(type, pos) {
    if (!MARKERS[type]) throw new Error('marker type ' + type);
    const m = { id: this._nextMarker++, type, pos: pos.map((v) => +v.toFixed(2)) };
    this.markers.push(m); this.version++;
    return m;
  }
  removeMarker(id) { const n = this.markers.length; this.markers = this.markers.filter((m) => m.id !== id); if (n !== this.markers.length) this.version++; }
  nearestMarker(p, r = 2) {
    let best = null, bd = r;
    for (const m of this.markers) { const d = Math.hypot(...m.pos.map((v, i) => v - p[i])); if (d < bd) { bd = d; best = m; } }
    return best;
  }

  /** Seen cells as run-length pairs [start, length, …] — compact for localStorage. */
  seenRuns() {
    const out = []; let i = 0;
    while (i < this.seen.length) {
      if (!this.seen[i]) { i++; continue; }
      const s = i; while (i < this.seen.length && this.seen[i]) i++;
      out.push(s, i - s);
    }
    return out;
  }

  toJSON() { return { seen: this.seenRuns(), route: this.route, markers: this.markers, next: this._nextMarker }; }

  load(d) {
    if (!d) return;
    const r = d.seen || [];
    for (let q = 0; q + 1 < r.length; q += 2) for (let i = r[q]; i < r[q] + r[q + 1] && i < this.seen.length; i++) if (!this.seen[i]) { this.seen[i] = 1; this.seenCount++; }
    this.route = d.route || []; this.markers = d.markers || []; this._nextMarker = d.next || this.markers.length + 1;
    this.version++;
  }
}
