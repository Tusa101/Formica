// Map controls: drag to rotate, pinch / wheel / buttons to zoom, recenter, drop pheromone markers.
import { MARKERS } from '../gameplay/exploration.js';

export class MapPanel {
  constructor(root, { onClose, onOrbit, onZoom, onRecenter, onMark, onUnmark }) {
    this.el = document.createElement('div');
    this.el.id = 'map-panel'; this.el.hidden = true;
    this.el.innerHTML = `
      <div class="map-gesture"></div>
      <div class="map-title">NAV-CARAPACE · MAP</div>
      <button class="pbtn map-close" data-hud="map-close" data-hud-group="map">CLOSE</button>
      <div class="map-zoom">
        <button class="cbtn ghost" data-z="0.8" data-hud="map-zin">+</button>
        <button class="cbtn ghost" data-z="1.25" data-hud="map-zout">−</button>
        <button class="cbtn ghost" data-center data-hud="map-center">◎</button>
      </div>
      <div class="map-marks">
        <span>MARK HERE</span>
        ${Object.entries(MARKERS).map(([k, m]) => `<button class="cbtn ghost mk-${k}" data-mark="${k}" data-hud="map-mk-${k}">${m.name}</button>`).join('')}
        <button class="cbtn ghost" data-unmark data-hud="map-unmark">REMOVE</button>
      </div>`;
    root.appendChild(this.el);
    this.el.querySelector('.map-close').addEventListener('click', onClose);
    for (const b of this.el.querySelectorAll('[data-z]')) b.addEventListener('click', () => onZoom(Number(b.dataset.z)));
    this.el.querySelector('[data-center]').addEventListener('click', onRecenter);
    for (const b of this.el.querySelectorAll('[data-mark]')) b.addEventListener('click', () => onMark(b.dataset.mark));
    this.el.querySelector('[data-unmark]').addEventListener('click', onUnmark);
    const g = this.el.querySelector('.map-gesture');
    const pts = new Map(); let pinch = 0;
    g.addEventListener('pointerdown', (e) => { g.setPointerCapture?.(e.pointerId); pts.set(e.pointerId, [e.clientX, e.clientY]); pinch = 0; });
    g.addEventListener('pointermove', (e) => {
      if (!pts.has(e.pointerId)) return;
      const prev = pts.get(e.pointerId); pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 1) onOrbit(e.clientX - prev[0], e.clientY - prev[1]);
      else if (pts.size === 2) {
        const [a, b] = [...pts.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]);
        if (pinch) onZoom(pinch / d); pinch = d;
      }
    });
    const up = (e) => { pts.delete(e.pointerId); pinch = 0; };
    g.addEventListener('pointerup', up); g.addEventListener('pointercancel', up);
    g.addEventListener('wheel', (e) => onZoom(e.deltaY > 0 ? 1.1 : 0.9), { passive: true });
  }
  get open() { return !this.el.hidden; }
  show() { this.el.hidden = false; }
  hide() { this.el.hidden = true; }
}
