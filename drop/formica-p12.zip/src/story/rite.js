// The Rite — mini vertical slice script (GDD §63–64, §73; ADD §2–8). Pure JS: the scene supplies a context each tick
// and executes the returned actions. Every beat fires once; state is serialisable.
import { ESCORT, RITE_KIT_BOOT, RECORDINGS } from '../data/lore.js';

export class RiteStory {
  constructor(state = null) {
    this.s = state || { phase: 'off', t: 0, done: [], stats: { deaths: 0 } };
  }
  get phase() { return this.s.phase; }
  get active() { return this.s.phase !== 'off'; }
  did(id) { return this.s.done.includes(id); }
  _once(id, out, ...actions) { if (this.did(id)) return false; this.s.done.push(id); out.push(...actions); return true; }

  start() { this.s = { phase: 'opening', t: 0, done: [], stats: { deaths: 0 } }; }

  /** Whether the shelter bearing is shown (ADD §6: direction, not a path). */
  get signal() { return this.s.phase === 'journey' && this.did('boot') && !this.did('shelter'); }

  /**
   * @param {number} dt
   * @param {{seesResin?:boolean, air?:number, spiderThreat?:boolean, inShelter?:boolean, logRead?:boolean,
   *          powerRepaired?:boolean, deepNear?:boolean, beaconRepaired?:boolean, transmitted?:boolean, distance?:number}} c
   * @returns {Array<{type:string, lines?:Array, id?:string}>}
   */
  update(dt, c = {}) {
    const out = [];
    const s = this.s;
    if (s.phase === 'off' || s.phase === 'ended') return out;
    s.t += dt;
    if (s.phase === 'opening') {
      if (s.t > 0.8) this._once('escort1', out, { type: 'say', lines: [ESCORT[0]] });
      if (s.t > 4.5) this._once('escort2', out, { type: 'say', lines: [ESCORT[1]] });
      if (s.t > 6.0) this._once('seal', out, { type: 'seal' });
      if (s.t > 8.0) this._once('boot', out, { type: 'system', lines: RITE_KIT_BOOT.map((l, i) => (i === 3 ? `${l} ~${Math.round((c.distance ?? 35) / 5) * 5} u` : l)) });
      if (s.t > 13) { this._once('rec-start', out, { type: 'say', lines: RECORDINGS.start }); s.phase = 'journey'; }
      return out;
    }
    if (c.seesResin) this._once('rec-resin', out, { type: 'say', lines: RECORDINGS.resin });
    if (c.air !== undefined && c.air < 0.6) this._once('rec-air', out, { type: 'say', lines: RECORDINGS.air });
    if (c.spiderThreat) this._once('rec-spider', out, { type: 'say', lines: RECORDINGS.spider });
    if (c.inShelter) this._once('shelter', out, { type: 'say', lines: RECORDINGS.shelter });
    if (c.logRead) this._once('rec-log', out, { type: 'say', lines: RECORDINGS.log });
    if (c.powerRepaired) this._once('lure', out, { type: 'lure' });
    if (this.did('lure') && c.deepNear) this._once('shift', out, { type: 'shift' });
    if (c.beaconRepaired) this._once('rec-beacon', out, { type: 'say', lines: RECORDINGS.beacon });
    if (c.transmitted && this._once('finale', out, { type: 'finale' })) s.phase = 'ended';
    return out;
  }

  toJSON() { return this.s; }
}
