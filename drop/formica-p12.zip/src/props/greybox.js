// GREYBOX landmark props. Placeholders with a clear source for every light (AB §10);
// replaced by Blender assets (PIPE §43) through the level's `kind` without touching logic.
import * as THREE from 'three';

function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }

export function fungusCluster(seed, glowColor) {
  const r = rng(seed);
  const g = new THREE.Group();
  const capMat = new THREE.MeshStandardMaterial({ color: 0x9fb8a0, emissive: glowColor, emissiveIntensity: 0.9, roughness: 0.7 });
  const stemMat = new THREE.MeshStandardMaterial({ color: 0xcfc6b0, roughness: 0.9 });
  for (let i = 0; i < 6; i++) {
    const h = 0.3 + r() * 0.7;
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.07, h, 7), stemMat);
    stem.position.set((r() - 0.5) * 1.0, h / 2, (r() - 0.5) * 1.0);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.14 + r() * 0.14, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), capMat);
    cap.position.set(stem.position.x, h, stem.position.z);
    g.add(stem, cap);
  }
  return g;
}

export function ritualLamp() {
  const g = new THREE.Group();
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, 1.2, 8), new THREE.MeshStandardMaterial({ color: 0x3b3128, roughness: 0.6 }));
  post.position.y = 0.6;
  const glass = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 8),
    new THREE.MeshStandardMaterial({ color: 0xe0a64a, emissive: 0xe0a64a, emissiveIntensity: 1.4, roughness: 0.3 }));
  glass.position.y = 1.3;
  g.add(post, glass);
  return g;
}

export const PROP_BUILDERS = { fungus: (i, l) => fungusCluster(17 + i * 31, l.color), 'ritual-lamp': () => ritualLamp() };
