import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { TEST_TUNNELS } from '../src/levels/test-tunnels.js';
import { AntMotor } from '../src/player/ant-motor.js';
import { cameraBasis, modeUp, viewDirection } from '../src/player/camera-math.js';
import { CONFIG } from '../src/config.js';
import * as V from '../src/core/vec3.js';

function fieldFrom(fn, min, max, N = 20, voxel = 0.4) {
  const f = new DensityField(N, voxel);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, N, voxel, fn, () => 0));
  return f;
}
// Sphere cave radius 4 at origin (chunks of 8 units cover [-8, 8)).
const cave = fieldFrom((x, y, z) => Math.hypot(x, y, z) - 4, [-1, -1, -1], [0, 0, 0]);
const P = CONFIG.ant;
const fwd = (extra = {}) => ({ moveX: 0, moveY: 1, yaw: 0, pitch: 0, jump: false, fast: false, ...extra });

test('ant settles on the floor at hover height', () => {
  const a = new AntMotor(cave, P);
  a.place([0, 0, 0], 0);
  assert.equal(a.mode, 'surface');
  assert.ok(Math.abs(a.pos[1] - (-4 + P.hover)) < 0.1, `y=${a.pos[1]}`);
  assert.ok(a.up[1] > 0.95);
});

test('walking forward climbs the wall onto the ceiling, never entering rock', () => {
  const a = new AntMotor(cave, P);
  a.place([0, 0, 0], 0);
  let minUpY = 1, maxErr = 0;
  for (let i = 0; i < 60 * 10; i++) {
    a.step(1 / 60, fwd());
    assert.equal(a.mode, 'surface', `detached at step ${i}`);
    maxErr = Math.max(maxErr, Math.abs(Math.hypot(...a.pos) - (4 - P.hover)));
    minUpY = Math.min(minUpY, a.up[1]);
    assert.ok(cave.densityAt(...a.pos) < 0, 'inside rock');
  }
  assert.ok(maxErr < 0.12, `hover error ${maxErr}`);
  assert.ok(minUpY < -0.5, `reached ceiling (min up.y ${minUpY})`);
});

test('jump from floor → air → lands again', () => {
  const a = new AntMotor(cave, P);
  a.place([0, 0, 0], 0);
  a.step(1 / 60, fwd({ jump: true }));
  assert.equal(a.mode, 'air');
  let landed = false;
  for (let i = 0; i < 180 && !landed; i++) { a.step(1 / 60, fwd({ moveY: 0 })); landed = a.mode === 'surface'; }
  assert.ok(landed);
});

test('jump on the ceiling = let go → falls onto the floor', () => {
  const a = new AntMotor(cave, P);
  a.place([0, 0, 0], 0);
  for (let i = 0; i < 1000 && a.up[1] > -0.9; i++) a.step(1 / 60, fwd());
  assert.ok(a.up[1] < -0.9, 'on ceiling');
  a.step(1 / 60, fwd({ jump: true, moveY: 0 }));
  let t = 0;
  while (a.mode === 'air' && t < 400) { a.step(1 / 60, null); t++; }
  assert.equal(a.mode, 'surface');
  assert.ok(a.pos[1] < -2, `landed low (y=${a.pos[1].toFixed(2)})`);
});

test('Test Tunnels: 40 s of random input — never in rock, never lost, keeps moving', () => {
  const L = buildLevelField(TEST_TUNNELS);
  const { min, max } = TEST_TUNNELS.chunks;
  const f = fieldFrom(L.density, min, max, 40, 0.4);
  const a = new AntMotor(f, P);
  a.place(TEST_TUNNELS.spawn.pos, TEST_TUNNELS.spawn.yaw);
  assert.equal(a.mode, 'surface');
  let seed = 3; const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  let inp = fwd(), travelled = 0, inRock = 0;
  const start = [...a.pos];
  for (let i = 0; i < 60 * 40; i++) {
    if (i % 45 === 0) inp = { moveX: rnd() * 2 - 1, moveY: rnd() * 1.4 - 0.2, yaw: 0, pitch: 0, jump: rnd() < 0.08, fast: rnd() < 0.3 };
    inp.yaw = (rnd() - 0.5) * 0.06;
    const before = [...a.pos];
    a.step(1 / 60, inp);
    inp.jump = false;
    travelled += Math.hypot(a.pos[0] - before[0], a.pos[1] - before[1], a.pos[2] - before[2]);
    if (f.densityAt(...a.pos) > 0.05) inRock++;
    assert.ok(a.pos.every(Number.isFinite), 'finite');
    assert.ok(Math.abs(a.pos[0]) < 32 && Math.abs(a.pos[2]) < 32 && a.pos[1] > -16 && a.pos[1] < 16, 'inside world');
  }
  assert.equal(inRock, 0, 'frames inside rock');
  assert.ok(travelled > 40, `travelled ${travelled.toFixed(1)}`);
  assert.ok(Math.hypot(a.pos[0] - start[0], a.pos[2] - start[2]) >= 0, 'ok');
});

test('camera basis is orthonormal in all modes, incl. ceiling and view ∥ up', () => {
  for (const mode of CONFIG.camera.modes) {
    for (const [heading, up, pitch] of [[[0, 0, -1], [0, 1, 0], 0], [[0, 0, -1], [0, -1, 0], 0.3], [[0, 1, 0], [1, 0, 0], 1.45], [[0, 0, 1], [0, 1, 0], 1.45]]) {
      const u = modeUp([0, 0, 0], up, mode, CONFIG.camera.reducedBlend);
      const view = viewDirection([0, 0, 0], heading, up, pitch);
      const b = cameraBasis(view, u, [1, 0, 0]);
      for (const v of [b.right, b.up, b.back]) { assert.ok(v.every(Number.isFinite)); assert.ok(Math.abs(V.len(v) - 1) < 1e-6); }
      assert.ok(Math.abs(V.dot(b.right, b.up)) < 1e-6 && Math.abs(V.dot(b.up, b.back)) < 1e-6 && Math.abs(V.dot(b.right, b.back)) < 1e-6);
      assert.ok(V.dot(b.back, view) < -0.999, 'looks along view');
    }
  }
});

import { Course, formatTime } from '../src/gameplay/course.js';
test('course gates sit in empty space and run in order', () => {
  const L = buildLevelField(TEST_TUNNELS);
  for (const g of TEST_TUNNELS.course.gates) assert.ok(L.density(...g.pos) < -0.3, `${g.name} is open`);
  const mem = new Map(); const storage = { getItem: (k) => mem.get(k) ?? null, setItem: (k, v) => mem.set(k, v) };
  const c = new Course(TEST_TUNNELS.course, storage);
  assert.equal(c.update(0.5, [100, 100, 100], true), null);
  const gates = TEST_TUNNELS.course.gates;
  gates.slice(0, -1).forEach((g, i) => assert.equal(c.update(0.5, g.pos, true).index, i + 1));
  const fin = c.update(0.5, gates.at(-1).pos, true);
  assert.equal(fin.type, 'finish'); assert.ok(fin.record);
  assert.equal(new Course(TEST_TUNNELS.course, storage).best, fin.time);
  assert.equal(formatTime(65.25), '1:05.3');
});

import { ROUTE, runBot, groundRoute } from './bot.mjs';
test('route bot walks the whole Test Tunnels course on the real motor', () => {
  const L = buildLevelField(TEST_TUNNELS);
  const f = fieldFrom(L.density, TEST_TUNNELS.chunks.min, TEST_TUNNELS.chunks.max, 40, 0.4);
  const a = new AntMotor(f, P);
  a.place(TEST_TUNNELS.spawn.pos, TEST_TUNNELS.spawn.yaw);
  let rock = 0;
  const r = runBot(a, groundRoute(f, ROUTE, P.hover), { onStep: (m) => { if (f.densityAt(...m.pos) > 0.05) rock++; } });
  assert.ok(r.ok, `bot stuck: ${JSON.stringify(r)}`);
  assert.equal(rock, 0);
  // every course gate lies on the route
  for (const g of TEST_TUNNELS.course.gates) assert.ok(ROUTE.some((p) => Math.hypot(p[0] - g.pos[0], p[1] - g.pos[1], p[2] - g.pos[2]) < g.r + 1.5), g.name);
});
