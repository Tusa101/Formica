import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateChunk, DensityField } from '../src/world/field.js';
import { carveSphere, fillSphere } from '../src/world/terrain-ops.js';
import { NavGrid } from '../src/world/navgrid.js';
import { Stability, State } from '../src/world/stability.js';
import { MAT } from '../src/data/materials.js';

// A solid block of clay, 32 × 16 × 32 units (ADD §79 scenarios are dug into it).
function clayWorld() {
  const min = [-2, -1, -2], max = [1, 0, 1];
  const f = new DensityField(20, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 20, 0.4, () => 3, () => MAT.CLAY));
  const nav = new NavGrid(f); nav.build();
  const st = new Stability(f, nav); st.build();
  const edit = (c, r) => { carveSphere(f, c, r, { hardness: () => 0 }); nav.updateBox(c.map((v) => v - r - 1), c.map((v) => v + r + 1)); st.onEdit(c, r); };
  const tunnel = (a, b, r = 0.72) => { const n = Math.ceil(Math.hypot(...a.map((v, i) => b[i] - v)) / 0.45); for (let s = 0; s <= n; s++) edit(a.map((v, i) => v + (b[i] - v) * (s / n)), r); };
  /** a flat chamber: floor at y0, height h, square of side w */
  const chamber = (cx, cz, y0, w, h = 1.8) => { for (let x = -w / 2 + 0.7; x <= w / 2 - 0.7; x += 0.9) for (let z = -w / 2 + 0.7; z <= w / 2 - 0.7; z += 0.9) edit([cx + x, y0 + h / 2, cz + z], h / 2 + 0.25); };
  const run = (secs, fn) => { const out = []; for (let t = 0; t < secs; t += 1 / 30) { fn?.(t); const f2 = st.update(1 / 30, [0, 0, 0]); out.push(...f2); if (f2.length) break; } return out; };
  const worst = () => { st.update(0, null); while (st.urgent.size) st.update(0, null); let m = 0; for (const i of st.roofs) m = Math.max(m, st.S[i]); return m; };
  return { f, nav, st, edit, tunnel, chamber, run, worst };
}

test('A: a modest dug chamber (4 u) stays stable', () => {
  const w = clayWorld();
  w.chamber(0, 0, -2, 4);
  const failed = w.run(40);
  assert.equal(failed.length, 0);
  assert.ok(w.worst() < 0.6, `max S ${w.worst().toFixed(2)}`);
});

test('B: widening the chamber to ~11 u stresses the roof and collapses it; a support column prevents that', () => {
  const w = clayWorld();
  w.chamber(0, 0, -2, 11);
  const s = w.worst();
  assert.ok(s >= 1, `max S ${s.toFixed(2)}`);
  const failed = w.run(60);
  assert.equal(failed.length, 1, 'collapsed');
  const plan = w.st.planCollapse(failed[0]);
  assert.ok(plan.carve.r >= 1 && plan.fill.r >= 0.9);

  const w2 = clayWorld();
  w2.chamber(0, 0, -2, 11);
  for (const [x, z] of [[-2.5, -2.5], [2.5, -2.5], [-2.5, 2.5], [2.5, 2.5], [0, 0]]) w2.st.addSupport([x, -2, z], [x, -0.2, z]);
  assert.equal(w2.run(60).length, 0, 'supported chamber holds');
});

test('C: a second tunnel close below the first makes the layer stressed but it does not fail on its own', () => {
  const w = clayWorld();
  w.tunnel([-8, 0, 0], [8, 0, 0]);
  w.tunnel([-8, -2.6, 0], [8, -2.6, 0]);
  const s = w.worst();
  assert.ok(s >= 0.6 && s < 1, `layer S ${s.toFixed(2)} should be "stressed"`);
  assert.equal(w.run(40).length, 0);
  const states = new Set(w.st.roofs.map((i) => w.st.state(i)));
  assert.ok(states.has(State.STRESSED));
});

function trafficRun(w, secs) {
  // the ant walks back and forth along the upper tunnel floor (feet ~0.1 above it)
  return w.run(secs, (t) => { const x = -6 + ((t * 2.2) % 12); w.st.addTraffic([x, -0.55, 0], 1 / 30, 2); });
}

test('D: traffic over the thin layer makes it fail; the collapse joins upper and lower tunnel', () => {
  const w = clayWorld();
  w.tunnel([-8, 0, 0], [8, 0, 0]);
  w.tunnel([-8, -2.6, 0], [8, -2.6, 0]);
  const upper = w.nav.label[w.nav.nearestOpen([0, 0, 0])], lower = w.nav.label[w.nav.nearestOpen([0, -2.6, 0])];
  assert.notEqual(upper, lower, 'separate before');
  const failed = trafficRun(w, 90);
  assert.equal(failed.length, 1, 'layer failed under traffic');
  assert.ok(failed[0].info.thin);
  const { carve, fill } = w.st.planCollapse(failed[0]);
  carveSphere(w.f, carve.c, carve.r, { hardness: () => 0 });
  fillSphere(w.f, fill.c, fill.r, fill.material);
  w.nav.updateBox(carve.c.map((v) => v - 4), carve.c.map((v) => v + 4));
  w.st.settle(carve.c, 3);
  assert.equal(w.nav.label[w.nav.nearestOpen([0, 0, 0])], w.nav.label[w.nav.nearestOpen([6, -2.6, 0])], 'tunnels connected by the collapse');
});

test('D+: a support under the thin layer keeps it standing under the same traffic', () => {
  const w = clayWorld();
  w.tunnel([-8, 0, 0], [8, 0, 0]);
  w.tunnel([-8, -2.6, 0], [8, -2.6, 0]);
  for (const x of [-4, 0, 4]) w.st.addSupport([x, -3.2, 0], [x, -1.9, 0]);
  assert.equal(trafficRun(w, 90).length, 0);
});

test('fillSphere turns space solid with the given material', () => {
  const w = clayWorld();
  w.edit([0, 0, 0], 1.5);
  assert.ok(w.f.densityAt(0, 0, 0) < 0);
  fillSphere(w.f, [0, 0, 0], 1.0, MAT.SAND);
  assert.ok(w.f.densityAt(0, 0, 0) > 0);
  assert.equal(w.f.materialAt(0, 0, 0), MAT.SAND);
});

import { buildLevelField } from '../src/world/levelfield.js';
import { TEST_TUNNELS } from '../src/levels/test-tunnels.js';
import { AntMotor } from '../src/player/ant-motor.js';
import { CONFIG } from '../src/config.js';
import { ROUTE, runBot, groundRoute } from './bot.mjs';

test('natural caves of Test Tunnels stay standing while the ant walks the whole course', () => {
  const L = buildLevelField(TEST_TUNNELS), { min, max } = TEST_TUNNELS.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const nav = new NavGrid(f); nav.build();
  const st = new Stability(f, nav); st.build();
  const a = new AntMotor(f, CONFIG.ant); a.place(TEST_TUNNELS.spawn.pos, TEST_TUNNELS.spawn.yaw);
  let collapses = 0, maxS = 0;
  const r = runBot(a, groundRoute(f, ROUTE, CONFIG.ant.hover), { onStep: (m) => {
    st.addTraffic(m.pos.map((v, i) => v - m.up[i] * 0.45), 1 / 60, 1);
    collapses += st.update(1 / 60, m.pos).length;
  } });
  for (const i of st.roofs) maxS = Math.max(maxS, st.S[i]);
  assert.ok(r.ok);
  assert.equal(collapses, 0, `max S ${maxS.toFixed(2)}`);
});
