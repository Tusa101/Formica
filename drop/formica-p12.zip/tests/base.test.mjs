import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BaseNetwork } from '../src/gameplay/base.js';
import { Inventory } from '../src/gameplay/inventory.js';
import { craft } from '../src/gameplay/crafting.js';
import { TEST_TUNNELS as T } from '../src/levels/test-tunnels.js';

const fresh = () => new BaseNetwork(T.shelter.modules);
const inv = (items) => Inventory.from(items, 40);

test('ADD §8 initial shelter: degraded power keeps lights, air and condenser alive; fabricator and beacon are not', () => {
  const b = fresh();
  assert.equal(b.supply, 1.5);
  for (const id of ['lights', 'air', 'condenser']) assert.ok(b.isPowered(id), id);
  assert.ok(!b.isPowered('fabricator') && !b.isPowered('beacon'));
  const air = b.airSources().find((s) => s.radius === 1.6);
  assert.ok(air, 'degraded processor makes only a small bubble');
});

test('repairs follow a dependency chain: fix power before the fabricator can run', () => {
  const b = fresh();
  const i = inv({ resin: 10, scrap: 6, chitin: 4 });
  assert.equal(b.repair('fabricator', inv({})).ok, false, 'needs materials');
  assert.ok(b.repair('fabricator', i).ok);
  assert.ok(!b.isPowered('fabricator'), 'not enough power yet (1.5 supply)');
  assert.ok(b.repair('power', i).ok);
  assert.equal(b.supply, 3);
  assert.ok(b.isPowered('fabricator'));
  assert.ok(b.repair('air', i).ok);
  assert.equal(b.airSources().find((s) => b.get('air').pos === s.pos).radius, 4.5);
  assert.equal(i.count('resin'), 3);
});

test('power nodes burn fuel with use and go dark when empty; a chemical cell refuels', () => {
  const b = fresh();
  const t = 55 / (1.5 / 15);
  for (let s = 0; s < t - 5; s += 1) b.update(1);
  assert.ok(b.isPowered('air'));
  for (let s = 0; s < 10; s += 1) b.update(1);
  assert.ok(!b.isPowered('air') && b.supply === 0, 'dark');
  assert.ok(b.refuel('power', inv({ chemical_cell: 1 })).ok);
  assert.ok(b.isPowered('air'));
});

test('air pipes extend the network only within range and line of sight; boosters need power', () => {
  const wall = (a, b) => !(Math.min(a[0], b[0]) < 30 && Math.max(a[0], b[0]) > 30); // rock at x = 30
  const b = new BaseNetwork([{ id: 'p', type: 'power', pos: [0, 0, 0], state: 'working', fuel: 100 }, { id: 'air', type: 'air', pos: [0, 0, 0], state: 'working' }], { los: wall });
  const p1 = b.place('pipe', [5, 0, 0]);
  const p2 = b.place('pipe', [10.5, 0, 0]);
  const far = b.place('pipe', [20, 0, 0]);
  assert.ok(b.linked.has(p1.id) && b.linked.has(p2.id));
  assert.ok(!b.linked.has(far.id), 'gap of 9.5 is too long for pipes');
  const boost = b.place('booster', [21.5, 0, 0]);
  assert.ok(b.linked.has(boost.id) && b.linked.has(far.id), 'booster bridges 11 u and relays');
  const behind = b.place('pipe', [31, 0, 0]);
  assert.ok(!b.linked.has(behind.id), 'rock blocks the link');
  assert.equal(b.airSources().length, 1 + 4);
});

test('forward camp: own air bubble on a 10-minute battery, refillable with a cell', () => {
  const b = new BaseNetwork([]);
  const c = b.place('camp', [0, 0, 0]);
  assert.equal(b.airSources().length, 1);
  for (let s = 0; s < 601; s++) b.update(1);
  assert.equal(b.airSources().length, 0);
  assert.ok(b.refuel(c.id, inv({ chemical_cell: 1 })).ok);
  assert.equal(b.airSources().length, 1);
});

test('fabricator recipes need a working fabricator; state survives save/load', () => {
  const i = inv({ resin: 5, chitin: 5, scrap: 3, chemical_cell: 1 });
  assert.equal(craft(i, 'air_pipe').reason, 'needs fabricator');
  assert.ok(craft(i, 'air_pipe', { fabricator: true }).ok);
  assert.equal(i.count('air_pipe'), 2);
  const b = fresh(); b.repair('power', inv({ resin: 2, scrap: 1 })); b.place('pipe', [16, -5, -12]);
  const c = fresh(); c.load(JSON.parse(JSON.stringify(b.toJSON())));
  assert.equal(c.get('power').state, 'working');
  assert.equal(c.ofType('pipe').length, 1);
});

import { generateChunk, DensityField } from '../src/world/field.js';
import { buildLevelField } from '../src/world/levelfield.js';
import { NavGrid } from '../src/world/navgrid.js';
import { Atmosphere } from '../src/world/atmosphere.js';

test('GDD first hour: the shelter is reachable, its air is stale, repairing the Air Processor clears it', () => {
  const L = buildLevelField(T), { min, max } = T.chunks;
  const f = new DensityField(40, 0.4, min, max);
  for (let cz = min[2]; cz <= max[2]; cz++) for (let cy = min[1]; cy <= max[1]; cy++) for (let cx = min[0]; cx <= max[0]; cx++)
    f.set(cx, cy, cz, generateChunk(cx, cy, cz, 40, 0.4, L.density, L.material));
  const nav = new NavGrid(f); nav.build();
  assert.equal(nav.label[nav.nearestOpen(T.shelter.respawn, 3)], nav.label[nav.nearestOpen(T.spawn.pos, 3)], 'shelter reachable from the start');
  const run = (repair) => {
    const air = new Atmosphere(nav, T.air, (p) => L.zoneAt(...p, 0.3)); air.init();
    const b = new BaseNetwork(T.shelter.modules.map((m) => { const s = f.dropToSurface(m.pos, 6); return { ...m, pos: s ? [s[0], s[1] + 0.3, s[2]] : m.pos }; }));
    if (repair) b.repair('air', Inventory.from({ resin: 2, chitin: 1, scrap: 1 }));
    air.setSources(b.airSources());
    const q0 = air.quality(T.shelter.respawn);
    for (let t = 0; t < 60; t += 0.1) air.update(0.1);
    return { q0, q: air.quality(T.shelter.respawn) };
  };
  const degraded = run(false), repaired = run(true);
  if (process.env.SHOW) console.log(JSON.stringify({ degraded, repaired }));
  assert.ok(degraded.q0 < 0.5, `stale at start (${degraded.q0.toFixed(2)})`);
  assert.ok(repaired.q > 0.75 && repaired.q > degraded.q + 0.15, `degraded ${degraded.q.toFixed(2)} vs repaired ${repaired.q.toFixed(2)}`);
});
